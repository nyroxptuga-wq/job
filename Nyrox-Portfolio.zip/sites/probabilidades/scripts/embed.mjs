import {readFile,writeFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url);const html=await readFile(new URL('app.html',root),'utf8');const server=await readFile(new URL('server.js',root),'utf8');await writeFile(new URL('worker/index.js',root),'const HTML='+JSON.stringify(html)+';\n'+server);
