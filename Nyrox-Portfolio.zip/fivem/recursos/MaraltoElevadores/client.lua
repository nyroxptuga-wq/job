local prefix=GetCurrentResourceName()..':'
local elevators,opened,travelling={},false,false
local activeTrip=nil
local function close()
    opened=false;SetNuiFocus(false,false);SendNUIMessage({action='close'})
    TriggerServerEvent(prefix..'close')
end
RegisterNetEvent(prefix..'config',function(data)if type(data)=='table'then elevators=data end end)
RegisterNetEvent(prefix..'open',function(elevatorId,floors)
    if travelling then return end
    opened=true;SetNuiFocus(true,true)
    SendNUIMessage({action='openElevator',elevatorId=elevatorId,andares=floors})
end)
RegisterNUICallback('UIRequest',function(data,cb)
    if data.action=='close'then close()
    elseif data.action=='teleport' and opened then
        opened=false;SetNuiFocus(false,false);SendNUIMessage({action='close'})
        TriggerServerEvent(prefix..'travel',data.elevatorId,data.andarId)
    end
    cb({ok=true})
end)
local function finishTrip(trip,rollback,message)
    if trip and activeTrip~=trip then return end
    activeTrip=nil;travelling=false;opened=false
    local ped=trip and trip.ped or PlayerPedId()
    -- Cleanup must run even if a streaming/teleport native fails.
    if rollback and trip and trip.origin then
        pcall(RequestCollisionAtCoord,trip.origin.x,trip.origin.y,trip.origin.z)
        pcall(SetEntityCoordsNoOffset,ped,trip.origin.x,trip.origin.y,trip.origin.z,false,false,false)
        pcall(SetEntityHeading,ped,trip.heading)
    end
    pcall(FreezeEntityPosition,ped,false)
    pcall(SetNuiFocus,false,false)
    pcall(DoScreenFadeIn,0)
    SendNUIMessage({action='close'})
    if message then TriggerEvent('Notify','aviso',message,6000)end
end
RegisterCommand('elevadorfix',function()
    local trip=activeTrip
    finishTrip(trip,trip~=nil,'Ecrã e controlos libertados. Se continuar preto, consulte os erros no F8.')
    TriggerServerEvent(prefix..'close')
end,false)
RegisterNetEvent(prefix..'travel',function(coords)
    if travelling or type(coords)~='table'then return end
    local x,y,z=tonumber(coords[1]),tonumber(coords[2]),tonumber(coords[3])
    local function finite(value)return value and value==value and value~=math.huge and value~=-math.huge end
    if not finite(x)or not finite(y)or not finite(z)then return end
    local ped=PlayerPedId()
    local trip={ped=ped,origin=GetEntityCoords(ped),heading=GetEntityHeading(ped)}
    activeTrip=trip;travelling=true
    -- No fade-out: an exception can no longer leave this resource's screen black.
    SetTimeout(6000,function()
        if activeTrip==trip then finishTrip(trip,true,'O destino não carregou. Voltou ao ponto de partida.')end
    end)
    CreateThread(function()
        if activeTrip~=trip then return end
        local arrived=false
        local ok,err=xpcall(function()
            FreezeEntityPosition(ped,true)
            RequestCollisionAtCoord(x,y,z)
            SetEntityCoordsNoOffset(ped,x,y,z,false,false,false)
            if tonumber(coords[4])then SetEntityHeading(ped,tonumber(coords[4]))end
            local deadline=GetGameTimer()+4000
            while activeTrip==trip and not HasCollisionLoadedAroundEntity(ped)and GetGameTimer()<deadline do
                RequestCollisionAtCoord(x,y,z);Wait(50)
            end
            if activeTrip~=trip then return end
            arrived=HasCollisionLoadedAroundEntity(ped)
        end,debug.traceback)
        if activeTrip~=trip then return end
        if not ok then print('[MaraltoElevadores] Viagem interrompida: '..tostring(err))end
        if ok and arrived then
            finishTrip(trip,false)
            SendNUIMessage({action='bell'})
        else finishTrip(trip,true,'Não foi possível carregar o destino. Confirme o mapa/interior na consola F8.')end
    end)
end)

CreateThread(function()
    TriggerServerEvent(prefix..'config')
    while true do
        local sleep=1000;local ped=PlayerPedId()
        if not travelling and not opened and not IsPedInAnyVehicle(ped,false)then
            local p=GetEntityCoords(ped)
            for key,elevator in pairs(elevators)do
                for _,point in pairs(elevator.blips or {})do
                    local distance=(p.x-point[1])^2+(p.y-point[2])^2+(p.z-point[3])^2
                    if distance<=42.25 then
                        sleep=0
                        DrawMarker(30,point[1],point[2],point[3]-0.45,0,0,0,0,0,0,0.3,0.3,0.3,255,255,255,180,false,false,2,false,nil,nil,false)
                        if distance<=1.44 and IsControlJustPressed(0,38)then TriggerServerEvent(prefix..'open',key);Wait(500)end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
AddEventHandler('onClientResourceStart',function(name)if name==GetCurrentResourceName()then TriggerServerEvent(prefix..'config')end end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName()then return end
    local trip=activeTrip
    if trip then finishTrip(trip,true)else SetNuiFocus(false,false)end
end)
