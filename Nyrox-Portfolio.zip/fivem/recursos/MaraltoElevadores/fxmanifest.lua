fx_version 'cerulean'
game 'gta5'
author 'Implementação independente para vRP'
version '2.0.1'
dependencies {'vrp', '/onesync'}
ui_page 'ui/ui.html'
files {'ui/*'}
client_scripts {'@vrp/lib/utils.lua', 'client.lua'}
server_scripts {'@vrp/lib/utils.lua', 'server.lua'}
