local dir=os.getenv('MARALTO_RESOURCE_DIR')or'.'
local events,commands,threads,timers,messages={}, {}, {}, {}, {}
local now=1000
local position={x=1,y=2,z=3}
local frozen,focus,fadeOutCalls,fadeInCalls=false,false,0,0
local collision=true;local failTeleport=false
local count=0
local function check(ok,message)count=count+1;assert(ok,message)end
function GetCurrentResourceName()return'MaraltoElevadores'end
function RegisterNetEvent(name,fn)events[name]=fn end
function AddEventHandler(name,fn)events[name]=fn end
function RegisterNUICallback()end
function RegisterCommand(name,fn)commands[name]=fn end
function CreateThread(fn)threads[#threads+1]=fn end
function SetTimeout(ms,fn)timers[#timers+1]=fn end
function PlayerPedId()return 1 end
function GetEntityCoords()return position end
function GetEntityHeading()return 90 end
function SetEntityHeading()end
function SetNuiFocus(value)focus=value end
function SendNUIMessage(data)messages[#messages+1]=data end
function TriggerServerEvent()end
function TriggerEvent()end
function RequestCollisionAtCoord()end
function FreezeEntityPosition(_,value)frozen=value end
function DoScreenFadeOut()fadeOutCalls=fadeOutCalls+1 end
function DoScreenFadeIn()fadeInCalls=fadeInCalls+1 end
function SetEntityCoordsNoOffset(_,x,y,z)
 if failTeleport then failTeleport=false;error('simulated native failure')end
 position={x=x,y=y,z=z}
end
function HasCollisionLoadedAroundEntity()return collision end
function GetGameTimer()return now end
function Wait(ms)now=now+ms end
dofile(dir..'/client.lua')
local function trip()events['MaraltoElevadores:travel']({10,20,30});return threads[#threads],timers[#timers]end
local run,watchdog=trip();run()
check(position.x==10 and not frozen,'normal trip arrives and unfreezes')
check(fadeOutCalls==0,'normal trip never fades out')
check(messages[#messages].action=='bell','normal arrival rings bell')
local before=fadeInCalls;watchdog();check(fadeInCalls==before,'completed trip watchdog is inert')
position={x=1,y=2,z=3};failTeleport=true;run=trip();run()
check(position.x==1 and not frozen,'native error restores origin and unfreezes')
check(fadeInCalls>before,'native error restores image')
collision=false;run=trip();run()
check(position.x==1 and not frozen,'missing collision rolls back within timeout')
check(now>=5000,'collision timeout is bounded')
collision=true;run,watchdog=trip();watchdog()
check(position.x==1 and not frozen,'independent watchdog rolls back')
run();check(position.x==1 and not frozen,'expired worker cannot teleport later')
run,watchdog=trip();commands.elevadorfix()
check(not frozen and not focus and position.x==1,'manual command releases image and controls')
run();check(position.x==1,'manual cancellation prevents stale worker')
run,watchdog=trip();events.onResourceStop('MaraltoElevadores');run()
check(not frozen and not focus and position.x==1,'stop cancels trip without late teleport')
events['MaraltoElevadores:travel']({0/0,0,0})
check(threads[#threads]==run,'non-finite coordinates rejected')
commands.elevadorfix();check(not frozen and not focus,'manual recovery works without active trip')
check(fadeOutCalls==0,'no path darkens screen')
print('travel recovery: '..count..' checks passed')
