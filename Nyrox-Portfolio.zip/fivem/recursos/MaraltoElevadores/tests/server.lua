local dir=os.getenv('MARALTO_RESOURCE_DIR')or'.'
local config=dofile(dir..'/config.lua')
local events,sent={},{}
local positions={[1]={x=2497.3137,y=-349.23059,z=94.0922},[2]={x=0,y=0,z=0}}
local users={[1]=101,[2]=102};local permission=false;local now=1000
local count=0
local function check(ok,message)count=count+1;assert(ok,message)end
function GetCurrentResourceName()return'MaraltoElevadores'end
function module(_,path)if path=='config'then return config else return{getInterface=function()return{
 getUserId=function(src)return users[src]end,hasPermission=function()return permission end}end}end end
function RegisterNetEvent(name,fn)events[name]=fn end
function AddEventHandler(name,fn)events[name]=fn end
function GetPlayerPed(src)return src end
function GetEntityCoords(ped)return positions[ped]end
function GetGameTimer()return now end
function TriggerClientEvent(name,...)sent[#sent+1]={name,...}end
source=1
dofile(dir..'/server.lua')
local function fire(name,...)now=now+600;events['MaraltoElevadores:'..name](...)end
fire('config');check(sent[#sent][1]=='MaraltoElevadores:config','config sent');check(sent[#sent][3][1].permission==nil,'permissions not sent to clients')
local before=#sent;fire('open',999);check(#sent==before,'unknown elevator rejected')
fire('travel',1,2);check(#sent==before,'travel requires menu session')
fire('open',1);check(sent[#sent][1]=='MaraltoElevadores:open','opens near origin')
check(#sent[#sent][4]==3,'configured floors retained')
fire('travel',1,2);check(sent[#sent][1]=='MaraltoElevadores:travel','valid trip approved');check(sent[#sent][3][3]==101.89338684082,'uses server configured coordinates')
before=#sent;fire('travel',1,2);check(#sent==before,'travel session cannot be replayed')
fire('open',1);before=#sent;fire('travel',1,999);check(sent[#sent][1]=='Notify','unknown floor rejected')
source=2;fire('open',1);check(sent[#sent][1]=='Notify','remote opening denied')
source=1;config.elevadores[1].permission='policia.permissao';fire('open',1);check(sent[#sent][1]=='Notify','permission enforced')
permission=true;fire('open',1);check(sent[#sent][1]=='MaraltoElevadores:open','authorized user opens restricted elevator')
permission=false;fire('travel',1,2);check(sent[#sent][1]=='Notify','permission rechecked at travel')
config.elevadores[1].permission=nil;fire('open',1);now=now+60001;before=#sent;fire('travel',1,2);check(#sent==before,'expired session rejected')
fire('open',1);positions[1]={x=0,y=0,z=0};fire('travel',1,2);check(sent[#sent][1]=='Notify','position rechecked at travel')
positions[1]={x=2497.3137,y=-349.23059,z=94.0922};fire('open',1);fire('close');before=#sent;fire('travel',1,2);check(#sent==before,'close invalidates session')
users[1]=nil;fire('open',1);check(sent[#sent][1]=='Notify','missing vRP character rejected')
print('elevators: '..count..' checks passed')
