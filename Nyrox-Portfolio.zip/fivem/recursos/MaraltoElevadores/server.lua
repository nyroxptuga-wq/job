local vRP = module('vrp','lib/Proxy').getInterface('vRP')
local cfg = module(GetCurrentResourceName(),'config')
local prefix = GetCurrentResourceName()..':'
local sessions, cooldowns = {}, {}
local function id(n) n=tonumber(n); return n and n==n and n%1==0 and n>0 and n<10000 and n end
local function call(name,...) if cfg.vrpCallStyle=='table' then return vRP[name]({...}) end; return vRP[name](...) end
local function allowed(src,elevator)
    local uid=call('getUserId',src)
    return uid and (not elevator.permission or elevator.permission=='' or call('hasPermission',uid,elevator.permission))
end
local function nearby(src,elevator)
    local ped=GetPlayerPed(src); if not ped or ped==0 then return false end
    local p=GetEntityCoords(ped)
    for _,point in pairs(elevator.blips or {}) do
        if (p.x-point[1])^2+(p.y-point[2])^2+(p.z-point[3])^2<=9 then return true end
    end
    return false
end
local function deny(src,message) TriggerClientEvent('Notify',src,'negado',message,5000) end
RegisterNetEvent(prefix..'config',function()
    local src=source
    local entries={}
    for key,elevator in pairs(cfg.elevadores)do entries[key]={blips=elevator.blips}end
    TriggerClientEvent(prefix..'config',src,entries)
end)
RegisterNetEvent(prefix..'open',function(elevatorId)
    local src=source; elevatorId=id(elevatorId)
    local elevator=elevatorId and cfg.elevadores[elevatorId]
    if not elevator then return end
    local now=GetGameTimer(); if cooldowns[src] and now-cooldowns[src]<500 then return end
    cooldowns[src]=now
    if not allowed(src,elevator) then deny(src,'Não tem permissão para este elevador.');return end
    if not nearby(src,elevator) then deny(src,'Aproxime-se do elevador.');return end
    local floors={}
    for floorId,floor in pairs(elevator.andares or {})do floors[#floors+1]={id=floorId,name=tostring(floor.text)}end
    table.sort(floors,function(a,b)return a.id<b.id end)
    sessions[src]={elevatorId=elevatorId,expires=now+60000}
    TriggerClientEvent(prefix..'open',src,elevatorId,floors)
end)
RegisterNetEvent(prefix..'close',function() sessions[source]=nil end)
RegisterNetEvent(prefix..'travel',function(elevatorId,floorId)
    local src=source; elevatorId,floorId=id(elevatorId),id(floorId)
    local session=sessions[src]; sessions[src]=nil
    if not session or session.elevatorId~=elevatorId or GetGameTimer()>session.expires then return end
    local elevator=cfg.elevadores[elevatorId];local floor=elevator and elevator.andares[floorId]
    if not floor or not allowed(src,elevator) or not nearby(src,elevator) then
        deny(src,'Viagem recusada. Abra novamente o elevador junto ao ponto.');return
    end
    TriggerClientEvent(prefix..'travel',src,floor.tp_coords)
end)
AddEventHandler('playerDropped',function()sessions[source]=nil;cooldowns[source]=nil end)
print('[MaraltoElevadores] Núcleo vRP independente carregado.')
