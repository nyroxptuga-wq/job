'use strict';
(() => {
    const root = document.getElementById('root');
    const bell = new Audio('bell.ogg');
    bell.volume = 0.2;
    let busy = false;
    const send = async (data) => {
        if (busy) return;
        busy = true;
        try {
            const response = await fetch(`https://${GetParentResourceName()}/UIRequest`, {
                method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)
            });
            if (!response.ok) throw new Error('NUI ' + response.status);
        } catch (error) { console.error('[Elevadores]', error); }
        finally { busy = false; }
    };
    window.addEventListener('message', ({data}) => {
        if (!data || typeof data !== 'object') return;
        if (data.action === 'close') { root.style.display = 'none'; root.replaceChildren(); }
        if (data.action === 'bell') { bell.currentTime = 0; bell.play().catch(() => {}); }
        if (data.action !== 'openElevator' || !data.andares) return;
        root.replaceChildren();
        const container = document.createElement('div'); container.className = 'container';
        const title = document.createElement('h6'); title.textContent = 'Elevador'; container.append(title);
        const floors = document.createElement('div'); floors.className = 'andares'; container.append(floors);
        Object.values(data.andares).forEach(floor => {
            if (!floor || floor.id == null || floor.name == null) return;
            const button = document.createElement('button'); button.className = 'andar';
            button.textContent = String(floor.name);
            button.onclick = () => send({action: 'teleport', elevatorId: data.elevatorId, andarId: floor.id});
            floors.append(button);
        });
        root.append(container); root.style.display = 'block';
    });
    document.addEventListener('keyup', event => {
        if (event.key === 'Escape' && root.style.display !== 'none') send({action: 'close'});
    });
})();
