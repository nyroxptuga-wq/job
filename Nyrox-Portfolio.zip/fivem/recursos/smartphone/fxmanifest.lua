fx_version 'cerulean'
game 'gta5'
version '1.1.0'

dependency 'vrp'

server_script 'server.js'
client_scripts {
    '@vrp/lib/utils.lua',
    'compat.lua',
    'client.lua'
}

ui_page 'index.html'
files {
    'index.html',
    'app.js',
    'nui.js',
    'bootstrap.js',
    'styles.css'
}
