const test=require('node:test'),assert=require('node:assert/strict');
const {createBackend}=require('../lib/backend');
function fixture(opts={}) {
 const replies=[],calls=[];
 const methods=Object.assign(Object.create(null),{ok:async(s,...a)=>{calls.push([s,...a]);return {ok:true}},empty:()=>undefined,bad:()=>{throw new Error('database failed')}});
 const backend=createBackend({methods,isReady:()=>true,respond:(...a)=>replies.push(a),userId:async()=>1,sleep:ms=>new Promise(r=>setTimeout(r,ms)),log:()=>{},...opts});
 return {backend,replies,calls,methods};
}
test('valid request and Lua positional table',async()=>{
 const f=fixture();await f.backend.request(10,1,'ok',{'1':'hello','2':20});assert.deepEqual(f.calls,[[10,'hello',20]]);assert.deepEqual(f.replies[0],[10,1,{ok:true}]);
});
test('null result uses legacy marker',async()=>{
 const f=fixture();await f.backend.request(10,1,'empty',[]);assert.deepEqual(f.replies[0][2],{__null__:true});
});
test('unknown and inherited methods are rejected',async()=>{
 const f=fixture();for(const name of ['__proto__','constructor','toString','missing']) await f.backend.request(10,1,name,[]);
 assert.equal(f.replies.length,4);assert(f.replies.every(r=>r[2].error));assert.equal(f.calls.length,0);
});
test('null, nonnumeric keys, sparse overflow, too many arguments and large payloads',async()=>{
 const f=fixture();for(const args of [null,{foo:1},{'99999999':1},Array(33).fill(1),['x'.repeat(131073)]]) await f.backend.request(10,1,'ok',args);
 assert.equal(f.replies.length,5);assert(f.replies.every(r=>r[2].error));assert.equal(f.calls.length,0);
});
test('exceptions respond and release the queue',async()=>{
 const f=fixture();await f.backend.request(10,1,'bad',[]);await f.backend.request(10,2,'ok',[]);assert(f.replies[0][2].error);assert.equal(f.calls.length,1);
});
test('readiness waits are bounded',async()=>{
 let now=0;const f=fixture({isReady:()=>false,now:()=>now,sleep:async ms=>{now+=ms}});
 await f.backend.request(10,1,'ok',[]);assert(f.replies[0][2].error);assert.equal(f.calls.length,0);
});
test('unidentified users cannot call methods',async()=>{
 const f=fixture({userId:async()=>null});await f.backend.request(10,1,'ok',[]);assert(f.replies[0][2].error);assert.equal(f.calls.length,0);
});
test('disconnection suppresses stale responses, even if source is reused',async()=>{
 const f=fixture();let resolve;
 f.methods.slow=()=>new Promise(r=>{resolve=r});
 const old=f.backend.request(10,1,'slow',[]);await Promise.resolve();await Promise.resolve();f.backend.drop(10);
 await f.backend.request(10,2,'ok',[]);resolve('old');await old;
 assert.equal(f.replies.length,1);assert.equal(f.replies[0][1],2);
});
test('rate limit responds without dropping the player',async()=>{
 const f=fixture({now:()=>1000});for(let i=0;i<61;i++) await f.backend.request(10,i,'ok',[]);
 assert.equal(f.calls.length,60);assert(f.replies[60][2].error);
});
