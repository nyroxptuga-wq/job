const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),test=require('node:test'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
test('NUI routes use HTTPS and the actual resource name',()=>{
 const ctx={AbortSignal:{timeout(){}},GetParentResourceName:()=> 'smartphone',encodeURIComponent};vm.createContext(ctx);
 vm.runInContext(fs.readFileSync(path.join(root,'nui.js'),'utf8'),ctx);
 assert.equal(ctx.phoneNuiUrl('client'),'https://smartphone/client');
});
test('bootstrap loads local app once and replays early messages',()=>{
 const listeners={},scripts=[],dispatched=[];const status={hidden:true};
 const window={addEventListener:(name,fn)=>listeners[name]=fn,dispatchEvent:e=>dispatched.push(e.data)};
 const ctx={window,console,document:{getElementById:()=>status,createElement:()=>({}),head:{appendChild:s=>scripts.push(s)}},MessageEvent:class{constructor(type,args){Object.assign(this,args)}}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'bootstrap.js'),'utf8'),ctx);
 listeners.message({data:{safeEval:'authorizedClientLoader'}});
 listeners.message({data:{event:'pusher',args:['READY']}});
 assert.equal(scripts.length,1);assert.equal(scripts[0].src,'app.js');
 scripts[0].onload();assert.equal(dispatched.length,2);assert.equal(ctx.safeEval,'authorizedClientLoader');
 listeners.message({data:{event:'later'}});assert.equal(scripts.length,1);
});
test('bootstrap reports local app load failure',()=>{
 const listeners={},scripts=[],status={};const window={addEventListener:(name,fn)=>listeners[name]=fn};
 const ctx={window,console,document:{getElementById:()=>status,createElement:()=>({}),head:{appendChild:s=>scripts.push(s)}}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'bootstrap.js'),'utf8'),ctx);
 listeners.message({data:{}});scripts[0].onerror();assert.equal(status.hidden,false);assert.match(status.textContent,/Não foi possível/);
});
