import ctypes,os
from pathlib import Path
root=Path(__file__).resolve().parent.parent
os.chdir(root)
lua=ctypes.CDLL('liblua5.4.so.0')
lua.luaL_newstate.restype=ctypes.c_void_p
lua.luaL_openlibs.argtypes=[ctypes.c_void_p]
lua.luaL_loadfilex.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
lua.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
lua.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lua.lua_tolstring.restype=ctypes.c_char_p
lua.lua_close.argtypes=[ctypes.c_void_p]
for file in root.glob('*.lua'):
 state=lua.luaL_newstate()
 if lua.luaL_loadfilex(state,str(file).encode(),None): raise RuntimeError(lua.lua_tolstring(state,-1,None).decode())
 lua.lua_close(state); print('Syntax OK:',file.name)
state=lua.luaL_newstate();lua.luaL_openlibs(state)
code=lua.luaL_loadfilex(state,b'tests/compat_test.lua',None)
if not code: code=lua.lua_pcallk(state,0,0,0,0,None)
if code: raise RuntimeError(lua.lua_tolstring(state,-1,None).decode())
lua.lua_close(state)
