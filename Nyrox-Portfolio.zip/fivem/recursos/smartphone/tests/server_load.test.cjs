const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
function load() {
 const events={},network={},exported={},logs=[];
 const config=JSON.parse(fs.readFileSync(path.join(root,'config.json')));
 const exports=Object.assign((name,fn)=>{exported[name]=fn},{oxmysql:{query_async:async()=>[]}});
 const state={console:{log(){},error:(...a)=>logs.push(a)},Buffer,process:{hrtime:()=>[0,1],title:'test',env:{PATH:''}},exports,
  require:name=>name==='./config.json'||name==='./config'?config:name.startsWith('./lib/')?require(path.join(root,name)):require(name),
  GetCurrentResourceName:()=> 'smartphone',GetResourceState:()=> 'started',GetResourceMetadata:()=> '2.12.0',
  LoadResourceFile:(_r,file)=>fs.readFileSync(path.join(root,file),'utf8'),SaveResourceFile(){},
  RegisterCommand(){},on:(name,fn)=>{events[name]=fn},onNet:(name,fn)=>{network[name]=fn},emit(){},emitNet(){},
  setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,setImmediate:()=>1,GetConvar:()=>'',GetHashKey:()=>123,
  StopResource(){},GetGameTimer:()=>10};
 state.global=state;state.globalThis=state;vm.createContext(state);
 const code=fs.readFileSync(path.join(root,'server.js'),'utf8');
 vm.runInContext(code+'\nglobalThis._test={pL,pF,pc,pb,pp,r7,r9};',state,{timeout:2000});
 return {state,events,network,exported,logs};
}
test('server loads without missing injected scripts or native HTTP handler',()=>{
 const f=load();assert.equal(typeof f.network['backend:req'],'function');assert.equal(f.exported.isReady(),false);
 assert.equal(f.state._test.pL.tor_ping,undefined);
 assert.equal(typeof f.state._test.pL.ig_createPost,'function');
});
test('SQL thenables propagate rejected queries',async()=>{
 const f=load();f.state._test.pb.query=async()=>{throw new Error('db unavailable')};
 for (const operation of [q=>q.select('id'),q=>q.insert({id:1}),q=>q.update({id:2}),q=>q.delete(),q=>q.count(),q=>q.exists(),q=>q.sum('id'),q=>q.pluck('id')]) {
  await assert.rejects(Promise.resolve(operation(f.state._test.pc('smartphone_test'))),/db unavailable/);
 }
});

test('PayPal rejects non-finite, fractional and negative amounts before SQL',async()=>{
 const f=load();f.state._test.pp.getUserId=async()=>1;
 let queries=0;f.state._test.pb.query=async()=>{queries++;return []};
 for(const amount of [-1,0,NaN,Infinity,1.5,'invalid']) {
  assert((await f.state._test.pL.paypal_deposit(10,amount)).error);
  assert((await f.state._test.pL.paypal_transfer(10,amount)).error);
  assert((await f.state._test.pL.paypal_send(10,2,amount,'test')).error);
 }
 assert.equal(queries,0);
});
test('PayPal uses the detected table and key',async()=>{
 const f=load();Object.assign(f.state._test.r7,{table:'vrp_user_moneys',key:'user_id'});
 let sql;f.state._test.pb.query=async(q)=>{sql=q;return [{paypal:123}]};
 assert.equal(await f.state._test.r9({user_id:1}),123);
 assert.match(sql,/FROM vrp_user_moneys/);assert.match(sql,/`user_id`/);
});
