local handlers,timers,events={},{},{}
local focus=true
function RegisterNUICallback(name,fn) handlers[name]=fn end
function SetTimeout(_,fn) timers[#timers+1]=fn end
function AddEventHandler(name,fn) events[name]=fn end
function GetCurrentResourceName() return 'smartphone' end
function SetNuiFocus(value) focus=value end
function SetNuiFocusKeepInput() end
function SendNUIMessage() end
dofile('compat.lua')
assert(bit32.band(0xff,0x0f)==15)
assert(bit32.bxor(0xff,0x0f)==240)
assert(bit32.rshift(0x80000000,31)==1)
assert(bit32.arshift(0x80000000,31)==0xffffffff)
assert(bit32.lrotate(0x80000000,1)==1)
assert(bit32.extract(0x12345678,8,8)==0x56)
assert(bit32.replace(0x12345678,0xff,8,8)==0x1234ff78)
RegisterNUICallback('success',function(_,cb) cb({ok=true});cb({ok=false}) end)
local count=0
handlers.success({},function(value) count=count+1;assert(value.ok) end)
for _,timer in ipairs(timers) do timer() end
assert(count==1,'Duplicate callback response')
RegisterNUICallback('error',function() error('expected test failure') end)
handlers.error({},function(value) assert(value.error);count=count+1 end)
assert(count==2,'Error must be acknowledged')
RegisterNUICallback('pending',function() end)
handlers.pending({},function(value) assert(value.error);count=count+1 end)
timers[#timers]()
assert(count==3,'Unanswered callback timeout')
events.onResourceStop('smartphone');assert(not focus,'Focus released on stop')
print('LUA COMPATIBILITY TESTS PASSED')
