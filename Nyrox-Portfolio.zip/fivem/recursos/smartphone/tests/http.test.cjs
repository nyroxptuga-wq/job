const test=require('node:test'),assert=require('node:assert/strict'),http=require('node:http');
const {request}=require('../lib/http');
let server,url;
test.before(async()=>{
 server=http.createServer((req,res)=>{
  if(req.url==='/bad'){res.writeHead(200,{'content-type':'application/json'});res.end('{broken');return;}
  if(req.url==='/denied'){res.writeHead(401);res.end('denied');return;}
  if(req.url==='/empty'){res.writeHead(204,{'content-type':'application/json'});res.end();return;}
  let body='';req.on('data',c=>body+=c);req.on('end',()=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({body,method:req.method}));});
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));url=`http://127.0.0.1:${server.address().port}`;
});
test.after(()=>new Promise(r=>server.close(r)));
test('HTTP serializes JSON with no headers supplied',async()=>{const r=await request(url,{method:'POST',body:{hello:'olá'}});assert.equal(JSON.parse(r.data.body).hello,'olá');assert.equal(r.data.method,'POST');});
test('malformed JSON rejects without crashing',()=>assert.rejects(request(url+'/bad'),/JSON inválida/));
test('HTTP authentication failure rejects',()=>assert.rejects(request(url+'/denied'),/401/));
test('empty JSON response is supported',async()=>assert.equal((await request(url+'/empty')).data,null));
test('unsupported URL scheme rejects',()=>assert.rejects(request('file:///etc/passwd'),/Protocolo/));
