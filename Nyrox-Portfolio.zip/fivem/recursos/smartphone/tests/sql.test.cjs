const test=require('node:test'),assert=require('node:assert/strict');
const {query}=require('../lib/sql');
const env=(exports,started=true)=>({exports,GetResourceState:()=>started?'started':'stopped',GetResourceMetadata:()=> '2.12.0'});
test('oxmysql returns rows',async()=>assert.deepEqual(await query('oxmysql','SELECT ?',[1],env({oxmysql:{query_async:async()=>[{id:1}]}})),[{id:1}]));
test('oxmysql errors reject',async()=>assert.rejects(query('oxmysql','SELECT ?',[],env({oxmysql:{query_async:async()=>{throw new Error('SQL failure')}}})),/SQL failure/));
test('missing driver rejects immediately',async()=>assert.rejects(query('oxmysql','SELECT 1',[],env({},false)),/Inicie/));
test('unsupported driver rejects',async()=>assert.rejects(query('fake','SELECT 1',[],env({})),/não suportado/));
test('legacy named placeholders are converted',async()=>{
 let received;const db=env({ghmattimysql:{execute:(...a)=>{received=a.slice(0,2);a[2]([])}}});
 await query('ghmattimysql','SELECT ? AS a, ? AS b',[10,20],db);assert.deepEqual(received,['SELECT @1 AS a, @2 AS b',{'@1':10,'@2':20}]);
});
test('non-array parameters reject',async()=>assert.rejects(query('oxmysql','SELECT 1',{},env({})),/lista/));
