'use strict';
function phoneNuiUrl(path) {
 if (typeof GetParentResourceName !== 'function') throw new Error('Esta interface deve abrir dentro do FiveM.');
 return `https://${GetParentResourceName()}/${encodeURIComponent(path)}`;
}
if (typeof AbortSignal.timeout!=='function') {
 AbortSignal.timeout=function(ms) {const c=new AbortController();setTimeout(()=>c.abort(),ms);return c.signal;};
}
