-- Lua 5.4 no longer ships bit32. Retain the legacy 32-bit API when absent.
if not bit32 then
 local mask=0xffffffff
 local function bits(value) return math.tointeger(value) & mask end
 bit32={}
 function bit32.band(...) local r=mask; for i=1,select('#',...) do r=r & bits(select(i,...)) end; return r end
 function bit32.bor(...) local r=0; for i=1,select('#',...) do r=r | bits(select(i,...)) end; return r end
 function bit32.bxor(...) local r=0; for i=1,select('#',...) do r=r ~ bits(select(i,...)) end; return r end
 function bit32.bnot(value) return (~bits(value)) & mask end
 function bit32.btest(...) return bit32.band(...)~=0 end
 function bit32.lshift(value,n)
  if n<0 then return bit32.rshift(value,-n) end
  return n>=32 and 0 or (bits(value)<<n) & mask
 end
 function bit32.rshift(value,n)
  if n<0 then return bit32.lshift(value,-n) end
  return n>=32 and 0 or bits(value)>>n
 end
 function bit32.arshift(value,n)
  if n<0 then return bit32.lshift(value,-n) end
  local v=bits(value)
  if (v & 0x80000000)==0 then return bit32.rshift(v,n) end
  if n>=32 then return mask end
  return ((v>>n) | (mask << (32-n))) & mask
 end
 function bit32.lrotate(value,n)
  n=n%32; local v=bits(value)
  return ((v<<n) | (v>>(32-n))) & mask
 end
 function bit32.rrotate(value,n) return bit32.lrotate(value,-n) end
 local function fieldmask(field,width)
  width=width or 1
  assert(field>=0 and width>0 and field+width<=32,'invalid bit field')
  return (1<<width)-1,width
 end
 function bit32.extract(value,field,width)
  local m=fieldmask(field,width); return (bits(value)>>field) & m
 end
 function bit32.replace(value,replacement,field,width)
  local m=fieldmask(field,width)
  return ((bits(value) & (~(m<<field))) | ((bits(replacement) & m)<<field)) & mask
 end
end

-- Runs before the supplied packed client. Its original logic is preserved.
local original = RegisterNUICallback
RegisterNUICallback = function(name, handler)
 original(name, function(data, cb)
  local completed=false
  local function respond(value)
   if completed then return end
   completed=true
   cb(value == nil and {} or value)
  end
  -- Prompt/confirm can legitimately wait for the user.
  if name~='prompt' and name~='confirm' then
   SetTimeout(40000,function()
    respond({error='Tempo de resposta excedido. Verifique a consola F8.'})
   end)
  end
  local ok,err=pcall(handler,data,respond)
  if not ok then
   print(('[smartphone] Callback %s: %s'):format(name,tostring(err)))
   respond({error='Não foi possível concluir a operação.'})
  end
 end)
end
AddEventHandler('onResourceStop',function(resource)
 if resource~=GetCurrentResourceName() then return end
 SetNuiFocus(false,false)
 SetNuiFocusKeepInput(false)
 if IsNuiOpen then
  IsNuiOpen=false
  SendNUIMessage({event='close',args={}})
 end
end)
