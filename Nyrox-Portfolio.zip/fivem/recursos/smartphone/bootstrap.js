(function () {
 'use strict';
 let started=false,ready=false;
 const pending=[];
 const status=document.getElementById('load-status');
 function fail(message) {status.textContent=message;status.hidden=false;}
 window.addEventListener('unhandledrejection', event=>console.error('[smartphone] Pedido rejeitado:',event.reason && event.reason.message || event.reason));
 window.addEventListener('message',function init(event) {
  if (event.source && event.source!==window) return;
  if (!event.data || typeof event.data!=='object') return;
  if (ready) return;
  if (pending.length<100) pending.push(event.data);
  if (started) return;
  started=true;
  globalThis.safeEval=typeof event.data.safeEval==='string' ? event.data.safeEval : undefined;
  const script=document.createElement('script');script.src='app.js';
  script.onload=()=>{
   ready=true;status.hidden=true;
   for (const data of pending.splice(0)) window.dispatchEvent(new MessageEvent('message',{data}));
  };
  script.onerror=()=>fail('Não foi possível carregar o smartphone. Confirma os ficheiros e reinicia o recurso.');
  document.head.appendChild(script);
 });
})();
