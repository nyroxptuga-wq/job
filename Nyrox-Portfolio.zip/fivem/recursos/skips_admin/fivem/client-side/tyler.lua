local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
local vRP = Proxy.getInterface("vRP")
local server = Tunnel.getInterface("skips_admin")
local opened = false
local function setOpen(value)
 if opened == value then return end
 opened = value
 SetNuiFocus(value, value)
 SendNUIMessage({action = value and 'showMenu' or 'closeMenu'})
 TriggerEvent('bdl:triggerhud')
 if value then StartScreenEffect('MenuMGSelectionIn',0,true)
 else StopScreenEffect('MenuMGSelectionIn') end
end
local function callback(name, handler)
 RegisterNUICallback(name, function(data, cb)
  local ok, result = pcall(handler, type(data)=='table' and data or {})
  if not ok then
   print('[skips_admin] NUI '..name..': '..tostring(result))
   cb({ok=false,error='Erro na operação. Consulte a consola F8.'})
  elseif type(result)=='table' then cb(result)
  else cb({ok=result==true}) end
 end)
end
local function list(value) return type(value)=='table' and value or {} end
callback('spawnVehicle',function(d) return server.adminSpawnVeh(d.vehicle) end)
callback('killid',function(d) return server.Kill(d.id) end)
callback('ykill',function(d) return server.Kill() end)
callback('killall',function(d) return server.killAll() end)
callback('reviveid',function(d) return server.Revive(d.id) end)
callback('yrevive',function(d) return server.Revive() end)
callback('reviveall',function(d) return server.reviveAll() end)
callback('upgradevehicle',function(d) return server.upgradeVeh() end)
callback('addwl',function(d) return server.addWl(d.id) end)
callback('kickid',function(d) return server.kickSpecified(d.id) end)
callback('kickall',function(d) return server.kickAll() end)
callback('banid',function(d) return server.banSpecified(d.id) end)
callback('unbanid',function(d) return server.unbanSpecified(d.id) end)
callback('removewl',function(d) return server.removeWl(d.id) end)
callback('setUserGroup',function(d) return server.setUserGroup(d.group,d.id) end)
callback('removeUserGroup',function(d) return server.removeUserGroup(d.group,d.id) end)
callback('takeItem',function(d) return server.takeItem(d.item,d.amount) end)
callback('giveItemToID',function(d) return server.giveItem(d.user,d.amount,d.item) end)
callback('clearInv',function(d) return server.clearUserInv(d.id) end)
callback('addToGarage',function(d) return server.addToGarage(d.id,d.veh) end)
callback('remFromGarage',function(d) return server.remFromGarage(d.id,d.veh) end)
callback('TeleportToMe',function(d) return server.teleportToMe(d.id) end)
callback('TPToPlayer',function(d) return server.TeleportToPlayer(d.id) end)
callback('TPWay',function(d) return server.TeleportWaypoint() end)
callback('giveWeaponToPlayer',function(d) return server.giveWeapon(d.weapon,d.id,d.ammo) end)
callback('clearPlayerWeapons',function(d) return server.clearWeapons(d.id) end)
callback('AdminNotify',function(d) return server.AdminNotify(d.specified,d.id,d.message,d.signature) end)
callback('GiveMoney',function(d) return server.GiveMoney(d.place,d.id,d.amount) end)
callback('SetMoney',function(d) return server.SetMoney(d.place,d.id,d.amount) end)
callback('eraseLog',function(d) return server.EraseLog(d.id) end)
callback('eraseAllLogs',function(d) return server.WipeLogs() end)
callback('requestGroups',function(d) local value=server.GetGroups(); return { groups=list(value), ok=type(value)=='table' } end)
callback('requestVehicles',function(d) local value=server.GetVehiclesList(); return { vehicle=list(value), ok=type(value)=='table' } end)
callback('requestItemList',function(d) local value=server.GetItemList(); return { item=list(value), ok=type(value)=='table' } end)
callback('requestPlayers',function(d) local value=server.GetOnlinePlayers(); return { players=list(value), ok=type(value)=='table' } end)
callback('requestWeapons',function(d) local value=server.getWeapons(d.type); return { weapons=list(value), ok=type(value)=='table' } end)
callback('GetMoneyList',function(d) local value=server.GetUserMoney(); return { moneys=list(value), ok=type(value)=='table' } end)
callback('GetLogs',function(d) local value=server.GetPanelLogs(); return { all_logs=list(value), ok=type(value)=='table' } end)
callback('GetWhitelisted',function(d) local value=server.GetWhitelisted(); return { whitelisted=list(value), ok=type(value)=='table' } end)
callback('GetNonWhitelisted',function(d) local value=server.GetNonWhitelisted(); return { non_whitelisted=list(value), ok=type(value)=='table' } end)
callback('getSpecifiedPlayer',function(d)
 local first,last,state=server.getSpecifiedPlayer(d.id)
 return {name=first or '',lastname=last or '',state=state==true}
end)
callback('GetPlayerInfos',function(d)
 local first,last=server.GetPlayerInfos(d.id)
 return {name=first or '',lastname=last or ''}
end)
callback('GetPlayerCoords',function()
 local coords=server.GetEntityCoords()
 return {coords=coords or '',heading=math.floor(GetEntityHeading(PlayerPedId())*100)/100,ok=type(coords)=='string'}
end)
for _,entry in ipairs({{'TryGiveMoney','GiveMoney'},{'TrySetMoney','SetMoney'}}) do
 local name,method=entry[1],entry[2]
 callback(name,function(d)
  local result=server[method](d.place,d.id,d.amount)
  return {state=result==true,ok=result==true}
 end)
end
callback('CheckOnlinePlayer',function(d) return {state=server.CheckPlayer(d.id)==true} end)
callback('checkPermission',function(d) return {isAllowed=server.VerifyPerm(d.action)==true} end)
local management={groups='manage_groups',items='manage_items',vehicles='manage_vehicles',players='manage_players',notify='manage_notify',coordinates='get_coordinates'}
callback('checkManagementPerm',function(d) return {isAllowed=server.VerifyPerm(management[d.action] or d.action)==true} end)
callback('TriggerUI',function() setOpen(false); return true end)
callback('TriggerTicketUI',function() return false end)
RegisterCommand(config.openCommand,function()
 if opened then setOpen(false)
 elseif server.checkGlobalPermission() then setOpen(true)
 else TriggerEvent('Notify','negado','Sem permissão para abrir o painel.',6000) end
end)
AddEventHandler('onResourceStop',function(resource)
 if resource~=GetCurrentResourceName() then return end
 if opened then setOpen(false) end
end)

RegisterNetEvent('skips_admin:spawnVehicle',function(model,plate)
 if source~=65535 then return end
 local hash=GetHashKey(model)
 if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then
  TriggerEvent('Notify','negado','Modelo de veículo inválido.',6000); return
 end
 RequestModel(hash)
 local deadline=GetGameTimer()+10000
 while not HasModelLoaded(hash) and GetGameTimer()<deadline do Wait(50) end
 if not HasModelLoaded(hash) then
  SetModelAsNoLongerNeeded(hash)
  TriggerEvent('Notify','negado','O veículo não carregou dentro do prazo.',6000); return
 end
 local ped=PlayerPedId()
 local coords=GetOffsetFromEntityInWorldCoords(ped,0.0,4.0,0.0)
 local vehicle=CreateVehicle(hash,coords.x,coords.y,coords.z,GetEntityHeading(ped),true,false)
 if vehicle~=0 then
  if type(plate)=='string' then SetVehicleNumberPlateText(vehicle,plate:sub(1,8)) end
  SetVehicleOnGroundProperly(vehicle); SetPedIntoVehicle(ped,vehicle,-1)
  SetVehicleEngineOn(vehicle,true,true,false)
 end
 SetModelAsNoLongerNeeded(hash)
end)
RegisterNetEvent('skips_admin:waypoint',function()
 if source~=65535 then return end
 if not IsWaypointActive() then TriggerEvent('Notify','negado','Waypoint não encontrado.',6000); return end
 local ped=PlayerPedId()
 local entity=IsPedInAnyVehicle(ped,false) and GetVehiclePedIsIn(ped,false) or ped
 local previous=GetEntityCoords(entity)
 local coords=GetBlipInfoIdCoord(GetFirstBlipInfoId(8))
 FreezeEntityPosition(entity,true)
 local found,z=false,0.0
 for height=1000.0,0.0,-50.0 do
  SetEntityCoordsNoOffset(entity,coords.x,coords.y,height,false,false,false)
  RequestCollisionAtCoord(coords.x,coords.y,height)
  Wait(50)
  found,z=GetGroundZFor_3dCoord(coords.x,coords.y,height,false)
  if found then break end
 end
 if found then SetEntityCoordsNoOffset(entity,coords.x,coords.y,z+1.0,false,false,false)
 else
  SetEntityCoordsNoOffset(entity,previous.x,previous.y,previous.z,false,false,false)
  TriggerEvent('Notify','negado','Não foi possível localizar solo seguro.',6000)
 end
 FreezeEntityPosition(entity,false)
end)
RegisterNetEvent("skips_admin:tuning")
AddEventHandler("skips_admin:tuning",function(vehicle)
    if source ~= 65535 then return end
	local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    
	if IsEntityAVehicle(vehicle) then
		SetVehicleModKit(vehicle,0)
		SetVehicleWheelType(vehicle,7)
		SetVehicleMod(vehicle,0,GetNumVehicleMods(vehicle,0)-1,false)
		SetVehicleMod(vehicle,1,GetNumVehicleMods(vehicle,1)-1,false)
		SetVehicleMod(vehicle,2,GetNumVehicleMods(vehicle,2)-1,false)
		SetVehicleMod(vehicle,3,GetNumVehicleMods(vehicle,3)-1,false)
		SetVehicleMod(vehicle,4,GetNumVehicleMods(vehicle,4)-1,false)
		SetVehicleMod(vehicle,5,GetNumVehicleMods(vehicle,5)-1,false)
		SetVehicleMod(vehicle,6,GetNumVehicleMods(vehicle,6)-1,false)
		SetVehicleMod(vehicle,7,GetNumVehicleMods(vehicle,7)-1,false)
		SetVehicleMod(vehicle,8,GetNumVehicleMods(vehicle,8)-1,false)
		SetVehicleMod(vehicle,9,GetNumVehicleMods(vehicle,9)-1,false)
		SetVehicleMod(vehicle,10,GetNumVehicleMods(vehicle,10)-1,false)
		SetVehicleMod(vehicle,11,GetNumVehicleMods(vehicle,11)-1,false)
		SetVehicleMod(vehicle,12,GetNumVehicleMods(vehicle,12)-1,false)
		SetVehicleMod(vehicle,13,GetNumVehicleMods(vehicle,13)-1,false)
		SetVehicleMod(vehicle,14,16,false)
		SetVehicleMod(vehicle,15,GetNumVehicleMods(vehicle,15)-2,false)
		SetVehicleMod(vehicle,16,GetNumVehicleMods(vehicle,16)-1,false)
		ToggleVehicleMod(vehicle,17,true)
		ToggleVehicleMod(vehicle,18,true)
		ToggleVehicleMod(vehicle,19,true)
		ToggleVehicleMod(vehicle,20,true)
		ToggleVehicleMod(vehicle,21,true)
		ToggleVehicleMod(vehicle,22,true)
		SetVehicleMod(vehicle,23,1,false)
		SetVehicleMod(vehicle,24,1,false)
		SetVehicleMod(vehicle,25,GetNumVehicleMods(vehicle,25)-1,false)
		SetVehicleMod(vehicle,27,GetNumVehicleMods(vehicle,27)-1,false)
		SetVehicleMod(vehicle,28,GetNumVehicleMods(vehicle,28)-1,false)
		SetVehicleMod(vehicle,30,GetNumVehicleMods(vehicle,30)-1,false)
		SetVehicleMod(vehicle,33,GetNumVehicleMods(vehicle,33)-1,false)
		SetVehicleMod(vehicle,34,GetNumVehicleMods(vehicle,34)-1,false)
		SetVehicleMod(vehicle,35,GetNumVehicleMods(vehicle,35)-1,false)
		SetVehicleMod(vehicle,38,GetNumVehicleMods(vehicle,38)-1,true)
		SetVehicleTyreSmokeColor(vehicle,0,0,127)
		SetVehicleWindowTint(vehicle,1)
		SetVehicleTyresCanBurst(vehicle,false)
		--SetVehicleNumberPlateText(vehicle,"FiveM Brasil")
		SetVehicleNumberPlateTextIndex(vehicle,5)
		SetVehicleModColor_1(vehicle,4,12,0)
		SetVehicleModColor_2(vehicle,4,12)
		SetVehicleColours(vehicle,12,12)
		SetVehicleExtraColours(vehicle,70,141)
	end
end)



