-- vRP Creative/legacy adapter. Every public Tunnel method is checked server-side.
local Tunnel = module('vrp', 'lib/Tunnel')
local Proxy = module('vrp', 'lib/Proxy')
local vRP = Proxy.getInterface('vRP')
local vRPclient = Tunnel.getInterface('vRP')
local api = {}
local ready = false
local rates = {}
local permissions = {
 spawn_veh='perm_QuickActions_SpawnVeh', kill='perm_QuickActions_Kill',
 kill_all='perm_QuickActions_KillAll', revive='perm_QuickActions_Revive',
 revive_all='perm_QuickActions_ReviveAll', upgrade_veh='perm_QuickActions_UpgradeVeh',
 wl_manage='perm_QuickActions_WLManage', ban_manage='perm_QuickActions_BanManage',
 kick_id='perm_QuickActions_KickID', kick_all='perm_QuickActions_KickAll',
 manage_groups='perm_GroupManagement', manage_items='perm_ItemManagement',
 manage_vehicles='perm_VehicleManagement', manage_players='perm_PlayerManagement',
 manage_notify='perm_NotifyPlayers', get_coordinates='perm_GetCoordinates',
 teleport='perm_TeleportPlayer', weapons='perm_WeaponManagement', money='perm_MoneyManagement',
 see_logs='perm_SeeLogs', edit_logs='perm_EditLogs'
}
local function integer(value, minimum, maximum)
 local n = tonumber(value)
 if not n or n ~= n or n == math.huge or n == -math.huge or n % 1 ~= 0 then return nil end
 if n < (minimum or 1) or n > (maximum or 2147483647) then return nil end
 return n
end
local function required(value, message)
 if value == nil or value == false then error(message or 'Dados inválidos.', 0) end
 return value
end
local function id(value) return required(integer(value), 'ID inválido.') end
local function key(value)
 return required(type(value)=='string' and #value<=80 and value:match('^[%w_%.%-]+$'), 'Identificador inválido.')
end
local function escape(value)
 return tostring(value or ''):gsub('&','&amp;'):gsub('<','&lt;'):gsub('>','&gt;'):gsub('"','&quot;'):gsub("'",'&#39;')
end
local function identity(uid)
 local data = vRP.getUserIdentity(uid) or {}
 return data.name or 'Desconhecido', data.firstname or '', data
end
local function notify(s, message) TriggerClientEvent('Notify', s, 'negado', escape(message), 6000) end
local function allowed(uid, action)
 if not uid or not vRP.hasPermission(uid,config.globalPerm) then return false end
 if not action then return true end
 local list = config[permissions[action] or '']
 if type(list) ~= 'table' then return false end
 for _,entry in pairs(list) do
  if type(entry)=='table' and type(entry[1])=='string' and vRP.hasPermission(uid, entry[1]) then return true end
 end
 return false
end
local function audit(uid, message)
 local first,last = identity(uid)
 vRP.execute('aurora/insert_log', {user_id=uid, user_name=first..' '..last, action=message:sub(1,250), hour=os.date('%H:%M:%S')})
end
local function online(value, fallback)
 local uid = (value==nil or value=='') and fallback or id(value)
 required(uid, 'ID em falta.')
 return uid, required(vRP.getUserSource(uid), 'Jogador indisponível ou offline.')
end
local function expose(name, permission, fn, needsDB)
 api[name] = function(...)
  local s = source
  local uid = vRP.getUserId(s)
  if not allowed(uid, permission) then return false end
  local now = os.time()
  local rate = rates[s]
  if not rate or rate.time ~= now then rate={time=now,count=0}; rates[s]=rate end
  rate.count=rate.count+1
  if rate.count>60 then return false end
  if needsDB and not ready then notify(s,'Base de dados indisponível. Consulte a consola.'); return false end
  local result = table.pack(pcall(fn, s, uid, ...))
  if not result[1] then
   print(('[skips_admin] %s (ID %s): %s'):format(name,tostring(uid),tostring(result[2])))
   notify(s, 'Não foi possível concluir a operação. Verifique os dados e a consola.')
   return false
  end
  return table.unpack(result,2,result.n)
 end
end
local function query(name,params) return vRP.query(name,params or {}) or {} end
local function groupList()
 local loaded = module('vrp','cfg/groups')
 return type(loaded)=='table' and (loaded.groups or loaded) or {}
end
local function groups()
 local output = {}
 for name,data in pairs(groupList()) do
  if type(data)=='table' and type(data._config)=='table' then
   for _,entry in ipairs(config.allowedGtype or {}) do
    if data._config.gtype==entry[1] then
     output[#output+1]={k=name,name=data._config.title or name}; break
    end
   end
  end
 end
 return output
end
local function groupKey(value)
 value=key(value)
 for _,entry in ipairs(groups()) do if entry.k==value then return value end end
 error('Grupo não permitido.',0)
end
local function weaponKey(value)
 value=key(value)
 for _,entry in ipairs(config.allowedWeapons or {}) do if entry.id==value then return value end end
 error('Arma não permitida.',0)
end
local function vehicleList()
 -- This export is provided by the original Creative base. Other bases can use config.vehicles.
 return config.vehicles or vRP.vehicleGlobal() or {}
end
local function vehicleKey(value)
 value=key(value)
 required(vehicleList()[value], 'Veículo não configurado na base.')
 return value
end
CreateThread(function()
 local ok,err=pcall(function()
  vRP.prepare('aurora/admin_log', [[CREATE TABLE IF NOT EXISTS au_admin_log (
   id INTEGER AUTO_INCREMENT PRIMARY KEY, user_id INTEGER, user_name VARCHAR(255),
   action VARCHAR(255), hour VARCHAR(255), data VARCHAR(255))]])
  vRP.prepare('aurora/insert_log', "INSERT INTO au_admin_log(user_id,user_name,action,hour,data) VALUES(@user_id,@user_name,@action,@hour,DATE_FORMAT(CURDATE(),'%d/%m/%Y'))")
  vRP.prepare('aurora/rem_log','DELETE FROM au_admin_log WHERE id=@id')
  vRP.prepare('aurora/rem_all_logs','DELETE FROM au_admin_log')
  vRP.prepare('aurora/get_logs','SELECT * FROM au_admin_log ORDER BY id DESC LIMIT 1000')
  vRP.prepare('aurora/get_user_money','SELECT user_id,wallet,bank FROM vrp_user_moneys')
  vRP.prepare('aurora/get_users','SELECT id,whitelisted FROM vrp_users')
  vRP.prepare('aurora/get_user_identity','SELECT name,firstname FROM vrp_user_identities WHERE user_id=@user_id')
  vRP.prepare('aurora/add_vehicle',config.garageAddQuery)
  vRP.prepare('aurora/rem_vehicle',config.garageRemoveQuery)
  vRP.execute('aurora/admin_log')
  vRP.prepare('aurora/migrate_logs','ALTER TABLE au_admin_log MODIFY COLUMN action VARCHAR(255)')
  vRP.execute('aurora/migrate_logs')
 end)
 ready=ok
 if not ok then print('[skips_admin] Erro na inicialização SQL: '..tostring(err)) end
end)
expose('checkGlobalPermission',nil,function() return true end)
expose('checkAuth',nil,function() return true end)
expose('VerifyPerm',nil,function(_,uid,action) return allowed(uid,action) and permissions[action]~=nil end)
expose('GetGroups','manage_groups',function() return groups() end)
expose('GetItemList','manage_items',function()
 local output={}
 for name,data in pairs(config.itens or {}) do output[#output+1]={k=name,name=data.name or name,item_directory=config.ItemDirectory} end
 return output
end)
expose('GetVehiclesList','manage_vehicles',function()
 local output={}
 for name,data in pairs(vehicleList()) do output[#output+1]={k=name,name=data.name or name,tipo=data.tipo or '',vehicle_directory=config.VehicleDirectory} end
 return output
end)
expose('getWeapons','weapons',function(_,_,category)
 local output={}
 for _,data in ipairs(config.allowedWeapons or {}) do
  if category=='all' or category==data.type then output[#output+1]={weapon_id=data.id,weapon_name=data.index,weapon_type=data.type,weapon_directory=config.WeaponDirectory} end
 end
 return output
end)
expose('GetOnlinePlayers','manage_players',function()
 local output={}
 for uid in pairs(vRP.getUsers() or {}) do
  local first,last=identity(uid)
  output[#output+1]={k=uid,uname=first,ulname=last}
 end
 return output
end)
expose('GetUserMoney','money',function()
 local output={}
 for _,row in ipairs(query('aurora/get_user_money')) do
  local wallet,bank=tonumber(row.wallet) or 0,tonumber(row.bank) or 0
  output[#output+1]={u_id=row.user_id,wallet=wallet,bank=bank,total=wallet+bank}
 end
 return output
end,true)
expose('GetPanelLogs','see_logs',function()
 local output={}
 for _,row in ipairs(query('aurora/get_logs')) do
  output[#output+1]={log_id=row.id,u_id=row.user_id,u_name=row.user_name,log=row.action,data=row.data,hour=row.hour}
 end
 return output
end,true)
for _,yes in ipairs({true,false}) do
 local selected=yes
 expose(selected and 'GetWhitelisted' or 'GetNonWhitelisted','wl_manage',function()
  local output={}
  for _,row in ipairs(query('aurora/get_users')) do
   local state=row.whitelisted==true or row.whitelisted==1 or row.whitelisted=='1'
   if state==selected then output[#output+1]={u_id=row.id,wlstate=state and 'Sim' or 'Não'} end
  end
  return output
 end,true)
end
expose('getSpecifiedPlayer','manage_players',function(_,_,value)
 local uid=id(value)
 local first,last=identity(uid)
 return first,last,vRP.getUserSource(uid)~=nil and vRP.getUserSource(uid)~=false
end)
expose('GetPlayerInfos','money',function(_,_,value)
 local rows=query('aurora/get_user_identity',{user_id=id(value)})
 if rows[1] then return rows[1].name,rows[1].firstname end
 return 'Desconhecido',''
end,true)
expose('CheckPlayer','money',function(_,_,value) return vRP.getUserSource(id(value)) and true or false end)
expose('EraseLog','edit_logs',function(_,_,value) vRP.execute('aurora/rem_log',{id=id(value)}); return true end,true)
expose('WipeLogs','edit_logs',function() vRP.execute('aurora/rem_all_logs'); return true end,true)
for _,adding in ipairs({true,false}) do
 local add=adding
 expose(add and 'addToGarage' or 'remFromGarage','manage_vehicles',function(_,uid,target,model)
  target=id(target); model=vehicleKey(model)
  vRP.execute(add and 'aurora/add_vehicle' or 'aurora/rem_vehicle',{user_id=target,vehicle=model,ipva=os.time()})
  audit(uid,('%s garagem ID %s: %s'):format(add and 'Adicionou à' or 'Removeu da',target,model)); return true
 end,true)
end
expose('adminSpawnVeh','spawn_veh',function(s,uid,model)
 model=key(model)
 local _,_,info=identity(uid)
 TriggerClientEvent('skips_admin:spawnVehicle',s,model,info.registration)
 audit(uid,'Criou veículo '..model); return true
end,true)
local function revive(target,uid)
 vRPclient.killGod(target); vRPclient.setHealth(target,config.reviveHealth)
 TriggerClientEvent('resetBleeding',target); TriggerClientEvent('resetDiagnostic',target)
 vRP.varyThirst(uid,-100); vRP.varyHunger(uid,-100)
end
expose('Kill','kill',function(_,uid,value)
 local target,player=online(value,uid); vRPclient.setHealth(player,0)
 audit(uid,'Matou ID '..target); return true
end,true)
expose('Revive','revive',function(_,uid,value)
 local target,player=online(value,uid); revive(player,target)
 audit(uid,'Reviveu ID '..target); return true
end,true)
for _,entry in ipairs({{'killAll','kill_all'},{'reviveAll','revive_all'},{'kickAll','kick_all'}}) do
 local name,permission=entry[1],entry[2]
 expose(name,permission,function(_,uid)
  local snapshot={}
  for target,player in pairs(vRP.getUsers() or {}) do snapshot[#snapshot+1]={target,player} end
  for _,target in ipairs(snapshot) do
   if name=='killAll' then vRPclient.setHealth(target[2],0)
   elseif name=='reviveAll' then revive(target[2],target[1])
   else vRP.kick(target[2],'Reinício administrativo. Volte a entrar mais tarde.') end
  end
  audit(uid,name..' ('..#snapshot..' jogadores)'); return true
 end,true)
end
expose('upgradeVeh','upgrade_veh',function(s,uid)
 TriggerClientEvent('skips_admin:tuning',s); audit(uid,'Melhorou o próprio veículo'); return true
end,true)
for _,entry in ipairs({{'addWl',true},{'removeWl',false},{'banSpecified',true},{'unbanSpecified',false}}) do
 local name,state=entry[1],entry[2]
 local banning=name=='banSpecified' or name=='unbanSpecified'
 expose(name,banning and 'ban_manage' or 'wl_manage',function(_,uid,value)
  local target=id(value)
  if banning then
   vRP.setBanned(target,state)
   local player=vRP.getUserSource(target)
   if state and player then vRP.kick(player,'Foi banido da cidade.') end
  else vRP.setWhitelisted(target,state) end
  audit(uid,name..' ID '..target); return true
 end,true)
end
expose('kickSpecified','kick_id',function(_,uid,value)
 local target,player=online(value); vRP.kick(player,'Foi expulso da cidade.')
 audit(uid,'Expulsou ID '..target); return true
end,true)
for _,adding in ipairs({true,false}) do
 local add=adding
 expose(add and 'setUserGroup' or 'removeUserGroup','manage_groups',function(_,uid,group,value)
  group=groupKey(group); local target=online(value)
  if add then vRP.addUserGroup(target,group) else vRP.removeUserGroup(target,group) end
  audit(uid,('%s grupo %s ID %s'):format(add and 'Adicionou' or 'Removeu',group,target)); return true
 end,true)
end
local function giveItem(uid,target,item,amount)
 item=key(item); required(config.itens[item], 'Item não permitido.')
 amount=required(integer(amount,1,config.maxItemAmount),'Quantidade inválida.')
 vRP.giveInventoryItem(target,item,amount)
 audit(uid,('Deu %s x%s ao ID %s'):format(item,amount,target)); return true
end
expose('takeItem','manage_items',function(_,uid,item,amount) return giveItem(uid,uid,item,amount) end,true)
expose('giveItem','manage_items',function(_,uid,value,amount,item) local target=online(value); return giveItem(uid,target,item,amount) end,true)
expose('clearUserInv','manage_items',function(_,uid,value)
 local target=online(value); local data=required(vRP.getUserDataTable(target),'Inventário indisponível.')
 local snapshot={}
 for item,entry in pairs(data.inventory or {}) do snapshot[#snapshot+1]={item,entry.amount} end
 for _,entry in ipairs(snapshot) do vRP.tryGetInventoryItem(target,entry[1],entry[2]) end
 audit(uid,'Limpou inventário ID '..target); return true
end,true)
expose('teleportToMe','teleport',function(s,uid,value)
 local target,player=online(value); local x,y,z=vRPclient.getPosition(s)
 required(x,'Posição indisponível.'); vRPclient.teleport(player,x,y,z)
 audit(uid,'Puxou ID '..target); return true
end,true)
expose('TeleportToPlayer','teleport',function(s,uid,value)
 local target,player=online(value); local x,y,z=vRPclient.getPosition(player)
 required(x,'Posição indisponível.'); vRPclient.teleport(s,x,y,z)
 audit(uid,'Teleportou-se para ID '..target); return true
end,true)
expose('TeleportWaypoint','teleport',function(s,uid)
 TriggerClientEvent('skips_admin:waypoint',s); audit(uid,'Pediu teleporte ao waypoint'); return true
end,true)
expose('GetEntityCoords','get_coordinates',function(s)
 local x,y,z=vRPclient.getPosition(s)
 required(x,'Posição indisponível.')
 return ("['x'] = %.2f, ['y'] = %.2f, ['z'] = %.2f"):format(x,y,z)
end)
expose('giveWeapon','weapons',function(_,uid,weapon,value,ammo)
 weapon=weaponKey(weapon); ammo=required(integer(ammo,0,config.maxAmmo),'Munições inválidas.')
 local target,player=online(value,uid); vRPclient.giveWeapons(player,{[weapon]={ammo=ammo}})
 audit(uid,('Deu %s x%s ao ID %s'):format(weapon,ammo,target)); return true
end,true)
expose('clearWeapons','weapons',function(_,uid,value)
 local target,player=online(value,uid); vRPclient.replaceWeapons(player,{})
 audit(uid,'Limpou armas ID '..target); return true
end,true)
expose('AdminNotify','manage_notify',function(_,uid,specified,value,message,signature)
 required(type(message)=='string' and #message>0 and #message<=1000,'Mensagem inválida.')
 required(type(signature)=='string' and #signature>0 and #signature<=100,'Assinatura inválida.')
 local target=-1
 if specified==true or specified=='true' then local _,player=online(value); target=player end
 TriggerClientEvent('Notify',target,'aviso',escape(message)..'<br><b>- '..escape(signature)..'</b>',15000)
 audit(uid,'Enviou aviso para '..target); return true
end,true)
for _,setting in ipairs({true,false}) do
 local set=setting
 expose(set and 'SetMoney' or 'GiveMoney','money',function(_,uid,place,value,amount)
  required(place=='bank' or place=='wallet' or place=='money' or place=='hand','Destino inválido.')
  amount=required(integer(amount,set and 0 or 1,config.maxMoneyAmount),'Montante inválido.')
  local target=online(value,uid)
  if place=='bank' then
   if set then vRP.setBankMoney(target,amount) else vRP.giveBankMoney(target,amount) end
  elseif set then vRP.setMoney(target,amount) else vRP.giveMoney(target,amount) end
  audit(uid,('%s %s em %s ao ID %s'):format(set and 'Definiu' or 'Deu',amount,place,target)); return true
 end,true)
end
Tunnel.bindInterface('skips_admin',api)
AddEventHandler('playerDropped',function() rates[source]=nil end)
