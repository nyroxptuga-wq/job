/* FiveM NUI transport. Local dependencies; HTTPS and the actual resource name. */
function nuiUrl(name) { return `https://${GetParentResourceName()}/${name}`; }
function safeHtml(value) {
 return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
(function ($) {
 'use strict';
 let timer;
 function status(message, success = false) {
  let box = document.getElementById('operation-status');
  if (!box) {
   box = document.createElement('div'); box.id = 'operation-status';
   box.setAttribute('role','alert'); document.body.appendChild(box);
  }
  box.textContent = message; box.style.display = 'block';
  box.style.background = success ? '#215c43' : '#852d39';
  clearTimeout(timer); timer = setTimeout(() => { box.style.display = 'none'; }, 7000);
 }
 const originalPost = $.post;
 $.post = function (url, data, success, dataType) {
  if (!String(url).startsWith(`https://${GetParentResourceName()}/`)) return originalPost.apply(this,arguments);
  if (typeof data === 'function') { success = data; data = '{}'; }
  const endpoint = String(url).split('/').pop();
  const mutations = new Set(['spawnVehicle', 'killid', 'ykill', 'killall', 'reviveid', 'yrevive', 'reviveall', 'upgradevehicle', 'addwl', 'kickid', 'kickall', 'banid', 'unbanid', 'removewl', 'setUserGroup', 'removeUserGroup', 'takeItem', 'giveItemToID', 'clearInv', 'addToGarage', 'remFromGarage', 'TeleportToMe', 'TPToPlayer', 'TPWay', 'giveWeaponToPlayer', 'clearPlayerWeapons', 'AdminNotify', 'GiveMoney', 'SetMoney', 'eraseLog', 'eraseAllLogs', 'TryGiveMoney', 'TrySetMoney']);
  const listKeys = ['groups','vehicle','item','players','weapons','moneys','all_logs','whitelisted','non_whitelisted'];
  return $.ajax({url, method:'POST',data:data || '{}',contentType:'application/json; charset=UTF-8',dataType:'json',timeout:15000})
   .done(response => {
    response = response && typeof response === 'object' ? response : {ok:false};
    for (const key of listKeys) if (key in response && !Array.isArray(response[key])) response[key]=[];
    if (response.ok === false) {
     $('.notify-model').hide();
     status(response.error || 'Operação não concluída. Confirma os dados, permissões e consola do servidor.');
    }
    if (mutations.has(endpoint) && response.ok === true) status('Operação confirmada pelo servidor.', true);
    if (typeof success === 'function') success(response);
   })
   .fail(() => status(`Sem resposta do recurso (${endpoint}). Confirma a ligação e a consola F8.`));
 };
 document.addEventListener('error', event => {
  if (event.target instanceof HTMLImageElement && !event.target.dataset.fallback) {
   event.target.dataset.fallback='1'; event.target.src='media/placeholder.png';
  }
 }, true);
})(jQuery);
