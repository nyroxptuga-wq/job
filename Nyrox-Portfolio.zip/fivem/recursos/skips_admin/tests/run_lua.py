"""Run Lua 5.4 static compilation and mocked integration tests using system liblua."""
import ctypes, pathlib, sys
lua=ctypes.CDLL('liblua5.4.so.0')
lua.luaL_newstate.restype=ctypes.c_void_p
lua.luaL_openlibs.argtypes=[ctypes.c_void_p]
lua.luaL_loadfilex.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
lua.luaL_loadfilex.restype=ctypes.c_int
lua.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
lua.lua_pcallk.restype=ctypes.c_int
lua.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)]
lua.lua_tolstring.restype=ctypes.c_char_p
lua.lua_close.argtypes=[ctypes.c_void_p]
root=pathlib.Path(__file__).resolve().parent.parent
for file in [root/'fxmanifest.lua',*root.glob('fivem/**/*.lua')]:
 state=lua.luaL_newstate()
 code=lua.luaL_loadfilex(state,str(file).encode(),None)
 if code: raise RuntimeError(lua.lua_tolstring(state,-1,None).decode())
 lua.lua_close(state)
 print('Syntax OK:',file.relative_to(root))
import os
os.chdir(root)
for test in ['tests/server_test.lua','tests/client_test.lua']:
 state=lua.luaL_newstate(); lua.luaL_openlibs(state)
 code=lua.luaL_loadfilex(state,test.encode(),None)
 if not code: code=lua.lua_pcallk(state,0,0,0,0,None)
 if code: raise RuntimeError(lua.lua_tolstring(state,-1,None).decode())
 lua.lua_close(state)
