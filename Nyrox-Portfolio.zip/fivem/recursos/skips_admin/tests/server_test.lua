local handlers,api,actions,queries={},{},{},{}
local permission=true
local users={[1]=101,[2]=202}
local identities={[1]={name='Admin',firstname='One'},[2]={name='Player',firstname='Two'}}
local rpc=setmetatable({}, {__index=function(_,name) return function(...) actions[#actions+1]={name,...}; if name=='getPosition' then return 10.1,20.2,30.3 end end end})
local vrp={
 getUserId=function(s) for uid,player in pairs(users) do if s==player then return uid end end end,
 getUserSource=function(uid) return users[uid] end,
 hasPermission=function() return permission end,
 getUserIdentity=function(uid) return identities[uid] end,
 getUsers=function() return users end,
 vehicleGlobal=function() return {adder={name='Adder',tipo='carros'}} end,
 prepare=function() end,
 execute=function(name,params) actions[#actions+1]={name,params} end,
 query=function(name) queries[name]=(queries[name] or 0)+1
  if name=='aurora/get_user_money' then return {{user_id=2,wallet=10,bank=20}} end
  if name=='aurora/get_users' then return {{id=1,whitelisted=1},{id=2,whitelisted=0},{id=3,whitelisted=true}} end
  return {}
 end,
 giveMoney=function(uid,n) actions[#actions+1]={'giveMoney',uid,n} end,
 setBankMoney=function(uid,n) actions[#actions+1]={'setBankMoney',uid,n} end,
 giveInventoryItem=function(uid,item,n) actions[#actions+1]={'giveInventoryItem',uid,item,n} end,
 addUserGroup=function(uid,group) actions[#actions+1]={'addUserGroup',uid,group} end,
 varyThirst=function() end,varyHunger=function() end,
 kick=function(s) actions[#actions+1]={'kick',s} end,
 setWhitelisted=function() end,setBanned=function() end
}
function module(_,name)
 if name=='lib/Proxy' then return {getInterface=function() return vrp end} end
 if name=='lib/Tunnel' then return {getInterface=function() return rpc end,bindInterface=function(_,value) api=value end} end
 if name=='cfg/groups' then return {groups={Admin={_config={gtype='admin',title='Admin'}}}} end
end
function CreateThread(fn) fn() end
function TriggerClientEvent(...) actions[#actions+1]={'event',...} end
function AddEventHandler(name,fn) handlers[name]=fn end
config=dofile('fivem/cfg/config.lua')
dofile('fivem/server-side/alyson.lua')
source=101
local passed=0
local function check(condition,label) assert(condition,label); passed=passed+1 end
local function find(name) for i=#actions,1,-1 do if actions[i][1]==name then return actions[i] end end end
check(api.checkGlobalPermission()==true,'Admin access')
permission=false
local n=#actions
check(api.GiveMoney('wallet',2,100)==false and #actions==n,'Unauthorized write rejected')
check(api.GetUserMoney()==false,'Unauthorized read rejected')
permission=true
check(api.GiveMoney('wallet',2,100)==true,'Money operation')
check(find('giveMoney')[2]==2,'Recipient is selected player')
check(api.SetMoney('bank',2,0)==true and find('setBankMoney')[3]==0,'Set bank to zero')
for _,value in ipairs({-1,1.5,'nan','inf',10000001}) do
 n=#actions; check(api.GiveMoney('wallet',2,value)==false and (not find('giveMoney') or find('giveMoney')[3]==100),'Invalid amount rejected')
end
check(api.GiveMoney('wallet',999,10)==false,'Offline recipient rejected')
check(api.takeItem('agua',-5)==false,'Negative inventory rejected')
check(api.takeItem('fakeitem',1)==false,'Unknown inventory item rejected')
check(api.giveWeapon('WEAPON_FAKE',2,100)==false,'Unknown weapon rejected')
check(api.setUserGroup('missing',2)==false,'Unknown group rejected')
check(api.setUserGroup('Admin',2)==true,'Configured group applied')
check(#api.GetGroups()==1,'Missing group API restored')
check(api.GetEntityCoords()=="['x'] = 10.10, ['y'] = 20.20, ['z'] = 30.30",'All three coordinates are distinct')
local first,last,state=api.getSpecifiedPlayer(2)
check(first=='Player' and last=='Two' and state,'Search uses user ID, not player source')
check(api.GetUserMoney()[1].total==30 and queries['aurora/get_user_money']==1,'Single money query per request')
check(#api.GetWhitelisted()==2 and #api.GetNonWhitelisted()==1,'SQL booleans supported')
check(api.killAll()==true and api.reviveAll()==true and api.kickAll()==true,'Missing mass APIs restored')
check(api.AdminNotify(true,2,'<script>','Admin')==true,'Notify')
check(find('event')[5]:find('&lt;script&gt;',1,true)~=nil,'Notification HTML escaped')
source=999
check(api.checkGlobalPermission()==false,'Unregistered player rejected')
print('SERVER TESTS PASSED: '..passed)
