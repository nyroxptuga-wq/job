const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:900}});
 const errors=[],requests=[];
 page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript(()=>{window.GetParentResourceName=()=> 'renamed_admin';});
 await page.route('https://renamed_admin/**',async route=>{
  const endpoint=route.request().url().split('/').pop(); requests.push(endpoint);
  const payload={ok:true,isAllowed:true,state:true,name:'Player',lastname:'Two',
   groups:[{k:'Admin',name:'Admin'}],players:[{k:2,uname:'<img src=x onerror="window.injected=true">',ulname:'Two'}],
   item:[{k:'agua',name:'Água',item_directory:'media/placeholder'}],vehicle:[],weapons:[],moneys:[],all_logs:[],whitelisted:[],non_whitelisted:[]};
  if(endpoint==='GiveMoney' && JSON.parse(route.request().postData()).amount<0) {payload.ok=false;}
  await route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(payload)});
 });
 await page.goto('http://127.0.0.1:8765/aurora.html');
 await page.evaluate(()=> window.postMessage({action:'showMenu'},'*'));
 await page.waitForTimeout(500);
 assert(await page.locator('.background-main').isVisible());
 assert(requests.includes('requestGroups'));
 await page.evaluate(()=> $.post(nuiUrl('GiveMoney'),JSON.stringify({id:2,place:'wallet',amount:10})));
 assert.match(await page.locator('#operation-status').innerText(),/confirmada/);
 await page.evaluate(()=> $.post(nuiUrl('GiveMoney'),JSON.stringify({id:2,place:'wallet',amount:-1})));
 assert.match(await page.locator('#operation-status').innerText(),/não concluída/);
 // Trigger the original players renderer, including a malicious name in its response.
 await page.locator('.general-button').click();
 await page.locator('#players').click();
 await page.waitForTimeout(400);
 assert.equal(await page.evaluate(()=> window.injected),undefined);
 assert.equal(await page.locator('#online-players img').count(),0);
 assert.match(await page.locator('#online-players').innerText(),/<img/);
 await page.screenshot({path:require('node:path').join(__dirname,'ui-check.png')});
 await page.evaluate(()=>window.postMessage({action:'closeMenu'},'*'));
 await page.waitForTimeout(500);
 assert.equal(await page.locator('.background-main').isVisible(),false);
 assert.deepEqual(errors,[]);
 console.log('UI TESTS PASSED: open/close, renamed resource, server success/rejection, HTML injection, no JS errors');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
