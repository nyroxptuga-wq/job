local callbacks,events,commands={},{},{}
local focus=false
local fail=false
local fake=setmetatable({}, {__index=function(_,name) return function(...)
 if fail then error('Simulated Tunnel failure') end
 if name=='GetGroups' then return false end
 if name=='GetUserMoney' then return {} end
 return true
end end})
function module(_,name)
 if name=='lib/Proxy' then return {getInterface=function() return {} end} end
 return {getInterface=function() return fake end}
end
function RegisterNUICallback(name,fn) callbacks[name]=fn end
function RegisterNetEvent(name,fn) events[name]=fn end
function AddEventHandler(name,fn) events[name]=fn end
function RegisterCommand(name,fn) commands[name]=fn end
function GetCurrentResourceName() return 'skips_admin' end
function SetNuiFocus(v) focus=v end
function SendNUIMessage() end
function TriggerEvent() end
function StartScreenEffect() end
function StopScreenEffect() end
function PlayerPedId() return 1 end
function GetEntityHeading() return 180 end
config={openCommand='admin'}
dofile('fivem/client-side/tyler.lua')
local passed=0
local function check(v,label) assert(v,label); passed=passed+1 end
for name,fn in pairs(callbacks) do
 local count,response=0,nil
 fn({id=2,action='unknown'},function(value) count=count+1; response=value end)
 check(count==1 and type(response)=='table','Every callback responds exactly once: '..name)
end
local response
callbacks.requestGroups({},function(r) response=r end)
check(type(response.groups)=='table' and response.ok==false,'Denied list has empty fallback')
fail=true
callbacks.GiveMoney({},function(r) response=r end)
check(response.ok==false and response.error,'Tunnel failure returns explicit error')
fail=false
commands.admin(); check(focus,'Menu captures focus')
callbacks.TriggerUI({},function() end); check(not focus,'Menu close releases focus')
commands.admin(); events.onResourceStop('skips_admin'); check(not focus,'Resource stop releases focus')
source=123
check(pcall(events['skips_admin:spawnVehicle'],'adder'),'Local spoofed spawn ignored')
check(pcall(events['skips_admin:waypoint']),'Local spoofed teleport ignored')
print('CLIENT TESTS PASSED: '..passed)
