'use strict';
(() => {
    const $ = id => document.getElementById(id);
    let state = {}, busy = false;
    const post = async (name, body) => {
        const response = await fetch(`https://${GetParentResourceName()}/${name}`, {
            method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body || {})
        });
        if (!response.ok) throw new Error('NUI ' + response.status);
        return response.json();
    };
    const text = (parent, tag, content, cls) => {
        const element = document.createElement(tag); element.textContent = String(content ?? '');
        if (cls) element.className = cls; parent.append(element); return element;
    };
    const displayCoins = () => { $('coins').textContent = String(state.coins || 0); };
    const show = message => { $('result').textContent = message; $('result').hidden = false; };
    function renderItems() {
        const selected = (state.rewards || [])[Number($('box-select').value) - 1];
        $('items').replaceChildren();
        for (const category of selected?.categorias || []) for (const item of category.items || []) {
            const card = document.createElement('div'); card.className = 'item';
            const rarity = String(category.raridade || '').toLowerCase();
            text(card, 'div', '', `bar ${rarity}`); text(card, 'div', item.type, `type ${rarity}`);
            text(card, 'div', item.itemName, 'name-item');
            const img = document.createElement('img'); img.alt = item.itemName || 'Prémio';
            // Custom images are optional; local fallback always exists.
            const url = typeof state.configImg === 'string' ? state.configImg : '';
            img.src = /^https:\/\//.test(url) ? `${url.replace(/\/$/,'')}/${encodeURIComponent(item.item)}.png` : 'assets/images/box1.png';
            img.onerror = () => { img.onerror = null; img.src = 'assets/images/box1.png'; };
            card.append(img); $('items').append(card);
        }
    }
    async function open(quantity) {
        if (busy || $('container').hidden) return;
        const cost = quantity * (quantity >= Number(state.promoMin || 3) ? state.promoPrice : state.price);
        if (Number(state.coins) < cost) { show('Coins insuficientes.'); return; }
        busy = true; $('open-one').disabled = $('open-five').disabled = true;
        try {
            const result = await post('sendRewards', {qtd:quantity, box:Number($('box-select').value)});
            if (result.error || !result.recompensas) { show('Não foi possível abrir. Consulte a notificação no jogo.'); return; }
            state.coins = result.coins; displayCoins();
            const rewards = Object.values(result.recompensas).map(item => item.itemName);
            show(rewards.length ? `Recebeu: ${rewards.join(', ')}. Custo: ${result.charged} coins.` : 'Nenhum prémio entregue. Coins devolvidas.');
        } catch (error) { console.error(error); show('Falha na ligação. Feche e reabra o menu para consultar o saldo.'); }
        finally { busy=false; $('open-one').disabled = $('open-five').disabled = false; }
    }
    async function close() {
        if (busy || $('container').hidden) return;
        try { await post('BoxClick', {action:'closeNui'}); $('container').hidden=true; }
        catch (error) { console.error(error); }
    }
    $('open-one').onclick=()=>open(1); $('open-five').onclick=()=>open(5);
    $('close').onclick=close; $('box-select').onchange=renderItems;
    window.addEventListener('keydown', event => { if (event.key==='Escape') close(); });
    window.addEventListener('message', ({data}) => {
        if (!data || typeof data!=='object') return;
        if (data.type==='closeBox') { $('container').hidden=true; return; }
        if (data.type!=='openBox') return;
        state=data; $('container').hidden=false; $('result').hidden=true; displayCoins();
        $('coin-name').textContent=data.config?.nameCoins || 'Coins';
        $('price-one').textContent=String(data.price); $('price-five').textContent=String(5*(5>=data.promoMin ? data.promoPrice : data.price));
        $('box-select').replaceChildren();
        (data.rewards || []).forEach((box,index) => { const option=text($('box-select'),'option',box.name); option.value=String(index+1); });
        $('box-select').value='1'; renderItems();
        $('winners').replaceChildren();
        Object.values(data.winers || []).slice(0,3).forEach(winner=>text($('winners'),'p',`${winner.nome || ''} ganhou ${winner.reward || ''}`));
        const expiry = Date.parse(data.config?.dataValidade || '');
        $('expiry').textContent=Number.isFinite(expiry) ? (expiry<=Date.now() ? 'Prazo terminado' : `Até ${new Date(expiry).toLocaleDateString('pt-PT')}`) : 'Sem prazo de validade';
    });
})();
