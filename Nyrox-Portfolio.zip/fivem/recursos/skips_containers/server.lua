local Tunnel = module("vrp", "lib/Tunnel")
local vRP = module("vrp", "lib/Proxy").getInterface("vRP")
local resource = GetCurrentResourceName()
local cfg = module(resource, "box_config")
local scfg = module(resource, "sv_config")
local api, locks, sessions = {}, {}, {}
local accounting = {}
local ready = false
Tunnel.bindInterface(resource, api)
local function notify(src, kind, message) TriggerClientEvent("Notify", src, kind, message) end
local function integer(value, min, max)
    local n = tonumber(value)
    return n and n == n and n % 1 == 0 and n >= min and n <= max and n or nil
end
local function tableName(name)
    assert(type(name) == "string" and name:match("^[%w_]+$"), "Nome de tabela inválido")
    return "`" .. name .. "`"
end
local users = tableName(scfg.prepare.tabelaCoins)
local times = tableName(scfg.prepare.tabelaTempoOn)
local vehicles = tableName(scfg.prepare.tabelaVeiculos)
local function query(sql, values) return MySQL.query.await(sql, values or {}) end
local function update(sql, values) return MySQL.update.await(sql, values or {}) end
local function coins(uid)
    local rows = query("SELECT coins FROM " .. users .. " WHERE id = ?", {uid})
    return rows[1] and math.max(0, tonumber(rows[1].coins) or 0) or 0
end
local function access(src, uid)
    if not uid then return false end
    if scfg.permAbrirLonge and vRP.hasPermission(uid, scfg.permAbrirLonge) then return true end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    local p, c = GetEntityCoords(ped), scfg.coords
    return ((p.x-c[1])^2+(p.y-c[2])^2+(p.z-c[3])^2) <= (scfg.openDistance or 3)^2
end
local function winners()
    GlobalState.winers = query("SELECT * FROM nxgroup_box WHERE " .. scfg.prepare.rewardShow .. " ORDER BY id DESC LIMIT 10")
end
local function log(url, text)
    if type(url) == "string" and url:match("^https://") then
        PerformHttpRequest(url, function() end, 'POST', json.encode({content=text}), {['Content-Type']='application/json'})
    end
end
function api.checkPermissao()
    local src = source
    return ready and access(src, vRP.getUserId(src)) or false
end
function api.checkCoins()
    local src = source
    local uid = vRP.getUserId(src)
    return ready and uid and coins(uid) or 0
end
function api.getMenu()
    local src = source
    local uid = vRP.getUserId(src)
    if not ready or not access(src, uid) then return nil end
    return {coins=coins(uid), winers=GlobalState.winers or {}, imagesIP=scfg.imagesIP,
        price=scfg.precoBox, promoPrice=scfg.precoPromoBox, promoMin=scfg.promoMin}
end
local rarityNames = {'Lendario','Epico','Raro','Normal','Comum'}
local function draw(box)
    local weights = {scfg.chanceLendario, scfg.chanceEpico, scfg.chanceRaro, scfg.chanceNormal, scfg.chanceComum}
    local sum = 0
    for _, n in ipairs(weights) do assert(type(n)=='number' and n>=0, 'Probabilidade inválida'); sum=sum+n end
    assert(sum > 0, 'Probabilidades vazias')
    local ticket, cumulative = math.random()*sum, 0
    for i, weight in ipairs(weights) do
        cumulative = cumulative + weight
        if ticket < cumulative then
            for _, category in ipairs(box.categorias) do
                if category.raridade == rarityNames[i] then
                    assert(#category.items > 0, 'Categoria vazia')
                    return category.items[math.random(#category.items)], category.raridade
                end
            end
            error('Categoria de recompensa não encontrada')
        end
    end
end
local function grant(uid, reward)
    local amount = assert(integer(reward.qtd, 1, 100000000), 'Quantidade de recompensa inválida')
    if reward.type == 'carro' then
        -- INSERT IGNORE returns zero for an existing vehicle; refund this box.
        return update("INSERT IGNORE INTO "..vehicles.." (user_id,vehicle) VALUES (?,?)", {uid,reward.item}) == 1
    elseif reward.type == 'item' or reward.type == 'arma' then
        return vRP.giveInventoryItem(uid, reward.type == 'arma' and reward.spawn or reward.item, amount, true) ~= false
    elseif reward.type == 'dinheiro' then
        vRP.giveBankMoney(uid, amount)
        return true
    end
    error('Tipo de recompensa inválido')
end
function api.openBox(quantity, boxId)
    local src = source
    local uid = vRP.getUserId(src)
    quantity, boxId = integer(quantity, 1, scfg.maxBoxes or 5), integer(boxId or 1, 1, #cfg.box)
    if not ready or not uid or not quantity or not boxId or locks[uid] or not access(src, uid) then return nil end
    locks[uid] = true
    local reserved, charged, granted = 0, 0, 0
    local ok, result = xpcall(function()
        local price = quantity >= (scfg.promoMin or 3) and scfg.precoPromoBox or scfg.precoBox
        assert(integer(price, 1, 100000000), 'Preço inválido')
        local rewards, rarities, draws = {}, {}, {}
        -- Resolve the entire draw before reserving coins.
        for i=1,quantity do local reward, rarity=draw(cfg.box[boxId]); draws[i]={reward,rarity} end
        if update("UPDATE "..users.." SET coins=coins-? WHERE id=? AND coins>=?", {price*quantity,uid,price*quantity}) ~= 1 then
            notify(src, 'negado', 'Você não tem coins suficientes.'); return nil
        end
        reserved = price * quantity
        local identity = vRP.getUserIdentity(uid) or {}
        for _, entry in ipairs(draws) do
            if vRP.getUserId(src) ~= uid then break end
            local reward, rarity = entry[1], entry[2]
            if grant(uid, reward) then
                charged = charged + price
                granted = granted + 1
                rewards[#rewards+1], rarities[#rarities+1] = reward, rarity
                -- A logging failure must not refund an already delivered reward.
                local logged, err = pcall(query, "INSERT INTO nxgroup_box(user_id,nome,sobrenome,reward,raridade) VALUES (?,?,?,?,?)", {uid,identity.name or '',identity.firstname or '',reward.itemName,rarity})
                if not logged then print('[containers] Registo do prémio: '..tostring(err)) end
            else
                notify(src, 'aviso', 'Veículo já possuído: coins desta caixa devolvidas.')
            end
        end
        return {recompensas=rewards, raridades=rarities}
    end, debug.traceback)
    local refund = reserved-charged
    local refunded, refundError = true, nil
    if refund>0 then refunded,refundError=pcall(update,"UPDATE "..users.." SET coins=coins+? WHERE id=?",{refund,uid}) end
    locks[uid] = nil
    if not refunded then print(('[containers] DEVOLUÇÃO PENDENTE uid=%s coins=%s: %s'):format(uid,refund,tostring(refundError))) end
    if not ok then print('[containers] '..tostring(result)); notify(src,'negado','Falha ao abrir a caixa. Verifique a consola.'); return nil end
    if result then result.coins=coins(uid); result.charged=charged; pcall(winners) end
    return result
end
-- Online time is accounted exclusively by the server. No remote addCoin endpoint.
local function accountImpl(src, disconnecting)
    local uid=vRP.getUserId(src) or (disconnecting and sessions[src] and sessions[src].uid)
    if not uid then return end
    local now=os.time()
    local session=sessions[src]
    if not session or session.uid~=uid then
        local rows=query('SELECT tempoTotal FROM '..times..' WHERE id=?',{uid})
        sessions[src]={uid=uid, at=now, total=rows[1] and tonumber(rows[1].tempoTotal) or 0, minutes=0}
        return
    end
    local minutes=math.floor((now-session.at)/60)
    if minutes<=0 then return end
    local interval=math.max(1,tonumber(cfg.addCoinTime) or 60)
    local earned=math.floor((session.total+minutes)/interval)-math.floor(session.total/interval)
    if users==times then
        update('UPDATE '..users..' SET tempoTotal=tempoTotal+?, coins=coins+? WHERE id=?',{minutes,earned,uid})
    else
        assert(MySQL.transaction.await({
            {query='UPDATE '..times..' SET tempoTotal=tempoTotal+? WHERE id=?',values={minutes,uid}},
            {query='UPDATE '..users..' SET coins=coins+? WHERE id=?',values={earned,uid}}
        }), 'Não foi possível guardar tempo online')
    end
    session.at=session.at+minutes*60; session.total=session.total+minutes; session.minutes=session.minutes+minutes
    if earned>0 then notify(src,'sucesso',('Recebeu %s coins por tempo online.'):format(earned)) end
end
local function account(src, disconnecting)
    if accounting[src] then return end
    accounting[src]=true
    local ok,err=xpcall(function() accountImpl(src,disconnecting) end, debug.traceback)
    accounting[src]=nil
    if not ok then error(err) end
end
AddEventHandler('playerDropped', function() local src=source; if ready then local ok,err=pcall(account,src,true); if not ok then print(err) end end; sessions[src]=nil end)
RegisterCommand(scfg.comandoTempoOnline, function(src)
    if src<=0 or not ready then return end
    local session=sessions[src]
    notify(src,'sucesso',('Tempo online nesta sessão: %s minutos.'):format(session and session.minutes or 0))
end)
RegisterCommand(scfg.comandoAddCoins, function(src,args)
    local uid=src>0 and vRP.getUserId(src)
    if not ready or (src>0 and (not uid or not vRP.hasPermission(uid,scfg.permComandoAddCoins))) then return end
    local target,amount=integer(args[1],1,2147483647),integer(args[2],1,1000000)
    if not target or not amount then if src>0 then notify(src,'aviso','Uso: /addcoins ID QUANTIDADE (positiva)') end; return end
    local affected=update('UPDATE '..users..' SET coins=coins+? WHERE id=?',{amount,target})
    if src>0 then notify(src,affected==1 and 'sucesso' or 'negado',affected==1 and 'Coins adicionadas.' or 'ID não encontrado.') end
    if affected==1 then log(scfg.webhookAddCoins,('ID %s adicionou %s coins ao ID %s'):format(uid or 'consola',amount,target)) end
end)
RegisterCommand(scfg.comandoComprar, function(src)
    local uid=src>0 and vRP.getUserId(src)
    if not ready or not uid or not scfg.venderInGame or locks[uid] then return end
    locks[uid]=true
    local paid=false
    local ok,err=pcall(function()
        if vRP.tryFullPayment(uid,scfg.precoBoxInGame) then
            paid=true
            assert(update('UPDATE '..users..' SET coins=coins+25 WHERE id=?',{uid})==1,'ID não encontrado')
            paid=false
            notify(src,'sucesso','Você comprou 25 coins.')
            log(scfg.webhookBuyInGame,('ID %s comprou 25 coins'):format(uid))
        else notify(src,'negado','Dinheiro insuficiente.') end
    end)
    if paid then vRP.giveBankMoney(uid,scfg.precoBoxInGame) end
    locks[uid]=nil
    if not ok then print('[containers] '..tostring(err)) end
end)
MySQL.ready(function()
    local ok,err=pcall(function()
        query([[CREATE TABLE IF NOT EXISTS nxgroup_box (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT, nome VARCHAR(50), sobrenome VARCHAR(50),
            reward VARCHAR(100), raridade VARCHAR(50), hora VARCHAR(50), data VARCHAR(50)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
        for _,column in ipairs({{scfg.prepare.tabelaCoins,'coins'},{scfg.prepare.tabelaTempoOn,'tempoTotal'}}) do
            local rows=query('SHOW COLUMNS FROM '..tableName(column[1])..' LIKE ?', {column[2]})
            if #rows==0 then query('ALTER TABLE '..tableName(column[1])..' ADD COLUMN `'..column[2]..'` INT NOT NULL DEFAULT 0') end
            query('UPDATE '..tableName(column[1])..' SET `'..column[2]..'`=0 WHERE `'..column[2]..'` IS NULL')
        end
        GlobalState.imagesIP=scfg.imagesIP; winners(); ready=true
    end)
    if not ok then print('[containers] Falha na preparação SQL: '..tostring(err)); return end
    Citizen.CreateThread(function()
        while true do
            for _,src in ipairs(GetPlayers()) do
                local ok,err=pcall(account,tonumber(src)); if not ok then print('[containers] '..tostring(err)) end
            end
            Citizen.Wait(60000)
        end
    end)
end)
