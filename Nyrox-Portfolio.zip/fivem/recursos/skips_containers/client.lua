-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONEXÃO
-----------------------------------------------------------------------------------------------------------------------------------------
eG = Tunnel.getInterface(GetCurrentResourceName())
local cFG = module(GetCurrentResourceName(),"box_config")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local open = false
function ToggleActionMenu(tela)
    if tela == 'box' then
        if open == false then
            local menu = eG.getMenu()
            if type(menu) ~= "table" then return end
            open = true
            SetNuiFocus(true,true)
            SendNUIMessage({type='openBox', rewards = cFG.box,coins = menu.coins, winers = menu.winers, configImg = menu.imagesIP, config = cFG.geral, price = menu.price, promoPrice = menu.promoPrice, promoMin = menu.promoMin})
            StartScreenEffect("MenuMGSelectionIn", 0, true)
        else
            open = false
            SetNuiFocus(false,false)
            SetCursorLocation(0.5,0.5)
            SendNUIMessage({type = "closeBox"})
            StopScreenEffect("MenuMGSelectionIn")
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- box
-----------------------------------------------------------------------------------------------------------------------------------------
-- CASO QUEIRA REMOVER O COMANDO /containers COMENTE ESSA FUNÇÃO ABAIXO.
RegisterCommand('containers', function()
    if eG.checkPermissao() then
        ToggleActionMenu('box')
    end
end) 


-- COORDENADAS DO BLIP
local CoordenadaX =  -93.47  --  -93.47, -2462.47, 6.03
local CoordenadaY = -2462.47
local CoordenadaZ =  6.03

Citizen.CreateThread(function()
	while true do
		local skips = 1000
		local ped = PlayerPedId()

			if not IsPedInAnyVehicle(ped) then
				local x,y,z = table.unpack(GetEntityCoords(ped))
				if Vdist(x,y,z,CoordenadaX,CoordenadaY,CoordenadaZ) <= 10 then
					skips = 4
				--	DrawMarker(21,CoordenadaX,CoordenadaY,CoordenadaZ-0.4, 0,0,0,0.0,0,0,0.5,0.5,0.4, 255,50,0,90,0,0,0,1)

                    DrawMarker(27,CoordenadaX,CoordenadaY,CoordenadaZ-0.97,0,0,0,0,0,0,1.0,1.0,0.5,255, 200, 0,150,0,0,0,1)
                     DrawMarker(21,CoordenadaX,CoordenadaY,CoordenadaZ-0.97,0,0,0,0,0,0,1.0,1.0,0.5,255, 200, 0,155,0,0,0,1)

                     if Vdist(x,y,z,CoordenadaX,CoordenadaY,CoordenadaZ) <= 1.2 then
                        skips = 4
						if IsControlJustPressed(1,38) then
                            ToggleActionMenu('box')
						end
                    end
				end
			end

		Citizen.Wait(skips)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- BoxClick
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("BoxClick", function(data, cb)
    if data.action == "closeNui" then
        if open then ToggleActionMenu('box') end
    end
    cb({ok=true})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- sendRewards
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback('sendRewards', function(data, cb)
    if not open then cb({error=true}); return end
    local result = eG.openBox(data.qtd, data.box)
    cb(result or {error=true})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- sendRewards
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SetNuiFocus(false,false)
    StopScreenEffect("MenuMGSelectionIn")
end)
