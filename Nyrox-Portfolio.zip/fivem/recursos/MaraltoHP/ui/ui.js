'use strict';
(() => {
    const $=id=>document.getElementById(id);
    const rows=value=>Array.isArray(value)?value:Object.values(value||{});
    let currentPatient=null,busy=false,defaultImage='';
    function element(tag,content,className){const el=document.createElement(tag);el.textContent=String(content??'');if(className)el.className=className;return el;}
    function feedback(message,error=false){$('feedback').textContent=String(message||'');$('feedback').className=error?'error':'';$('feedback').hidden=!message;}
    function disable(value){busy=value;document.querySelectorAll('button').forEach(button=>{if(button.id!=='close')button.disabled=value;});}
    async function post(name,body){
        const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),20000);
        try{
            const response=await fetch(`https://${GetParentResourceName()}/${name}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{}),signal:controller.signal});
            if(!response.ok)throw new Error('NUI '+response.status);
            return await response.json();
        }finally{clearTimeout(timer);}
    }
    async function request(action,data={}){
        if(busy)return null;
        disable(true);feedback('A processar…');
        try{
            const result=await post('action',{action,data});
            if(!result||result.error){feedback(result?.error||'Resposta inválida do servidor.',true);return null;}
            feedback(result.message||'');return result;
        }catch(error){console.error('[Hospital]',error);feedback('Falha na ligação. Confirme o estado no servidor antes de repetir a operação.',true);return null;}
        finally{disable(false);}
    }
    const statusNames={0:'A aguardar',1:'Em atendimento',2:'Concluído',3:'Cancelado'};
    function care(data){
        const item=data.care;
        $('my-care').replaceChildren();$('care-form').hidden=!!item;
        $('cancel-care').hidden=!item||Number(item.status)!==0;
        if(item){$('my-care').append(element('h3',`Pedido #${item.id} · ${statusNames[item.status]||item.status}`),element('p',item.reason));}
    }
    function showQueue(){currentPatient=null;$('queue-panel').hidden=false;$('patient-panel').hidden=true;}
    function dashboard(data){
        showQueue();$('medics').textContent=`Médicos online: ${Number(data.medics)||0}`;$('queue').replaceChildren();
        const list=rows(data.queue);
        if(!list.length)$('queue').append(element('p','Não existem pedidos de atendimento ativos.'));
        for(const item of list){
            const card=element('article','','case');
            card.append(element('h3',`Pedido #${item.id} · ID ${item.user_id}`),element('p',item.reason),element('small',`${statusNames[item.status]||item.status} · ${item.created_at||''}${item.doctor_id?' · Médico ID '+item.doctor_id:''}`));
            const actions=element('div','','buttons');
            const button=(label,fn,ghost=false)=>{const b=element('button',label,ghost?'ghost':'');b.onclick=fn;actions.append(b);};
            button('Consultar ficha',async()=>{const result=await request('patient',{id:item.user_id});if(result)patient(result.patient);},true);
            if(Number(item.status)===0)button('Aceitar',async()=>{const result=await request('claim',{id:item.id});if(result)dashboard(result.dashboard);});
            if(Number(item.status)===1){
                button('Chamar',()=>request('callPatient',{id:item.id}));
                button('Concluir',async()=>{const result=await request('finish',{id:item.id});if(result)dashboard(result.dashboard);},true);
            }
            card.append(actions);$('queue').append(card);
        }
    }
    function photo(url){
        if(typeof url==='string'&&/^https:\/\//i.test(url)){$('photo').src=url;$('photo').hidden=false;}
        else{$('photo').removeAttribute('src');$('photo').hidden=true;}
    }
    $('photo').onerror=()=>{$('photo').hidden=true;};
    function patient(data){
        if(!data)return;
        currentPatient=data.id;$('queue-panel').hidden=true;$('patient-panel').hidden=false;
        $('patient-name').textContent=data.name;$('patient-meta').textContent=`ID ${data.id}${data.phone?' · Telefone '+data.phone:''}`;
        const image=rows(data.photos)[0]?.imageUrl||defaultImage;photo(image);$('photo-url').value=rows(data.photos)[0]?.imageUrl||'';
        $('records').replaceChildren();
        const records=rows(data.records);
        if(!records.length)$('records').append(element('p','Ainda não existem ocorrências nesta ficha.'));
        for(const record of records){const card=element('article','','record');card.append(element('small',`${record.author||''} · ${record.datahora||''}`),element('p',record.ocorrencia));$('records').append(card);}
        const old=rows(data.legacy);$('legacy').replaceChildren();$('legacy-title').hidden=!old.length;
        old.forEach(item=>{$('legacy').append(element('p',`#${item.c_id} · ${item.c_esp} · ${item.c_date} · Estado: ${item.c_status}`));});
        const cast=rows(data.cast)[0];let parts=[];
        if(cast){try{parts=Object.keys(JSON.parse(cast.parts||'{}'));}catch(_){parts=[];}}
        const labels={'head':'Cabeça','left-arm':'Braço esquerdo','right-arm':'Braço direito','left-leg':'Perna esquerda','right-leg':'Perna direita'};
        $('cast-status').textContent=cast?`Gesso registado: ${parts.map(p=>labels[p]||p).join(', ')}`:'Sem gesso registado.';
        document.querySelectorAll('#body-parts input').forEach(input=>{input.checked=parts.includes(input.value);});
    }
    async function reload(){
        const result=await request(currentPatient?'patient':'dashboard',currentPatient?{id:currentPatient}:{});
        if(result){if(result.patient)patient(result.patient);else dashboard(result);}
    }
    $('close').onclick=async()=>{try{await post('close');$('app').hidden=true;}catch(error){feedback('Não foi possível fechar o menu.',true);}};
    window.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('app').hidden)$('close').onclick();});
    $('queue-tab').onclick=async()=>{const result=await request('dashboard');if(result)dashboard(result);};
    $('refresh').onclick=reload;
    $('search-form').onsubmit=async event=>{event.preventDefault();const id=Number($('patient-id').value);if(!Number.isInteger(id)||id<1)return;const result=await request('patient',{id});if(result)patient(result.patient);};
    $('note-form').onsubmit=async event=>{event.preventDefault();if(!currentPatient)return;const result=await request('addNote',{id:currentPatient,note:$('note').value});if(result){patient(result.patient);$('note').value='';}};
    $('photo-form').onsubmit=async event=>{event.preventDefault();if(!currentPatient)return;const result=await request('setPhoto',{id:currentPatient,url:$('photo-url').value});if(result)patient(result.patient);};
    $('apply-cast').onclick=()=>{if(!currentPatient)return;const parts=[...document.querySelectorAll('#body-parts input:checked')].map(input=>input.value);return request('applyCast',{id:currentPatient,parts});};
    $('remove-cast').onclick=async()=>{if(!currentPatient)return;const result=await request('removeCast',{id:currentPatient});if(result)patient(result.patient);};
    $('carry').onclick=()=>currentPatient&&request('carry',{id:currentPatient});
    $('care-form').onsubmit=async event=>{event.preventDefault();const result=await request('requestCare',{reason:$('reason').value});if(result)care(result);};
    $('cancel-care').onclick=async()=>{const result=await request('cancelCare');if(result)care(result);};
    $('refresh-care').onclick=async()=>{const result=await request('myCare');if(result)care(result);};
    const bell=new Audio('bell.ogg');bell.volume=.25;
    window.addEventListener('message',({data})=>{
        if(!data||typeof data!=='object')return;
        if(data.type==='close'){$('app').hidden=true;return;}
        if(data.type==='bell'){bell.currentTime=0;bell.play().catch(()=>{});return;}
        if(data.type!=='open')return;
        $('app').hidden=false;feedback('');defaultImage=data.defaultImage||'';
        const reception=data.view==='reception';$('reception').hidden=!reception;$('tablet').hidden=reception;
        $('title').textContent=reception?'Pedir atendimento':'Fichas clínicas';
        if(reception)care(data.data||{});else dashboard(data.data||{});
    });
})();
