fx_version 'cerulean'
game 'gta5'
author 'Implementação independente para vRP'
version '2.0.0'
dependencies {'vrp', 'oxmysql', '/onesync'}
ui_page 'ui/ui.html'
files {'ui/*'}
client_scripts {'client.lua'}
server_scripts {'@vrp/lib/utils.lua', '@oxmysql/lib/MySQL.lua', 'server.lua'}
