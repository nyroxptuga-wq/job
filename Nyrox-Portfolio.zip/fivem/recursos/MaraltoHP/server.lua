local vRP=module('vrp','lib/Proxy').getInterface('vRP')
local cfg=module(GetCurrentResourceName(),'config')
local prefix=GetCurrentResourceName()..':'
local ready=false
local busy,rate,pendingCast,callTimes={},{},{},{}
local carries = {}
local function call(name,...)if cfg.vrpCallStyle=='table'then return vRP[name]({...})end;return vRP[name](...)end
local function integer(n,lo,hi)n=tonumber(n);return n and n==n and n%1==0 and n>=lo and n<=hi and n end
local function uidOf(src)return call('getUserId',src)end
local function staff(src)
    local uid=uidOf(src)
    return uid and cfg.permissao and cfg.permissao~='' and call('hasPermission',uid,cfg.permissao) and uid
end
local function notify(src,kind,message)
    if src and src>0 then TriggerClientEvent('Notify',src,kind,message,6000)end
end
local function fail(message)error({public=message},0)end
local function text(value,max)
    if type(value)~='string'then return nil end
    value=value:gsub('[%z\1-\8\11\12\14-\31]',''):match('^%s*(.-)%s*$')
    return #value>0 and #value<=max and value or nil
end
local function target(value)
    local uid=integer(value,1,2147483647)
    if not uid then fail('ID inválido.')end
    return uid
end
local function identity(uid)
    local value=call('getUserIdentity',uid)
    if type(value)~='table'then fail('Este ID não tem identidade registada.')end
    return value
end
local function nameOf(uid)
    local i=identity(uid)
    return ((i.name or '')..' '..(i.firstname or '')):sub(1,180)
end
local function near(src,point,radius)
    local ped=GetPlayerPed(src);if not ped or ped==0 then return false end
    local p=GetEntityCoords(ped)
    return (p.x-point[1])^2+(p.y-point[2])^2+(p.z-point[3])^2<=radius^2
end
local function query(sql,args)return MySQL.query.await(sql,args or {})end
local function update(sql,args)return MySQL.update.await(sql,args or {})end
local function myCare(uid)
    local rows=query('SELECT id, reason, created_at, status, doctor_id FROM mrlt_hp_atendimentos WHERE active_user=? ORDER BY id DESC LIMIT 1',{uid})
    return rows[1] or false
end
local function overview()
    local rows=query('SELECT id,user_id,reason,created_at,status,doctor_id FROM mrlt_hp_atendimentos WHERE status IN (0,1) ORDER BY id ASC LIMIT 100')
    local total=0;local users=call('getUsersByPermission',cfg.medicalPermission or 'paramedico.permissao')or{}
    for _ in pairs(users)do total=total+1 end
    return {queue=rows,medics=total}
end
local function patient(uid)
    local i=identity(uid)
    return {id=uid,name=(i.name or '')..' '..(i.firstname or ''),phone=tostring(i.phone or ''),
        records=query('SELECT id,author,ocorrencia,datahora FROM mrlt_hp_data WHERE user_id=? ORDER BY id DESC LIMIT 100',{uid}),
        photos=query('SELECT imageUrl FROM mrlt_hp_fotos WHERE user_id=? LIMIT 1',{uid}),
        legacy=query('SELECT c_id,c_esp,c_date,c_status FROM mrlt_hp_consultas WHERE c_user_id=? ORDER BY c_id DESC LIMIT 25',{uid}),
        cast=query('SELECT parts FROM mrlt_hp_gesso WHERE user_id=? LIMIT 1',{uid})}
end
local function decode(value)
    local ok,result=pcall(json.decode,value or '')
    return ok and type(result)=='table' and result or {}
end
local bodyParts={['right-arm']=true,['left-arm']=true,['right-leg']=true,['left-leg']=true,head=true}
local function castPlan(model,parts)
    local preset=cfg.gesso.preset[model] or cfg.gesso.preset[model-4294967296] or cfg.gesso.preset[model+4294967296]
    if not preset then fail('Este modelo de personagem não tem gesso configurado.')end
    local plan={}
    for slot,value in pairs(preset)do
        local selected=parts[value.part]
        for _,part in pairs(value.also_parts or {})do selected=selected or parts[part]end
        if selected then plan[#plan+1]={slot=tonumber(slot),drawable=tonumber(value.part_data[1]),texture=tonumber(value.part_data[2])or 0}end
    end
    if #plan==0 then fail('Não existe roupa de gesso para estas partes do corpo.')end
    return plan
end
local function restoreCast(src,uid)
    local rows=query('SELECT model,original,applied FROM mrlt_hp_gesso WHERE user_id=? LIMIT 1',{uid})
    if rows[1]then TriggerClientEvent(prefix..'applyCast',src,tonumber(rows[1].model),decode(rows[1].original),decode(rows[1].applied))end
end
local actions={}
function actions.bootstrap(src)
    return {ready=ready,command=cfg.commandName,reception=cfg.atendimentos,useAnim=cfg.useAnim==true,defaultImage=cfg.defaultUserImage or ''}
end
function actions.myCare(src)return {care=myCare(uidOf(src))}end
function actions.restoreCast(src)restoreCast(src,uidOf(src));return {silent=true}end
function actions.requestCare(src,data)
    local uid=uidOf(src)
    if not near(src,cfg.atendimentos.coords,3.0)then fail('Aproxime-se da receção do hospital.')end
    local reason=text(data.reason,250)
    if not reason or #reason<3 then fail('Descreva o motivo, entre 3 e 250 caracteres.')end
    if myCare(uid)then fail('Já tem um atendimento pendente ou em curso.')end
    MySQL.insert.await('INSERT INTO mrlt_hp_atendimentos(user_id,active_user,reason,created_at,status) VALUES (?,?,?,NOW(),0)',{uid,uid,reason})
    TriggerClientEvent(prefix..'bell',-1,cfg.atendimentos.soundCoords,cfg.atendimentos.soundMaxDist or 13)
    return {message='Atendimento registado. Aguarde a chamada de um médico.',care=myCare(uid)}
end
function actions.cancelCare(src)
    local uid=uidOf(src)
    if update('UPDATE mrlt_hp_atendimentos SET status=3,active_user=NULL,ended_at=NOW() WHERE active_user=? AND status=0',{uid})~=1 then fail('Só pode cancelar um pedido ainda não aceite.')end
    return {message='Pedido cancelado.',care=false}
end
function actions.dashboard()return overview()end
function actions.patient(src,data)return {patient=patient(target(data.id))}end
function actions.addNote(src,data)
    local uid=target(data.id);identity(uid)
    local note=text(data.note,4000)
    if not note or #note<3 then fail('Escreva uma ocorrência entre 3 e 4000 caracteres.')end
    MySQL.insert.await('INSERT INTO mrlt_hp_data(user_id,author,ocorrencia,datahora) VALUES (?,?,?,?)',{uid,nameOf(uidOf(src))..' ['..uidOf(src)..']',note,os.date('%Y-%m-%d %H:%M:%S')})
    return {message='Ocorrência guardada.',patient=patient(uid)}
end
function actions.setPhoto(src,data)
    local uid=target(data.id);identity(uid)
    local url=text(data.url,255)
    if not url or not url:match('^https://[%w%.%-]+[:/]')or url:find('[<>%s]')then fail('Indique um URL HTTPS válido, até 255 caracteres.')end
    update('INSERT INTO mrlt_hp_fotos(user_id,imageUrl) VALUES (?,?) ON DUPLICATE KEY UPDATE imageUrl=VALUES(imageUrl)',{uid,url})
    return {message='Fotografia guardada.',patient=patient(uid)}
end
function actions.claim(src,data)
    local id=target(data.id);local uid=uidOf(src)
    if update('UPDATE mrlt_hp_atendimentos SET status=1,doctor_id=? WHERE id=? AND status=0',{uid,id})~=1 then fail('Este pedido já foi aceite ou encerrado.')end
    return {message='Atendimento aceite.',dashboard=overview()}
end
local function ownedCase(src,id)
    local rows=query('SELECT user_id FROM mrlt_hp_atendimentos WHERE id=? AND status=1 AND doctor_id=?',{target(id),uidOf(src)})
    if not rows[1]then fail('Aceite o atendimento antes de chamar ou concluir.')end
    return rows[1]
end
function actions.callPatient(src,data)
    local row=ownedCase(src,data.id)
    local now=GetGameTimer()
    if callTimes[row.user_id] and now-callTimes[row.user_id]<20000 then fail('Aguarde 20 segundos antes de voltar a chamar.')end
    local destination=call('getUserSource',row.user_id)
    if not destination or uidOf(destination)~=row.user_id then fail('O paciente não está na cidade.')end
    callTimes[row.user_id]=now
    notify(destination,'importante','Foi chamado para atendimento no hospital. Dirija-se à emergência.')
    TriggerClientEvent(prefix..'waypoint',destination,cfg.gesso.coords)
    return {message='Paciente chamado.'}
end
function actions.finish(src,data)
    ownedCase(src,data.id)
    if update('UPDATE mrlt_hp_atendimentos SET status=2,active_user=NULL,ended_at=NOW() WHERE id=? AND status=1 AND doctor_id=?',{target(data.id),uidOf(src)})~=1 then fail('Este atendimento já foi encerrado.')end
    return {message='Atendimento concluído.',dashboard=overview()}
end
local function castTarget(src,data)
    local uid=target(data.id);local destination=call('getUserSource',uid)
    if not destination or uidOf(destination)~=uid then fail('O paciente não está na cidade.')end
    if not near(src,cfg.gesso.coords,cfg.gesso.radius or 10)or not near(destination,cfg.gesso.coords,cfg.gesso.radius or 10)then
        fail('Médico e paciente devem estar na área de aplicação de gesso.')
    end
    local ped=GetPlayerPed(destination);local point=GetEntityCoords(ped)
    if not near(src,{point.x,point.y,point.z},4)then fail('Aproxime-se do paciente (até 4 metros).')end
    return uid,destination
end
function actions.applyCast(src,data)
    local uid,destination=castTarget(src,data)
    if #query('SELECT user_id FROM mrlt_hp_gesso WHERE user_id=?',{uid})>0 then fail('O paciente já tem gesso. Remova-o antes de alterar as partes.')end
    local pending=pendingCast[destination]
    if pending and GetGameTimer()<pending.expires then fail('Já existe uma aplicação de gesso pendente.')end
    local parts={}
    if type(data.parts)=='table'then for _,part in pairs(data.parts)do if bodyParts[part]then parts[part]=true end end end
    if next(parts)==nil then fail('Selecione pelo menos uma parte do corpo.')end
    local model=GetEntityModel(GetPlayerPed(destination))
    local plan=castPlan(model,parts)
    local nonce=math.random(100000,2000000000)
    pendingCast[destination]={uid=uid,actor=src,actorUid=uidOf(src),model=model,plan=plan,parts=parts,nonce=nonce,expires=GetGameTimer()+15000}
    TriggerClientEvent(prefix..'captureCast',destination,nonce,model,plan)
    return {message='A verificar e guardar a roupa original do paciente.'}
end
function actions.saveCast(src,data)
    local pending=pendingCast[src]
    if not pending or pending.nonce~=data.nonce or pending.uid~=uidOf(src)or GetGameTimer()>pending.expires then fail('Pedido de gesso expirado.')end
    pendingCast[src]=nil
    if data.error then
        if uidOf(pending.actor)==pending.actorUid then notify(pending.actor,'negado','Gesso indisponível: confirme os índices de roupas em config.lua para o modelo do paciente.')end
        return {silent=true}
    end
    if type(data.original)~='table'or #data.original~=#pending.plan then fail('Roupa original inválida.')end
    local original,seen={},{}
    for _,entry in ipairs(data.original)do
        if type(entry)~='table'then fail('Roupa original inválida.')end
        local slot=integer(entry.slot,0,11);local drawable=integer(entry.drawable,0,2000);local texture=integer(entry.texture,0,1000)
        local expected=false;for _,item in ipairs(pending.plan)do if item.slot==slot then expected=true end end
        if not slot or not drawable or not texture or not expected or seen[slot]then fail('Roupa original inválida.')end
        seen[slot]=true;original[#original+1]={slot=slot,drawable=drawable,texture=texture,palette=integer(entry.palette,0,3)or 0}
    end
    -- Recheck position and staff permission after the client's asynchronous reply.
    if uidOf(pending.actor)~=pending.actorUid or not staff(pending.actor)then fail('O médico já não está autorizado.')end
    castTarget(pending.actor,{id=pending.uid})
    if GetEntityModel(GetPlayerPed(src))~=pending.model then fail('O modelo do paciente mudou. Tente novamente.')end
    if update('INSERT IGNORE INTO mrlt_hp_gesso(user_id,parts,original,applied,model) VALUES (?,?,?,?,?)',{pending.uid,json.encode(pending.parts),json.encode(original),json.encode(pending.plan),pending.model})~=1 then fail('O paciente já tem gesso.')end
    if uidOf(src)==pending.uid then TriggerClientEvent(prefix..'applyCast',src,pending.model,original,pending.plan)end
    notify(pending.actor,'sucesso','Gesso aplicado e roupa original guardada.');notify(src,'importante','Foi-lhe aplicado gesso no hospital.')
    return {silent=true}
end
function actions.removeCast(src,data)
    local uid,destination=castTarget(src,data)
    local rows=query('SELECT model,original FROM mrlt_hp_gesso WHERE user_id=?',{uid})
    if not rows[1]then fail('O paciente não tem gesso registado.')end
    update('DELETE FROM mrlt_hp_gesso WHERE user_id=?',{uid})
    pendingCast[destination]=nil
    if uidOf(destination)==uid then
        TriggerClientEvent(prefix..'removeCast',destination,tonumber(rows[1].model),decode(rows[1].original))
        notify(destination,'sucesso','O gesso foi removido.')
    end
    return {message='Gesso removido.',patient=patient(uid)}
end
local function stopCarry(src)
    local pair=carries[src]
    if not pair then return end
    carries[pair.carrier]=nil;carries[pair.patient]=nil
    TriggerClientEvent(prefix..'stopCarry',pair.carrier)
    TriggerClientEvent(prefix..'stopCarry',pair.patient)
end
function actions.carry(src,data)
    if carries[src]then stopCarry(src);return {message='Paciente largado.'}end
    local uid,destination=castTarget(src,data)
    if src==destination then fail('Não pode carregar a sua própria personagem.')end
    if cfg.carryMode=='event'then
        if type(cfg.holdEvent)~='function'then fail('Evento de carregar não configurado.')end
        cfg.holdEvent(src,destination)
        return {message='Pedido enviado à integração configurada.'}
    end
    if carries[destination]then fail('O paciente já está a ser carregado.')end
    if GetVehiclePedIsIn(GetPlayerPed(src),false)~=0 or GetVehiclePedIsIn(GetPlayerPed(destination),false)~=0 then fail('Saia do veículo antes de carregar o paciente.')end
    local pair={carrier=src,patient=destination}
    carries[src]=pair;carries[destination]=pair
    TriggerClientEvent(prefix..'carry',src,'carrier',destination)
    TriggerClientEvent(prefix..'carry',destination,'patient',src)
    notify(src,'aviso','Prima X para largar o paciente.')
    SetTimeout(300000,function()if carries[src]==pair then stopCarry(src)end end)
    return {message='A carregar paciente. Prima X para largar.'}
end
RegisterNetEvent(prefix..'stopCarry',function()stopCarry(source)end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName()then return end
    local sources={};for src in pairs(carries)do sources[#sources+1]=src end
    for _,src in ipairs(sources)do stopCarry(src)end
end)

local public={bootstrap=true,myCare=true,requestCare=true,cancelCare=true,restoreCast=true,saveCast=true}
RegisterNetEvent(prefix..'request',function(requestId,action,data)
    local src=source
    if not integer(requestId,1,1000000000)or type(action)~='string'or not actions[action]then return end
    local function reply(result)TriggerClientEvent(prefix..'response',src,requestId,result)end
    local uid=uidOf(src)
    if not uid then reply({error='Personagem ainda não carregada.'});return end
    if busy[src]then reply({error='Aguarde a operação anterior.'});return end
    local now=GetGameTimer()
    if action~='saveCast'and rate[src]and now-rate[src]<150 then reply({error='Aguarde um instante antes de repetir.'});return end
    rate[src]=now
    if action~='bootstrap'and not ready then reply({error='Hospital indisponível: verifique a ligação SQL na consola.'});return end
    if not public[action]and not staff(src)then reply({error='Sem permissão para utilizar o tablet do hospital.'});return end
    busy[src]=true
    local ok,result=xpcall(function()return actions[action](src,type(data)=='table'and data or {})end,function(err)
        if type(err)=='table'and err.public then return err end
        print('[MaraltoHP] '..tostring(err));return {public='Falha no servidor. Consulte a consola do hospital.'}
    end)
    busy[src]=nil
    if uidOf(src)==uid then reply(ok and (result or {ok=true})or {error=result.public})end
end)
RegisterCommand(cfg.commandName or 'fichahp',function(src)
    if src>0 and staff(src)then TriggerClientEvent(prefix..'tablet',src)
    elseif src>0 then notify(src,'negado','Sem permissão para utilizar o tablet do hospital.')end
end)
AddEventHandler('playerDropped',function()
    local src=source;stopCarry(src);busy[src]=nil;rate[src]=nil;pendingCast[src]=nil
    for targetSource,entry in pairs(pendingCast)do if entry.actor==src then pendingCast[targetSource]=nil end end
end)
MySQL.ready(function()
    local ok,err=pcall(function()
        local sql=LoadResourceFile(GetCurrentResourceName(),'schema.sql')
        assert(sql,'schema.sql ausente')
        sql=sql:gsub('%-%-[^\n]*','')
        for statement in sql:gmatch('([^;]+);')do if statement:match('%S')then query(statement)end end
        query([[CREATE TABLE IF NOT EXISTS mrlt_hp_atendimentos (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,active_user INT DEFAULT NULL,
            reason VARCHAR(255) NOT NULL,created_at DATETIME NOT NULL,status INT NOT NULL DEFAULT 0,
            doctor_id INT DEFAULT NULL,ended_at DATETIME DEFAULT NULL,UNIQUE KEY active_user (active_user)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
        query([[CREATE TABLE IF NOT EXISTS mrlt_hp_gesso (
            user_id INT NOT NULL PRIMARY KEY,parts LONGTEXT NOT NULL,original LONGTEXT NOT NULL,
            applied LONGTEXT NOT NULL,model BIGINT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]])
        -- Fail at startup, rather than on the first patient lookup, if legacy schemas differ.
        query('SELECT id,user_id,author,ocorrencia,datahora FROM mrlt_hp_data LIMIT 0')
        query('SELECT user_id,imageUrl FROM mrlt_hp_fotos LIMIT 0')
        query('SELECT c_id,c_user_id,c_esp,c_date,c_status FROM mrlt_hp_consultas LIMIT 0')
        ready=true
        print('[MaraltoHP] Núcleo vRP independente carregado; SQL pronto; comando /'..(cfg.commandName or 'fichahp'))
    end)
    if not ok then print('[MaraltoHP] Falha SQL: '..tostring(err))end
end)
