local dir=os.getenv('MARALTO_RESOURCE_DIR')or'.'
local cfg=dofile(dir..'/config.lua')
local events,commands,sent={}, {}, {}
local count,now,requestNo=0,1000,0
local function check(ok,message)count=count+1;assert(ok,message)end
local users={[1]=101,[2]=102,[3]=103}
local permissions={[101]=true,[103]=true}
local positions={[1]={x=-438.2,y=-324.82,z=34.92},[2]={x=-438.2,y=-324.82,z=34.92},[3]={x=-438.2,y=-324.82,z=34.92}}
local names={[101]='Médico',[102]='Paciente',[103]='Outro médico',[999]='Offline'}
local identities={};for uid,name in pairs(names)do identities[uid]={name=name,firstname='Teste',phone='555'}end
local model=1885233650
function GetCurrentResourceName()return'MaraltoHP'end
function module(_,path)
 if path=='config'then return cfg end
 return{getInterface=function()return{
 getUserId=function(src)return users[src]end,
 hasPermission=function(uid)return permissions[uid]==true end,
 getUserIdentity=function(uid)return identities[uid]end,
 getUserSource=function(uid)for src,id in pairs(users)do if id==uid then return src end end end,
 getUsersByPermission=function()return {[1]=101,[3]=103}end
 }end}
end
function GetPlayerPed(src)return src end
function GetEntityCoords(ped)return positions[ped]end
function GetEntityModel()return model end
function GetVehiclePedIsIn()return 0 end
function SetTimeout()end
function GetGameTimer()return now end
function RegisterNetEvent(name,fn)events[name]=fn end
function AddEventHandler(name,fn)events[name]=fn end
function RegisterCommand(name,fn)commands[name]=fn end
function TriggerClientEvent(name,...)sent[#sent+1]={name,...}end
function LoadResourceFile(_,path)local f=assert(io.open(dir..'/'..path));local data=f:read('*a');f:close();return data end
local jsonValues={};local jsonId=0
json={encode=function(value)jsonId=jsonId+1;local key='json:'..jsonId;jsonValues[key]=value;return key end,decode=function(value)return jsonValues[value]or{}end}
local db={queue={},notes={},photos={},casts={}}
local sqlLog={};local queueId=0;local failSQL=false
local function copy(row)local result={};for k,v in pairs(row)do result[k]=v end;return result end
local function query(sql,args)
 sqlLog[#sqlLog+1]=sql;args=args or{}
 if failSQL then error('test SQL failure')end
 if sql:find('CREATE TABLE',1,true)or sql:find('SET NAMES',1,true)or sql:find('LIMIT 0',1,true)then return{}end
 if sql:find('mrlt_hp_atendimentos',1,true)then
  local result={}
  if sql:find('WHERE active_user=?',1,true)then
   for _,row in pairs(db.queue)do if row.active_user==args[1]then result[#result+1]=copy(row)end end
  elseif sql:find('WHERE id=? AND status=1 AND doctor_id=?',1,true)then
   local row=db.queue[args[1]];if row and row.status==1 and row.doctor_id==args[2]then result[1]=copy(row)end
  else for _,row in pairs(db.queue)do if row.status==0 or row.status==1 then result[#result+1]=copy(row)end end end
  return result
 elseif sql:find('mrlt_hp_data',1,true)then return db.notes[args[1]]or{}
 elseif sql:find('mrlt_hp_fotos',1,true)then return db.photos[args[1]]and{{imageUrl=db.photos[args[1]]}}or{}
 elseif sql:find('mrlt_hp_consultas',1,true)then return{}
 elseif sql:find('mrlt_hp_gesso',1,true)then return db.casts[args[1]]and{copy(db.casts[args[1]])}or{} end
 error('unknown SQL '..sql)
end
local function insert(sql,args)
 if failSQL then error('test SQL failure')end
 if sql:find('mrlt_hp_atendimentos',1,true)then queueId=queueId+1;db.queue[queueId]={id=queueId,user_id=args[1],active_user=args[2],reason=args[3],created_at='2026-10-20 03:00:00',status=0};return queueId end
 if sql:find('mrlt_hp_data',1,true)then
  local list=db.notes[args[1]]or{};db.notes[args[1]]=list
  list[#list+1]={id=#list+1,author=args[2],ocorrencia=args[3],datahora=args[4]};return #list
 end
 error('unknown INSERT '..sql)
end
local function update(sql,args)
 if failSQL then error('test SQL failure')end
 if sql:find('SET status=1,doctor_id=?',1,true)then local row=db.queue[args[2]];if row and row.status==0 then row.status=1;row.doctor_id=args[1];return 1 end;return 0 end
 if sql:find('SET status=2',1,true)then local row=db.queue[args[1]];if row and row.status==1 and row.doctor_id==args[2]then row.status=2;row.active_user=nil;return 1 end;return 0 end
 if sql:find('SET status=3',1,true)then for _,row in pairs(db.queue)do if row.active_user==args[1]and row.status==0 then row.status=3;row.active_user=nil;return 1 end end;return 0 end
 if sql:find('mrlt_hp_fotos',1,true)then db.photos[args[1]]=args[2];return 1 end
 if sql:find('INSERT IGNORE INTO mrlt_hp_gesso',1,true)then if db.casts[args[1]]then return 0 end;db.casts[args[1]]={user_id=args[1],parts=args[2],original=args[3],applied=args[4],model=args[5]};return 1 end
 if sql:find('DELETE FROM mrlt_hp_gesso',1,true)then db.casts[args[1]]=nil;return 1 end
 error('unknown UPDATE '..sql)
end
MySQL={query={await=query},insert={await=insert},update={await=update},ready=function(fn)fn()end}
dofile(dir..'/server.lua')
local function req(src,action,data)
 source=src;now=now+250;requestNo=requestNo+1
 events['MaraltoHP:request'](requestNo,action,data or{})
 for i=#sent,1,-1 do local item=sent[i];if item[1]=='MaraltoHP:response'and item[2]==src and item[3]==requestNo then return item[4]end end
 error('missing response for '..action)
end
local result=req(2,'bootstrap');check(result.ready==true,'SQL initialization completes');check(result.command=='fichahp','original command preserved')
check(result.reception.coords[1]==-438.2,'reception coordinates preserved')
check(req(2,'dashboard').error~=nil,'tablet requires server permission')
check(req(2,'addNote',{id=102,note='no'}).error~=nil,'patient cannot write records')
check(req(1,'dashboard').medics==2,'medic map is counted correctly')
check(req(1,'patient',{id=-1}).error~=nil,'negative patient rejected');check(req(1,'patient',{id=1.5}).error~=nil,'fractional ID rejected')
check(req(1,'patient',{id=555}).error~=nil,'unknown patient rejected')
result=req(1,'patient',{id=999});check(result.patient.id==999,'offline registered patient lookup supported')
result=req(1,'addNote',{id=102,note="Observação com 'aspas' e <texto>"});check(not result.error,'record saved');check(db.notes[102][1].ocorrencia=="Observação com 'aspas' e <texto>",'SQL values remain parameters')
check(req(1,'addNote',{id=102,note=''}).error~=nil,'empty note rejected')
check(req(1,'addNote',{id=102,note=string.rep('x',4001)}).error~=nil,'oversized note rejected')
check(req(1,'setPhoto',{id=102,url='javascript:alert(1)'}).error~=nil,'script photo URL rejected')
result=req(1,'setPhoto',{id=102,url='https://example.com/photo.png'});check(not result.error and db.photos[102]=='https://example.com/photo.png','HTTPS photo persisted')
positions[2]={x=0,y=0,z=0};check(req(2,'requestCare',{reason='Dor na perna'}).error~=nil,'reception proximity required')
positions[2]={x=-438.2,y=-324.82,z=34.92};result=req(2,'requestCare',{reason='Dor na perna'});check(result.care.id==1,'care request persisted')
check(req(2,'requestCare',{reason='Repetido'}).error~=nil,'duplicate pending care blocked')
check(req(2,'myCare').care.reason=='Dor na perna','own care state returned')
check(not req(1,'claim',{id=1}).error,'doctor claims case')
check(req(3,'claim',{id=1}).error~=nil,'second doctor cannot claim same case')
check(req(2,'cancelCare').error~=nil,'accepted care cannot be cancelled by patient')
check(req(3,'callPatient',{id=1}).error~=nil,'only case owner can call')
check(not req(1,'callPatient',{id=1}).error,'owner can call patient')
check(req(1,'callPatient',{id=1}).error~=nil,'call cooldown enforced')
check(req(3,'finish',{id=1}).error~=nil,'only case owner can finish')
check(not req(1,'finish',{id=1}).error and db.queue[1].status==2,'case closes and persists')
check(req(2,'myCare').care==false,'closed case no longer active')
check(not req(2,'requestCare',{reason='Nova visita'}).error,'new visit after completion accepted')
check(not req(2,'cancelCare').error,'waiting request can be cancelled')
check(req(1,'applyCast',{id=102,parts={'left-leg'}}).error~=nil,'gesso requires designated area')
positions[1]={x=-440.89,y=-302.98,z=35.78};positions[2]={x=-440.0,y=-302.98,z=35.78}
check(req(2,'applyCast',{id=102,parts={'left-leg'}}).error~=nil,'patient cannot prescribe cast')
check(req(1,'applyCast',{id=102,parts={}}).error~=nil,'cast body part required')
result=req(1,'applyCast',{id=102,parts={'left-leg'}});check(not result.error,'cast authorized in area')
local nonce
for i=#sent,1,-1 do if sent[i][1]=='MaraltoHP:captureCast'then nonce=sent[i][3];break end end
check(type(nonce)=='number','one-time snapshot nonce issued')
check(req(2,'saveCast',{nonce=nonce+1,original={}}).error~=nil,'forged snapshot nonce rejected')
result=req(2,'saveCast',{nonce=nonce,original={{slot=6,drawable=12,texture=0,palette=0}}});check(not result.error and db.casts[102]~=nil,'valid original saved before applying cast')
check(req(2,'saveCast',{nonce=nonce,original={}}).error~=nil,'snapshot replay rejected')
check(req(1,'applyCast',{id=102,parts={'head'}}).error~=nil,'duplicate cast blocked')
check(not req(2,'restoreCast').error,'cast can be restored after reconnect')
result=req(1,'removeCast',{id=102});check(not result.error and not db.casts[102],'cast removed and original restored')
check(req(1,'removeCast',{id=102}).error~=nil,'removing absent cast rejected')
result=req(1,'applyCast',{id=102,parts={'left-leg'}})
for i=#sent,1,-1 do if sent[i][1]=='MaraltoHP:captureCast'then nonce=sent[i][3];break end end
permissions[101]=false;check(req(2,'saveCast',{nonce=nonce,original={{slot=6,drawable=12,texture=0,palette=0}}}).error~=nil,'permission rechecked after snapshot');permissions[101]=true
check(req(1,'carry',{id=101}).error~=nil,'cannot carry own character')
result=req(1,'carry',{id=102});check(not result.error,'built-in carry starts without external resource')
check(sent[#sent-2][1]=='MaraltoHP:carry' or sent[#sent-3][1]=='MaraltoHP:carry','carry events sent to participants')
positions[3]={x=-440.5,y=-302.98,z=35.78}
check(req(3,'carry',{id=102}).error~=nil,'patient cannot be carried twice')
source=2;events['MaraltoHP:stopCarry']();check(sent[#sent][1]=='MaraltoHP:stopCarry','patient can stop being carried')
check(not req(1,'carry',{id=102}).error,'carry can restart after release')
source=1;events.playerDropped();check(sent[#sent][1]=='MaraltoHP:stopCarry','disconnect releases carry participants')
failSQL=true;check(req(1,'patient',{id=102}).error~=nil,'SQL failures return an error instead of hanging');failSQL=false
check(not req(1,'patient',{id=102}).error,'request lock released after SQL failure')
local safe=true;for _,sql in ipairs(sqlLog)do if sql:upper():find('DROP ',1,true)then safe=false end end;check(safe,'startup SQL never drops tables')
users[2]=nil;check(req(2,'myCare').error~=nil,'missing vRP identity rejected')
print('hospital: '..count..' checks passed')
