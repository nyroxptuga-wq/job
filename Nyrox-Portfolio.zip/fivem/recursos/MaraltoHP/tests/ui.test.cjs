const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const dir=process.env.MARALTO_RESOURCE_DIR||'.';
function setup(){
 const nodes={},events={},calls=[];let reject=false;
 const make=()=>({hidden:true,value:'',className:'',children:[],append(...items){this.children.push(...items)},replaceChildren(){this.children=[]},removeAttribute(name){delete this[name]}});
 const document={getElementById(id){return nodes[id]??=make()},createElement:make,querySelectorAll(){return[]}};
 for(const id of fs.readFileSync(path.join(dir,'ui/ui.html'),'utf8').matchAll(/id="([^"]+)"/g))document.getElementById(id[1]);
 const context={document,window:{addEventListener(n,fn){events[n]=fn}},console:{error(){}},Audio:function(){this.play=()=>Promise.resolve()},GetParentResourceName:()=> 'MaraltoHP',AbortController,setTimeout,clearTimeout,
 fetch:async(url,options)=>{const body=JSON.parse(options.body);calls.push({url,body});if(reject)throw Error('test connection failure');
 const action=body.action;let result={};if(action==='patient')result={patient:{id:102,name:'<script>Teste</script>',records:[{author:'Autor',ocorrencia:'<img src=x onerror=alert(1)>',datahora:'hoje'}],photos:[],cast:[],legacy:[]}};
 if(action==='requestCare')result={message:'Registado',care:{id:1,status:0,reason:body.data.reason}};
 if(action==='cancelCare')result={care:false,message:'Cancelado'};
 return{ok:true,json:async()=>result};}};
 vm.runInNewContext(fs.readFileSync(path.join(dir,'ui/ui.js'),'utf8'),context);
 return{nodes,events,calls,fail(){reject=true}};
}
test('hospital starts hidden, shows queue and uses HTTPS callbacks',async()=>{
 const {nodes,events,calls}=setup();assert.equal(nodes.app.hidden,true);
 events.message({data:{type:'open',view:'tablet',data:{queue:[{id:1,user_id:102,reason:'<b>dor</b>',status:0}],medics:2}}});
 assert.equal(nodes.app.hidden,false);assert.equal(nodes.tablet.hidden,false);assert.equal(nodes.reception.hidden,true);assert.equal(nodes.medics.textContent,'Médicos online: 2');
 const card=nodes.queue.children[0];assert.equal(card.children[1].textContent,'<b>dor</b>');
 await card.children[3].children[0].onclick();assert.equal(calls[0].url,'https://MaraltoHP/action');assert.equal(calls[0].body.action,'patient');
 assert.equal(nodes['patient-name'].textContent,'<script>Teste</script>');assert.equal(nodes.records.children[0].children[1].textContent,'<img src=x onerror=alert(1)>');
 assert.equal(nodes['patient-panel'].hidden,false);assert.equal(nodes.photo.hidden,true);
 await nodes.close.onclick();assert.equal(calls[1].url,'https://MaraltoHP/close');assert.equal(nodes.app.hidden,true);
});
test('reception creates and cancels own care without exposing tablet',async()=>{
 const {nodes,events,calls}=setup();events.message({data:{type:'open',view:'reception',data:{care:false}}});
 assert.equal(nodes.tablet.hidden,true);assert.equal(nodes['care-form'].hidden,false);
 nodes.reason.value='Dor na perna';await nodes['care-form'].onsubmit({preventDefault(){}});
 assert.equal(calls[0].body.action,'requestCare');assert.equal(nodes['care-form'].hidden,true);assert.equal(nodes['cancel-care'].hidden,false);
 await nodes['cancel-care'].onclick();assert.equal(nodes['care-form'].hidden,false);assert.equal(nodes['cancel-care'].hidden,true);
});
test('network errors leave a usable close button and error message',async()=>{
 const env=setup();env.events.message({data:{type:'open',view:'tablet',data:{queue:[]}}});env.fail();
 await env.nodes.refresh.onclick();assert.equal(env.nodes.feedback.className,'error');assert.match(env.nodes.feedback.textContent,/Falha/);
});
