local prefix=GetCurrentResourceName()..':'
local config,opened,castOriginal,castModel=nil,false,nil,nil
local requests,sequence={},0
local tablet,animationId=nil,0
local function notify(message,kind)TriggerEvent('Notify',kind or 'negado',message,6000)end
local function rpc(action,data,callback)
    sequence=sequence%1000000000+1
    local id=sequence;requests[id]=callback
    SetTimeout(15000,function()
        local cb=requests[id]
        if cb then requests[id]=nil;cb({error='O servidor não respondeu. Confirme a consola e tente novamente.'})end
    end)
    TriggerServerEvent(prefix..'request',id,action,data or {})
end
RegisterNetEvent(prefix..'response',function(id,result)
    local cb=requests[id]
    if cb then requests[id]=nil;cb(type(result)=='table'and result or {error='Resposta inválida do hospital.'})end
end)
local function stopTablet()
    animationId=animationId+1
    if tablet and DoesEntityExist(tablet)then DeleteEntity(tablet)end
    tablet=nil
    StopAnimTask(PlayerPedId(),'amb@world_human_clipboard@male@base','base',2.0)
end
local function close()
    opened=false;SetNuiFocus(false,false);SendNUIMessage({type='close'});stopTablet()
end
local function startTablet()
    if not config or not config.useAnim then return end
    animationId=animationId+1;local token=animationId
    CreateThread(function()
        local dict='amb@world_human_clipboard@male@base';local model=GetHashKey('prop_cs_tablet')
        RequestAnimDict(dict);RequestModel(model)
        local deadline=GetGameTimer()+5000
        while (not HasAnimDictLoaded(dict)or not HasModelLoaded(model))and GetGameTimer()<deadline do Wait(20)end
        if not opened or token~=animationId or not HasAnimDictLoaded(dict)or not HasModelLoaded(model)then SetModelAsNoLongerNeeded(model);return end
        local ped=PlayerPedId()
        tablet=CreateObject(model,0.0,0.0,0.0,false,false,false)
        SetModelAsNoLongerNeeded(model)
        AttachEntityToEntity(tablet,ped,GetPedBoneIndex(ped,60309),0.03,0.01,-0.02,0.0,0.0,0.0,true,true,false,true,1,true)
        TaskPlayAnim(ped,dict,'base',3.0,3.0,-1,49,0,false,false,false)
    end)
end
local function show(view,data)
    if opened then return end
    opened=true;SetNuiFocus(true,true)
    SendNUIMessage({type='open',view=view,data=data,defaultImage=config and config.defaultImage or ''})
    if view=='tablet'then startTablet()end
end
RegisterNetEvent(prefix..'tablet',function()
    if opened then close();return end
    rpc('dashboard',{},function(result)if result.error then notify(result.error)else show('tablet',result)end end)
end)
RegisterNUICallback('close',function(_,cb)close();cb({ok=true})end)
RegisterNUICallback('action',function(data,cb)
    if not opened or type(data)~='table'then cb({error='Menu fechado.'});return end
    rpc(data.action,data.data,function(result)
        cb(result)
        if data.action=='carry'and not result.error then close()end
    end)
end)
RegisterNetEvent(prefix..'bell',function(point,radius)
    if type(point)~='table'then return end
    local p=GetEntityCoords(PlayerPedId())
    if (p.x-point[1])^2+(p.y-point[2])^2+(p.z-point[3])^2<=(tonumber(radius)or 13)^2 then SendNUIMessage({type='bell'})end
end)
RegisterNetEvent(prefix..'waypoint',function(point)
    if type(point)=='table'and tonumber(point[1])and tonumber(point[2])then SetNewWaypoint(point[1],point[2])end
end)
local function sameModel(model)return tonumber(model)and GetEntityModel(PlayerPedId())%4294967296==tonumber(model)%4294967296 end
local function validOutfit(plan)
    if type(plan)~='table'or #plan==0 or #plan>12 then return false end
    local ped=PlayerPedId()
    for _,item in ipairs(plan)do
        if type(item)~='table'or not tonumber(item.slot)or item.slot<0 or item.slot>11 or not tonumber(item.drawable)or not tonumber(item.texture)then return false end
        if item.drawable<0 or item.drawable>=GetNumberOfPedDrawableVariations(ped,item.slot)then return false end
        if item.texture<0 or item.texture>=GetNumberOfPedTextureVariations(ped,item.slot,item.drawable)then return false end
    end
    return true
end
local function restore(model,original)
    if not sameModel(model)or type(original)~='table'then return end
    local ped=PlayerPedId()
    for _,item in ipairs(original)do
        if validOutfit({item})then SetPedComponentVariation(ped,item.slot,item.drawable,item.texture,item.palette or 0)end
    end
end
RegisterNetEvent(prefix..'captureCast',function(nonce,model,plan)
    if not sameModel(model)or not validOutfit(plan)then
        rpc('saveCast',{nonce=nonce,error=true},function()end);return
    end
    local original={};local ped=PlayerPedId()
    for _,item in ipairs(plan)do original[#original+1]={slot=item.slot,drawable=GetPedDrawableVariation(ped,item.slot),texture=GetPedTextureVariation(ped,item.slot),palette=GetPedPaletteVariation(ped,item.slot)}end
    rpc('saveCast',{nonce=nonce,original=original},function(result)if result.error then notify(result.error)end end)
end)
RegisterNetEvent(prefix..'applyCast',function(model,original,plan)
    if not sameModel(model)or not validOutfit(plan)then notify('Não foi possível aplicar o gesso: confirme as roupas configuradas.');return end
    castOriginal,castModel=original,model
    for _,item in ipairs(plan)do SetPedComponentVariation(PlayerPedId(),item.slot,item.drawable,item.texture,0)end
end)
RegisterNetEvent(prefix..'removeCast',function(model,original)
    restore(model,original);castOriginal,castModel=nil,nil
end)
local bootstrapBusy=false
local function bootstrap()
    if bootstrapBusy then return end
    bootstrapBusy=true
    rpc('bootstrap',{},function(result)
        bootstrapBusy=false
        if not result.error then
            local wasReady=config and config.ready
            config=result
            if result.ready and not wasReady then SetTimeout(350,function()rpc('restoreCast',{},function()end)end)end
        end
    end)
end
CreateThread(function()
    while not config or not config.ready do bootstrap();Wait(5000)end
end)
AddEventHandler('playerSpawned',function()
    SetTimeout(3000,function()if config and config.ready then rpc('restoreCast',{},function()end)end end)
end)
CreateThread(function()
    while true do
        local sleep=1000
        if config and config.reception and not opened then
            local ped=PlayerPedId();local p=GetEntityCoords(ped);local reception=config.reception;local c=reception.coords
            local distance=(p.x-c[1])^2+(p.y-c[2])^2+(p.z-c[3])^2
            if distance<=100 then
                sleep=0
                local marker=reception.marker or {}
                if marker.use then
                    local color=marker.marker_rgb_color or {252,186,3};local size=marker.marker_size or 0.3
                    DrawMarker(marker.marker_id or 20,c[1],c[2],c[3]+(marker.marker_height_adjustment or 0),0,0,0,0,0,0,size,size,size,color[1],color[2],color[3],150,false,false,2,false,nil,nil,false)
                end
                if distance<=2.25 then
                    local label=reception.text or {}
                    if label.use then
                        local xy=label.positionsXY or {0.265,0.945}
                        SetTextFont(4);SetTextScale(0.36,0.36);SetTextColour(255,255,255,255);SetTextOutline();SetTextCentre(true)
                        BeginTextCommandDisplayText('STRING');AddTextComponentSubstringPlayerName(label.string or 'Prima ~y~E~w~ para pedir atendimento.');EndTextCommandDisplayText(xy[1],xy[2])
                    end
                    if IsControlJustPressed(0,38)then
                        rpc('myCare',{},function(result)if result.error then notify(result.error)else show('reception',result)end end)
                        Wait(500)
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
local carrying=nil
local function stopCarryLocal()
    if not carrying then return end
    local ped=PlayerPedId()
    if carrying.role=='patient'then DetachEntity(ped,true,false)end
    StopAnimTask(ped,carrying.dict,carrying.clip,2.0)
    carrying=nil
end
RegisterNetEvent(prefix..'stopCarry',stopCarryLocal)
RegisterNetEvent(prefix..'carry',function(role,otherSource)
    stopCarryLocal()
    if role~='carrier'and role~='patient'then return end
    local otherPlayer=GetPlayerFromServerId(otherSource)
    if otherPlayer==-1 then TriggerServerEvent(prefix..'stopCarry');return end
    local dict=role=='carrier'and'missfinale_c2mcs_1'or'nm'
    local clip=role=='carrier'and'fin_c2_mcs_1_camman'or'firemans_carry'
    local state={role=role,dict=dict,clip=clip};carrying=state
    CreateThread(function()
        RequestAnimDict(dict);local deadline=GetGameTimer()+5000
        while not HasAnimDictLoaded(dict)and GetGameTimer()<deadline and carrying==state do Wait(20)end
        if carrying~=state then return end
        if not HasAnimDictLoaded(dict)then TriggerServerEvent(prefix..'stopCarry');stopCarryLocal();return end
        local ped=PlayerPedId();local otherPed=GetPlayerPed(otherPlayer)
        if role=='patient'then AttachEntityToEntity(ped,otherPed,0,0.27,0.15,0.63,0.0,0.0,180.0,false,false,false,false,2,false)end
        TaskPlayAnim(ped,dict,clip,8.0,-8.0,-1,role=='carrier'and 49 or 33,0,false,false,false)
        while carrying==state do
            if IsControlJustPressed(0,73)or IsEntityDead(ped)or not DoesEntityExist(otherPed)or IsPedInAnyVehicle(ped,false)then
                TriggerServerEvent(prefix..'stopCarry');stopCarryLocal();return
            end
            Wait(0)
        end
    end)
end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName()then return end
    SetNuiFocus(false,false);stopTablet();stopCarryLocal()
    if castOriginal then restore(castModel,castOriginal)end
    for _,cb in pairs(requests)do cb({error='Hospital reiniciado.'})end
    requests={}
end)
