GlobalState.license = GetConvar("vrp_license", "")
