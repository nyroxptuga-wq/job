if Config.Framework ~= 'vrp' then return end
local pending, nextId = {}, 0
function VRPTriggerCallback(name, data)
    nextId = nextId % 2147483647 + 1
    local id = nextId
    local slot = {done=false}; pending[id] = slot
    TriggerServerEvent('oph3z-phone:vrp:request', id, name, data)
    local deadline = GetGameTimer() + Config.VRP.CallbackTimeout
    while not slot.done and GetGameTimer() < deadline do Wait(0) end
    pending[id] = nil
    if not slot.done then print('[oph3z-phone/vrp] Callback timeout: '..tostring(name)) end
    return slot.value
end
RegisterNetEvent('oph3z-phone:vrp:response', function(id, value)
    if source ~= 65535 then return end
    local slot = pending[id]
    if slot and not slot.done then slot.value, slot.done = value, true end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, slot in pairs(pending) do slot.done = true end
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end)
