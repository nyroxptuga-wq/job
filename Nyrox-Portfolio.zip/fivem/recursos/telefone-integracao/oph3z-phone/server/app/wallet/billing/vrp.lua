-- Internal invoices for the vRP wallet. Other server resources issue them via export.
-- This provider does not read an unknown external bank's invoice schema.
if Config.Framework ~= 'vrp' or Config.BillingScript ~= 'vrp' then return end
BillsProvider = BillsProvider or {}
local paying = {}
local function invoices(cid)
    local doc = DB.LoadOrCreate(cid)
    doc.wallet = doc.wallet or {}
    doc.wallet.bills = doc.wallet.bills or {}
    doc.wallet.nextBillId = doc.wallet.nextBillId or 1
    return doc, doc.wallet.bills
end
function BillsProvider.Get(cid)
    local _, bills = invoices(cid)
    local out = {}
    for _, bill in ipairs(bills) do
        if not bill.paid then
            out[#out+1] = {id=bill.id, issuer=bill.issuer, label=bill.label, amount=bill.amount, ts=bill.ts, paid=false}
        end
    end
    return out
end
function BillsProvider.Pay(cid, src, billId)
    if GetIdentifier(src) ~= cid then return {ok=false,reason='gone'} end
    billId = VRPBridge.Integer(billId)
    if not billId then return {ok=false,reason='gone'} end
    local doc, bills = invoices(cid)
    local selected
    for _, bill in ipairs(bills) do if bill.id==billId and not bill.paid then selected=bill; break end end
    if not selected then return {ok=false,reason='gone'} end
    local key=cid..':'..billId
    if paying[key] then return {ok=false,reason='busy'} end
    paying[key]=true
    local ok,result=pcall(function()
        local paid,reason=Bank.Transfer(cid,VRPBridge.CitizenId(selected.recipient),selected.amount)
        if not paid then return {ok=false,reason=reason or 'failed'} end
        selected.paid=true; selected.paidAt=os.time()
        if not DB.SaveNow(cid,doc) then
            print('[oph3z-phone/vrp] Invoice paid but document write failed: '..key)
        end
        return {ok=true,amount=selected.amount,issuer=selected.issuer,label=selected.label}
    end)
    paying[key]=nil
    if not ok then print('[oph3z-phone/vrp] Invoice error: '..tostring(result)); return {ok=false,reason='failed'} end
    return result
end
exports('CreateVRPInvoice',function(payerUserId, recipientUserId, amount, label, issuer)
    local payer=VRPBridge.Integer(payerUserId)
    local recipient=VRPBridge.Integer(recipientUserId)
    amount=VRPBridge.Amount(amount)
    if not payer or not recipient or payer==recipient or not amount then return false end
    -- Require both accounts online when issuing; no unverified offline account writes.
    if not VRPBridge.Source(payer) or not VRPBridge.Source(recipient) then return false end
    if type(label)~='string' or label=='' or #label>160 then return false end
    issuer=type(issuer)=='string' and issuer:sub(1,80) or ('ID '..recipient)
    local cid=VRPBridge.CitizenId(payer)
    local doc,bills=invoices(cid)
    local bill={id=doc.wallet.nextBillId,recipient=recipient,amount=amount,label=label,issuer=issuer,ts=os.time(),paid=false}
    doc.wallet.nextBillId=doc.wallet.nextBillId+1
    bills[#bills+1]=bill
    if not DB.SaveNow(cid,doc) then
        table.remove(bills); return false
    end
    local src=VRPBridge.Source(payer)
    if src then TriggerClientEvent('oph3z-phone:client:wallet:bill',src,{id=bill.id,amount=amount,label=label,issuer=issuer,ts=bill.ts,paid=false}) end
    return bill.id
end)
