-- vRPex/Skips bridge. Framework calls remain on the server.
if Config.Framework ~= 'vrp' then return end
VRPBridge = { callbacks = {}, locks = {}, sessions = {} }
local options = Config.VRP
VRPBridge.core = module(options.Resource, 'lib/Proxy').getInterface(options.Interface)

function VRPBridge.Call(name, ...)
    local method = options.Methods[name] or name
    if options.CallStyle == 'table' then return VRPBridge.core[method]({...}) end
    return VRPBridge.core[method](...)
end
function VRPBridge.Integer(value, minimum, maximum)
    local n = tonumber(value)
    if not n or n ~= n or n % 1 ~= 0 or n < (minimum or 1) or n > (maximum or 9007199254740991) then return nil end
    return n
end
function VRPBridge.UserId(src)
    return VRPBridge.Integer(VRPBridge.Call('getUserId', tonumber(src)))
end
function VRPBridge.CitizenId(uid)
    uid = VRPBridge.Integer(uid)
    return uid and ('vrp_' .. tostring(uid)) or nil
end
function VRPBridge.ParseId(cid)
    if type(cid) ~= 'string' then return nil end
    return VRPBridge.Integer(cid:match('^vrp_(%d+)$'))
end
function VRPBridge.Source(uid)
    return VRPBridge.Integer(VRPBridge.Call('getUserSource', uid))
end
function VRPBridge.Identity(uid)
    local identity = VRPBridge.Call('getUserIdentity', uid)
    return type(identity) == 'table' and identity or {}
end
function GetVRPPhoneNumber(cid)
    if not options.UseIdentityPhone then return nil end
    local uid = VRPBridge.ParseId(cid)
    local number = uid and VRPBridge.Identity(uid)[options.PhoneField]
    if type(number) ~= 'string' and type(number) ~= 'number' then return nil end
    local digits = tostring(number):gsub('%D', '')
    return #digits >= 3 and #digits <= 20 and digits or nil
end
function VRPBridge.Amount(value)
    return VRPBridge.Integer(value, 1, options.MaxTransfer)
end
function VRPBridge.GetBalance(cid)
    local uid = VRPBridge.ParseId(cid)
    -- The supplied base has no documented offline-banking contract.
    if not uid or not VRPBridge.Source(uid) then return nil end
    return VRPBridge.Integer(VRPBridge.Call('getBankMoney', uid), 0)
end
function VRPBridge.Adjust(cid, amount, add)
    amount = VRPBridge.Amount(amount)
    local uid = VRPBridge.ParseId(cid)
    if not amount or not uid or VRPBridge.locks[uid] then return false end
    local owner = {}; VRPBridge.locks[uid] = owner
    local ok, result = pcall(function()
        local before = VRPBridge.GetBalance(cid)
        if not before then return false end
        local after = add and before + amount or before - amount
        if not VRPBridge.Integer(after, 0) then return false end
        VRPBridge.Call('setBankMoney', uid, after)
        return true
    end)
    if VRPBridge.locks[uid] == owner then VRPBridge.locks[uid] = nil end
    if not ok then print('[oph3z-phone/vrp] Bank adjustment failed: '..tostring(result)); return false end
    return result
end
function VRPBridge.Transfer(from, to, amount)
    local a, b = VRPBridge.ParseId(from), VRPBridge.ParseId(to)
    amount = VRPBridge.Amount(amount)
    if not a or not b or a == b or not amount then return false, 'amount' end
    if VRPBridge.locks[a] or VRPBridge.locks[b] then return false, 'busy' end
    local owner = {}; VRPBridge.locks[a], VRPBridge.locks[b] = owner, owner
    local result = table.pack(pcall(function()
        local sourceA, sourceB = VRPBridge.Source(a), VRPBridge.Source(b)
        if not sourceA or not sourceB then return false, 'offline' end
        local beforeA, beforeB = VRPBridge.GetBalance(from), VRPBridge.GetBalance(to)
        if not beforeA or not beforeB then return false, 'failed' end
        if beforeA < amount then return false, 'funds' end
        if not VRPBridge.Integer(beforeB + amount, 0) then return false, 'amount' end
        if VRPBridge.Source(a) ~= sourceA or VRPBridge.Source(b) ~= sourceB then return false, 'offline' end
        local afterA, afterB = beforeA - amount, beforeB + amount
        local wrote, err = pcall(function()
            VRPBridge.Call('setBankMoney', a, afterA)
            VRPBridge.Call('setBankMoney', b, afterB)
        end)
        if wrote then return true end
        local inspected, actualA, actualB = pcall(function()
            return VRPBridge.GetBalance(from), VRPBridge.GetBalance(to)
        end)
        if inspected and actualA == afterA and actualB == afterB then return true end
        if inspected and actualA == afterA and actualB == beforeB then
            local restored = pcall(function()
                VRPBridge.Call('setBankMoney', a, beforeA)
                assert(VRPBridge.GetBalance(from) == beforeA, 'Refund not confirmed')
            end)
            if restored then return false, 'failed' end
        elseif inspected and actualA == beforeA and actualB == beforeB then return false, 'failed' end
        print(('[oph3z-phone/vrp] RECONCILE IDs %s -> %s amount %s: %s'):format(a,b,amount,tostring(err)))
        return false, 'uncertain'
    end))
    if VRPBridge.locks[a] == owner then VRPBridge.locks[a] = nil end
    if VRPBridge.locks[b] == owner then VRPBridge.locks[b] = nil end
    if not result[1] then
        print('[oph3z-phone/vrp] Transfer failed: '..tostring(result[2])); return false, 'failed'
    end
    return table.unpack(result, 2, result.n)
end

-- Native callback transport: no ESX/QB callback dependency.
local function newSession(src)
    local value = { active = true, count = 0, window = GetGameTimer(), queued = 0 }
    VRPBridge.sessions[src] = value
    return value
end
RegisterNetEvent('oph3z-phone:vrp:request', function(id, name, data)
    local src = source
    if not VRPBridge.Integer(id, 1, 2147483647) then return end
    local session = VRPBridge.sessions[src] or newSession(src)
    local function reply(value)
        if session.active and VRPBridge.sessions[src] == session then
            TriggerClientEvent('oph3z-phone:vrp:response', src, id, value)
        end
    end
    if type(name) ~= 'string' or not VRPBridge.callbacks[name] then reply(nil); return end
    local encoded, payload = pcall(json.encode, data)
    if not encoded or type(payload)~='string' or #payload > 131072 then reply(nil); return end
    local now = GetGameTimer()
    if now - session.window >= 1000 then session.window, session.count = now, 0 end
    session.count = session.count + 1
    if session.count > 60 or session.queued >= 20 then reply(nil); return end
    session.queued = session.queued + 1
    local deadline = now + options.CallbackTimeout
    while session.busy do
        if not session.active or GetGameTimer() >= deadline then
            session.queued = session.queued - 1; reply(nil); return
        end
        Wait(10)
    end
    if not session.active then session.queued = session.queued - 1; return end
    session.busy = true
    local ok, value = pcall(function()
        if not VRPBridge.UserId(src) then return nil end
        if Config.RequireItem and name ~= 'oph3z-phone:server:hasItem' and not HasPhoneItem(src) then return nil end
        return VRPBridge.callbacks[name](src, data)
    end)
    session.busy = false; session.queued = session.queued - 1
    if not ok then print(('[oph3z-phone/vrp] Callback %s: %s'):format(name,tostring(value))); reply(nil)
    else reply(value) end
end)
AddEventHandler('playerDropped', function()
    local session = VRPBridge.sessions[source]
    if session then session.active = false end
    VRPBridge.sessions[source] = nil
end)
