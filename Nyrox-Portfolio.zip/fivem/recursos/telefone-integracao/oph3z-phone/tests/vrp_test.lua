local passed=0
local function test(name,fn) fn();passed=passed+1;print('PASS '..name) end
local function fixture(style)
    local f={bank={[1]=100,[2]=100},players={[1]=101,[2]=202},events={},replies={},exported={},writes=0,clock=0}
    dofile('config.lua')
    Config.VRP.CallStyle=style or 'direct'
    local core={
        getUserId=function(src) for uid,s in pairs(f.players) do if s==src then return uid end end end,
        getUserSource=function(uid)return f.players[uid] end,
        getUserIdentity=function(uid)return {name='Name'..uid,firstname='Last',phone='111-'..uid} end,
        getBankMoney=function(uid)return f.bank[uid] end,
        setBankMoney=function(uid,value)
            if f.failBefore==uid then error('expected failure') end
            f.bank[uid]=value;f.writes=f.writes+1
            if f.failAfter==uid then error('expected persisted-write error') end
        end,
        getInventoryItemAmount=function(uid,item)return f.item or 0 end,
        hasPermission=function()return true end,
    }
    if style=='table' then
        for name,fn in pairs(core) do core[name]=function(args)return fn(table.unpack(args)) end end
    end
    function module(_,lib) assert(lib=='lib/Proxy');return {getInterface=function()return core end} end
    function GetGameTimer()return f.clock end
    function Wait(ms)f.clock=f.clock+math.max(ms,1) end
    Citizen={CreateThread=function(fn)fn()end,Wait=Wait}
    CreateThread=Citizen.CreateThread
    function IsDuplicityVersion()return true end
    function RegisterNetEvent(name,fn)f.events[name]=fn end
    function AddEventHandler(name,fn)f.events[name]=fn end
    function TriggerClientEvent(name,src,id,value) f.replies[#f.replies+1]={event=name,source=src,id=id,value=value} end
    json={encode=function(data)return tostring(data) end}
    exports=setmetatable({}, {__call=function(_,name,fn)f.exported[name]=fn end})
    dofile('GetCore.lua')
    dofile('server/vrp_bridge.lua')
    dofile('server/utilities.lua')
    f.core=core
    return f
end

test('vRPex direct API resolves ID, identity and source',function()
    fixture();assert(GetIdentifier(101)=='vrp_1');assert(GetSourceById('vrp_2')==202)
    local a,b=GetCharName(101);assert(a=='Name1' and b=='Last');assert(GetVRPPhoneNumber('vrp_1')=='1111')
end)
test('classic table-argument API works',function()
    fixture('table');assert(GetIdentifier(101)=='vrp_1');assert(Bank.Get('vrp_1')==100)
end)
test('inventory item checked through vRP',function()
    local f=fixture();assert(not HasPhoneItem(101));f.item=1;assert(HasPhoneItem(101));assert(not HasPhoneItem(999))
end)
test('balance belongs to vRP account, not client-selected source',function()
    local f=fixture();assert(Bank.Transfer('vrp_1','vrp_2',25));assert(f.bank[1]==75 and f.bank[2]==125)
end)
test('invalid, negative, excessive, non-finite and fractional transfers rejected',function()
    local f=fixture();for _,amount in ipairs({0,-1,1.5,math.huge,'invalid',10000001})do assert(not Bank.Transfer('vrp_1','vrp_2',amount))end
    assert(f.writes==0);assert(not Bank.Transfer('vrp_1','vrp_1',10));assert(not Bank.Transfer('not-a-cid','vrp_2',10))
end)
test('exact remaining balance allowed',function()
    local f=fixture();assert(Bank.Transfer('vrp_1','vrp_2',100));assert(f.bank[1]==0)
end)
test('insufficient funds and offline recipient rejected',function()
    local f=fixture();assert(not Bank.Transfer('vrp_1','vrp_2',101));f.players[2]=nil
    local ok,why=Bank.Transfer('vrp_1','vrp_2',10);assert(not ok and why=='offline');assert(f.writes==0)
end)
test('failed debit never credits recipient',function()
    local f=fixture();f.failBefore=1;assert(not Bank.Transfer('vrp_1','vrp_2',10));assert(f.writes==0)
end)
test('failed credit restores debit when state is confirmed',function()
    local f=fixture();f.failBefore=2;assert(not Bank.Transfer('vrp_1','vrp_2',10));assert(f.bank[1]==100 and f.bank[2]==100);assert(next(VRPBridge.locks)==nil)
end)
test('persisted credit is not refunded twice after error',function()
    local f=fixture();f.failAfter=2;assert(Bank.Transfer('vrp_1','vrp_2',10));assert(f.bank[1]==90 and f.bank[2]==110)
end)
test('native RPC resolves actor on server and returns a result',function()
    local f=fixture();RegisterCallback('oph3z-phone:server:test',function(src,data)return {uid=VRPBridge.UserId(src),input=data.text}end)
    source=101;f.events['oph3z-phone:vrp:request'](1,'oph3z-phone:server:test',{source=202,text='ok'})
    assert(f.replies[1].value.uid==1 and f.replies[1].value.input=='ok')
end)
test('RPC denies unknown methods and unidentified players',function()
    local f=fixture();source=101;f.events['oph3z-phone:vrp:request'](1,'constructor',{})
    assert(f.replies[1].value==nil)
    RegisterCallback('oph3z-phone:server:test',function()error('must not run')end)
    source=999;f.events['oph3z-phone:vrp:request'](2,'oph3z-phone:server:test',{})
    assert(f.replies[2].value==nil)
end)
test('RPC exceptions respond and do not leave queue locked',function()
    local f=fixture();RegisterCallback('oph3z-phone:server:test',function()error('expected callback failure')end)
    source=101;f.events['oph3z-phone:vrp:request'](1,'oph3z-phone:server:test',{})
    assert(#f.replies==1 and not VRPBridge.sessions[101].busy)
end)
test('optional item requirement enforced on server callbacks',function()
    local f=fixture();Config.RequireItem=true;local called=false
    RegisterCallback('oph3z-phone:server:test',function()called=true;return true end)
    source=101;f.events['oph3z-phone:vrp:request'](1,'oph3z-phone:server:test',{})
    assert(not called);f.item=1;f.events['oph3z-phone:vrp:request'](2,'oph3z-phone:server:test',{});assert(called)
end)
test('disconnect clears RPC session',function()
    local f=fixture();source=101;f.events['oph3z-phone:vrp:request'](1,'unknown',{});local old=VRPBridge.sessions[101]
    f.events.playerDropped();assert(VRPBridge.sessions[101]==nil and not old.active)
end)

local function mockDB(f)
    BillsProvider={}
    local docs={}
    DB={
        LoadOrCreate=function(cid)docs[cid]=docs[cid] or {};return docs[cid]end,
        SaveNow=function()return true end,
        EnsurePhone=function(cid,doc)doc.phone=doc.phone or {numberRaw=cid=='vrp_1' and '1111' or '2222'};return doc end,
        Digits=function(s)return tostring(s):gsub('%D','')end,
        ResolveContact=function()return nil end,
        FormatNumber=function(s)return s end,
        GetCitizenIdByNumber=function(s)return s=='2222' and 'vrp_2' or nil end,
    }
    return docs
end
test('wallet toId uses vRP user ID, not server source ID',function()
    local f=fixture();mockDB(f);dofile('server/app/wallet/main.lua')
    local res=VRPBridge.callbacks['oph3z-phone:server:wallet:send'](101,{toId=2,amount=10})
    assert(res.ok and f.bank[1]==90 and f.bank[2]==110)
    assert(VRPBridge.callbacks['oph3z-phone:server:wallet:get'](101).serverId==1)
end)
test('internal vRP invoices can be issued and paid only once',function()
    local f=fixture();mockDB(f);dofile('server/app/wallet/billing/vrp.lua')
    local id=f.exported.CreateVRPInvoice(1,2,30,'Repair','Mechanic');assert(id==1)
    assert(#BillsProvider.Get('vrp_1')==1)
    assert(not BillsProvider.Pay('vrp_1',202,id).ok)
    assert(BillsProvider.Pay('vrp_1',101,id).ok);assert(not BillsProvider.Pay('vrp_1',101,id).ok)
    assert(f.bank[1]==70 and f.bank[2]==130 and #BillsProvider.Get('vrp_1')==0)
end)
print('ALL '..passed..' VRP SERVER TESTS PASSED')
