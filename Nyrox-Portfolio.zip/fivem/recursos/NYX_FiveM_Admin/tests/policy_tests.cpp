#include "../source/policy.hpp"
#include <cassert>
#include <iostream>
#include <limits>
int main() {
    using namespace nyx;
    assert(validToken(std::wstring(64,L'a')));
    assert(!validToken(std::wstring(63,L'a')));
    assert(!validToken(std::wstring(64,L'g')));
    assert(!validToken(std::wstring(62,L'a')+L"\r\n"));
    assert(safeEndpoint(L"http",L"127.0.0.1",L"/nyx_admin",L"",L"",L""));
    assert(safeEndpoint(L"http",L"[::1]",L"/nyx_admin",L"",L"",L""));
    assert(safeEndpoint(L"https",L"admin.example.test",L"/nyx_admin",L"",L"",L""));
    assert(!safeEndpoint(L"http",L"admin.example.test",L"/nyx_admin",L"",L"",L""));
    assert(!safeEndpoint(L"http",L"127.0.0.1.evil.test",L"/nyx_admin",L"",L"",L""));
    assert(!safeEndpoint(L"https",L"server",L"/nyx_admin",L"user",L"password",L""));
    assert(!safeEndpoint(L"https",L"server",L"/nyx_admin",L"",L"",L"?token=leak"));
    assert(!safeEndpoint(L"https",L"server",L"/other",L"",L"",L""));
    unsigned target=0;
    assert(parseTarget(L"0",target) && target==0);
    assert(parseTarget(L"65535",target) && target==65535);
    assert(!parseTarget(L"65536",target));
    assert(!parseTarget(L"-1",target));
    assert(!parseTarget(L"1abc",target));
    assert(!parseTarget(L"",target));
    assert(!validCoordinate(std::numeric_limits<double>::infinity(),false));
    assert(!validCoordinate(std::numeric_limits<double>::quiet_NaN(),true));
    assert(!validCoordinate(2001.0,true));
    assert(validCoordinate(-8000.0,false));
    std::cout << "PASS: 23 endpoint, token, target and coordinate policy assertions\n";
}
