-- Exercises the actual server.lua HTTP handler under controlled FiveM mocks.
dofile('resource/nyx_admin/config.lua')
dofile('resource/nyx_admin/core.lua')
local C = NyxCore
local validToken = string.rep('a', 64)
local identifier = 'license:owner'
Config.Operators[1].identifier = identifier
local permitted, online, bucket, now = {}, true, 0, 10000
local handlers, netHandlers, timers, effects = {}, {}, {}, {}
local testBody = nil
json = { encode = function(value) return value end, decode = function() return testBody end }
GetPlayerIdentifiers = function(id) return id == 7 and {identifier} or {'license:other'} end
GetPlayers = function() return online and {'7','8'} or {'8'} end
GetPlayerName = function(id) if id == 7 and online then return 'Owner' end; if id == 8 then return 'Other' end end
IsPlayerAceAllowed = function(_, permission) return permitted[permission] == true end
GetConvar = function() return validToken end
GetGameTimer = function() now = now + 1000; return now end
GetCurrentResourceName = function() return 'nyx_admin' end
GetPlayerRoutingBucket = function(id) return id == 8 and bucket or 0 end
GetPlayerPed = function() return 50 end
DoesEntityExist = function() return true end
GetEntityCoords = function() return {x=0,y=0,z=10} end
GetEntityHeading = function() return 0 end
GetHashKey = function() return 123 end
CreateVehicleServerSetter = function(...) effects[#effects+1] = {'vehicle',...}; return 99 end
SetEntityRoutingBucket = function(...) effects[#effects+1] = {'bucket',...} end
SetEntityOrphanMode = function() end
NetworkGetNetworkIdFromEntity = function() return 123 end
DeleteEntity = function(...) effects[#effects+1] = {'delete',...} end
TriggerClientEvent = function(...) effects[#effects+1] = {'event',...} end
SetTimeout = function(_, callback) timers[#timers+1] = callback end
RegisterNetEvent = function(name, callback) netHandlers[name] = callback end
AddEventHandler = function(name, callback) handlers[name] = callback end
SetHttpHandler = function(callback) handlers.http = callback end
CreateThread = function() end
print = function() end
dofile('resource/nyx_admin/server.lua')
local checks=0
local function expect(condition, description)
    checks=checks+1
    assert(condition, description)
end
local function request(path, method, body, overrides)
    testBody=body
    local reply={}
    local req={address='127.0.0.1:54444',path=path,method=method,
        headers={Authorization='Bearer '..validToken,['Content-Type']='application/json'},
        setDataHandler=function(callback) callback('{}') end}
    for key,value in pairs(overrides or {}) do req[key]=value end
    handlers.http(req,{writeHead=function(code) reply.code=code end, send=function(value) reply.value=value end})
    return reply
end
local function allow(action)
    permitted={['nyx_admin.use']=true}
    if action then permitted['nyx_admin.'..action]=true end
end
allow('spawn_vehicle')
expect(request('/status','GET',nil,{address='198.51.100.5:30000'}).code==403,'remote API denied')
expect(request('/status','GET',nil,{headers={Authorization='Bearer wrong'}}).code==401,'bad token denied')
local mismatch=string.rep('b',64)
expect(request('/status','GET',nil,{headers={Authorization='Bearer '..mismatch}}).code==401,'valid-format wrong token denied')
expect(request('/status','GET',nil,{headers={}}).code==401,'missing token denied')
online=false
expect(request('/status','GET').code==403,'offline operator denied')
online=true; permitted={}
expect(request('/status','GET').code==403,'base ACE required')
allow()
expect(request('/status','GET').code==200,'configured online account accepted')
expect(request('/players','GET').code==403,'player list has separate permission')
allow('players')
expect(request('/players','GET').code==200,'player list allowed')
allow()
local before=#effects
expect(request('/action','POST',{action='spawn_vehicle',model='adder'}).code==403,'spawn ACE required')
expect(#effects==before,'denied spawn has no effect')
allow('spawn_vehicle')
expect(request('/action','POST',{action='spawn_vehicle',model='bad_model'}).code==400,'vehicle allowlist enforced')
expect(request('/action','POST',{action='spawn_vehicle',model='adder',target=8}).code==400,'vehicle spawn self only')
expect(request('/action','POST',{action='execute',event='bank:addMoney'}).code==400,'arbitrary events rejected')
expect(request('/action','POST',{action='grant_staff',target=8}).code==400,'staff escalation rejected')
expect(request('/action','POST',{action='spawn_vehicle',model='adder',amount=10}).code==400,'unexpected fields rejected')
expect(request('/action','POST',{action='spawn_vehicle',model='adder'}).code==201,'authorized spawn succeeds')
expect(#effects>before,'authorized spawn dispatches native')
allow('revive'); bucket=1
expect(request('/action','POST',{action='revive',target=8}).code==403,'different routing bucket denied')
bucket=0
expect(request('/action','POST',{action='revive',target=9}).code==404,'offline target denied')
local queued=request('/action','POST',{action='revive',target=8})
expect(queued.code==nil,'reply waits for target acknowledgement')
local last=effects[#effects]
local id=last[4]
source=7; netHandlers['nyx_admin:ack'](id,true)
expect(queued.code==nil,'wrong player cannot acknowledge another target')
source=8; netHandlers['nyx_admin:ack'](id,true)
expect(queued.code==200,'correct target can acknowledge')
netHandlers['nyx_admin:ack'](id,true)
expect(queued.code==200,'duplicate acknowledgement has no new effect')
allow('god_on')
expect(request('/action','POST',{action='god_on',target=8}).code==400,'god mode self only')
allow('teleport')
expect(request('/action','POST',{action='teleport',x=math.huge,y=0,z=0}).code==400,'non-finite teleport rejected')
expect(request('/action','POST',{action='teleport',x=0,y=0,z=2001}).code==400,'out-of-bounds teleport rejected')
expect(request('/action','POST',{action='revive',target=-1}).code==400,'negative target rejected')
expect(request('/action','POST',{action='revive',target=7.5}).code==400,'fractional target rejected')
expect(request('/action','POST',{action='revive',target=65536}).code==400,'oversized target rejected')
expect(request('/action','POST',{}, {headers={Authorization='Bearer '..validToken,['Content-Type']='text/plain'}}).code==415,'content type enforced')
expect(request('/action','POST',{}, {headers={Authorization='Bearer '..validToken,['Content-Type']='application/json',['Content-Length']='99999'}}).code==413,'body bound enforced')
expect(request('/not-an-endpoint','GET').code==404,'unknown endpoint rejected')
expect(C.loopback('::1') and not C.loopback('127.0.0.1.evil:443'),'loopback parsing does not use prefix matching')
expect(C.secureEqual(validToken,validToken) and not C.secureEqual(validToken,mismatch),'token comparison')
-- Requests with delayed bodies are checked again against the current operator.
local delayed
local deferred=request('/action','POST',{}, {setDataHandler=function(callback) delayed=callback end})
online=false; testBody={action='teleport',x=1,y=2,z=3}; delayed('{}')
expect(deferred.code==403,'operator disconnect during body collection is denied')
online=true; allow('revive')
local unconfirmed=request('/action','POST',{action='revive',target=8})
expect(unconfirmed.code==nil,'unconfirmed request remains pending')
local actionTimer=timers[#timers-1]
actionTimer()
expect(unconfirmed.code==504,'missing acknowledgement times out honestly')
local disconnectReply=request('/action','POST',{action='revive',target=8})
source=8; handlers.playerDropped()
expect(disconnectReply.code==409,'disconnect closes pending target request')
GetGameTimer=function() return now end
request('/status','GET')
expect(request('/status','GET').code==429,'request rate limit enforced')
io.write('PASS: '..checks..' server authorization and dispatch assertions\n')
