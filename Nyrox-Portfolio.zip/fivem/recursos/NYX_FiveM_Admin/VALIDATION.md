# Validation

Build date: 12 October 2026.

## Completed checks

- Native Windows x64 GUI executable compiled with MinGW-w64 GCC 13.2.
- C++17 build used `-Wall -Wextra -Wpedantic -Werror`; the final build emitted no warnings or errors.
- All six Lua files passed Lua 5.4 syntax checks.
- 23 C++ policy assertions passed: private token format, local HTTP restriction, HTTPS URL rules,
  user-info/query rejection, player ID bounds and finite coordinate bounds.
- 40 server authorization/dispatch assertions passed against the actual resource handler with
  controlled FiveM mocks: non-loopback denial, token denial, offline operator denial, per-action ACE
  checks, allowlists, self-only actions, routing bucket checks, target existence, arbitrary-action
  rejection, unexpected field rejection, body limits, acknowledgement source checks, disconnects,
  body collection session rechecks, client timeout and request rate limiting.
- PE headers identify an x64 Windows GUI executable. All raw section bounds fit inside the file.
- High-entropy ASLR, dynamic base and NX flags are present.
- Imported DLLs are Windows system libraries: COMCTL32, GDI32, KERNEL32, msvcrt, USER32 and WINHTTP.

## Executable integrity

Size: 2,384,149 bytes.

SHA-256:

```text
3cda690c6ce707c3807b706c5e92081c21e57be17fa0d853f13ee2f540fd9e2d
```

## Live testing still required

The Windows GUI and FiveM natives have not been executed in a Windows/FiveM session here.
No live server credentials, running server or game session were supplied.
Offline mocks verify authorization and dispatch logic, not native behaviour or framework integration.

On your test server, install the resource and configure the license, token and ACE permissions.
Confirm connection and player listing first. Then test one vehicle spawn, one native weapon grant,
one revive, god-mode enable/disable, one teleport and a nearby vehicle lock/unlock.
Check your server's inventory, hospital and vehicle key resources for compatibility.
