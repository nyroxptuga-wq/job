@echo off
setlocal
cd /d "%~dp0"
where x86_64-w64-mingw32-g++.exe >nul 2>nul
if errorlevel 1 (
  echo Install a MinGW-w64 C++ toolchain and add its bin directory to PATH.
  exit /b 1
)
x86_64-w64-mingw32-g++.exe -std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror -municode -mwindows -static -static-libgcc -static-libstdc++ main.cpp -o ..\NYX_FiveM_Admin.exe -lwinhttp -lcomctl32 -lgdi32 -luser32 -luxtheme -Wl,--dynamicbase,--nxcompat,--high-entropy-va
exit /b %errorlevel%
