#pragma once
#include <cmath>
#include <cwctype>
#include <string>

namespace nyx {
inline bool validToken(const std::wstring& token) {
    if (token.size() != 64) return false;
    for (const wchar_t c : token) {
        if (!((c >= L'0' && c <= L'9') || (c >= L'a' && c <= L'f') || (c >= L'A' && c <= L'F'))) return false;
    }
    return true;
}
inline bool safeEndpoint(const std::wstring& scheme, const std::wstring& host,
                         const std::wstring& path, const std::wstring& user,
                         const std::wstring& password, const std::wstring& extra) {
    if (host.empty() || !user.empty() || !password.empty() || !extra.empty()) return false;
    if (path != L"/nyx_admin") return false;
    if (scheme == L"https") return true;
    return scheme == L"http" && (host == L"127.0.0.1" || host == L"localhost" || host == L"::1" || host == L"[::1]");
}
inline bool parseTarget(const std::wstring& text, unsigned& result) {
    if (text.empty() || text.size() > 5) return false;
    unsigned value = 0;
    for (const wchar_t c : text) {
        if (c < L'0' || c > L'9') return false;
        value = value * 10 + static_cast<unsigned>(c - L'0');
    }
    if (value > 65535) return false;
    result = value;
    return true;
}
inline bool validCoordinate(double value, bool z) {
    return std::isfinite(value) && std::abs(value) <= (z ? 2000.0 : 8000.0);
}
}
