#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <winhttp.h>
#include <commctrl.h>
#include <uxtheme.h>
#include <algorithm>
#include <iomanip>
#include <locale>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "policy.hpp"

namespace {
constexpr UINT Finished = WM_APP + 1;
constexpr COLORREF Background = RGB(13, 17, 25), Panel = RGB(22, 28, 40);
constexpr COLORREF Text = RGB(227, 234, 248), Muted = RGB(161, 175, 198), Accent = RGB(96, 169, 255);
enum Id { Url=101, Token, Target, Model, Weapon, X, Y, Z, Output,
    Connect=201, Players, Vehicle, GiveWeapon, Revive, GodOn, GodOff, Lock, Unlock, Teleport, Clear };
HWND windowHandle = nullptr;
HINSTANCE instanceHandle = nullptr;
HFONT normalFont = nullptr, titleFont = nullptr, monoFont = nullptr;
HBRUSH backgroundBrush = nullptr, panelBrush = nullptr;
bool busy = false;
std::vector<HWND> buttons;

std::wstring value(int id) {
    HWND control = GetDlgItem(windowHandle, id);
    int n = GetWindowTextLengthW(control);
    std::wstring text(static_cast<size_t>(n) + 1, L'\0');
    GetWindowTextW(control, text.data(), n + 1);
    text.resize(static_cast<size_t>(n));
    return text;
}

std::wstring decodeUtf8(const std::string& text) {
    if (text.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), nullptr, 0);
    if (n <= 0) return L"Server returned invalid UTF-8.";
    std::wstring out(static_cast<size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), out.data(), n);
    return out;
}

void status(const std::wstring& message) {
    SetWindowTextW(GetDlgItem(windowHandle, Output), message.c_str());
}

HWND control(const wchar_t* cls, const wchar_t* text, DWORD style, int id,
             int x, int y, int width, int height, HFONT font = nullptr) {
    HWND h = CreateWindowExW(0, cls, text, WS_CHILD | WS_VISIBLE | style,
        x, y, width, height, windowHandle, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), instanceHandle, nullptr);
    SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(font ? font : normalFont), TRUE);
    return h;
}

void label(const wchar_t* text, int x, int y, int width) {
    control(L"STATIC", text, 0, 0, x, y, width, 22);
}
void button(const wchar_t* text, int id, int x, int y, int width) {
    buttons.push_back(control(L"BUTTON", text, BS_OWNERDRAW | WS_TABSTOP, id, x, y, width, 34));
}
HWND edit(const wchar_t* text, int id, int x, int y, int width, DWORD extra = 0) {
    return control(L"EDIT", text, WS_BORDER | WS_TABSTOP | ES_AUTOHSCROLL | extra, id, x, y, width, 30);
}
void combo(int id, int x, int y, int width, const std::vector<const wchar_t*>& entries) {
    HWND h = control(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, id, x, y, width, 180);
    for (const auto* item : entries) SendMessageW(h, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(item));
    SendMessageW(h, CB_SETCURSEL, 0, 0);
}

struct Internet {
    HINTERNET handle;
    explicit Internet(HINTERNET h) : handle(h) {}
    ~Internet() { if (handle) WinHttpCloseHandle(handle); }
    Internet(const Internet&) = delete;
    Internet& operator=(const Internet&) = delete;
};
struct Request {
    HWND targetWindow;
    std::wstring url, token, path, method;
    std::string body;
    ~Request() { if (!token.empty()) SecureZeroMemory(token.data(), token.size() * sizeof(wchar_t)); }
};

std::wstring segment(LPWSTR pointer, DWORD length) {
    return pointer && length ? std::wstring(pointer, length) : std::wstring();
}
std::wstring lower(std::wstring text) {
    std::transform(text.begin(), text.end(), text.begin(), [](wchar_t c){ return std::towlower(c); });
    return text;
}
bool crack(const std::wstring& url, URL_COMPONENTS& parts) {
    parts = {};
    parts.dwStructSize = sizeof(parts);
    parts.dwSchemeLength = parts.dwHostNameLength = parts.dwUrlPathLength = static_cast<DWORD>(-1);
    parts.dwUserNameLength = parts.dwPasswordLength = parts.dwExtraInfoLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(url.c_str(), static_cast<DWORD>(url.size()), 0, &parts)) return false;
    return nyx::safeEndpoint(lower(segment(parts.lpszScheme, parts.dwSchemeLength)),
        lower(segment(parts.lpszHostName, parts.dwHostNameLength)), segment(parts.lpszUrlPath, parts.dwUrlPathLength),
        segment(parts.lpszUserName, parts.dwUserNameLength), segment(parts.lpszPassword, parts.dwPasswordLength),
        segment(parts.lpszExtraInfo, parts.dwExtraInfoLength));
}

void require(bool ok, const char* what) {
    if (!ok) throw std::runtime_error(std::string(what) + " (Windows error " + std::to_string(GetLastError()) + ").");
}

std::wstring perform(Request& data) {
    URL_COMPONENTS parts{};
    if (!crack(data.url, parts)) throw std::runtime_error("Unsafe or invalid server URL.");
    const std::wstring host = segment(parts.lpszHostName, parts.dwHostNameLength);
    const std::wstring path = segment(parts.lpszUrlPath, parts.dwUrlPathLength) + data.path;
    const bool secure = parts.nScheme == INTERNET_SCHEME_HTTPS;
    const DWORD access = secure ? WINHTTP_ACCESS_TYPE_DEFAULT_PROXY : WINHTTP_ACCESS_TYPE_NO_PROXY;
    Internet session(WinHttpOpen(L"NYX-FiveM-Admin/1.0", access,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0));
    require(session.handle != nullptr, "Cannot start HTTP session");
    require(WinHttpSetTimeouts(session.handle, 4000, 4000, 5000, 12000) != FALSE, "Cannot configure timeouts");
    Internet connection(WinHttpConnect(session.handle, host.c_str(), parts.nPort, 0));
    require(connection.handle != nullptr, "Cannot connect");
    const DWORD flags = secure ? WINHTTP_FLAG_SECURE : 0;
    Internet request(WinHttpOpenRequest(connection.handle, data.method.c_str(), path.c_str(), nullptr,
        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, flags));
    require(request.handle != nullptr, "Cannot create request");
    DWORD policy = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
    require(WinHttpSetOption(request.handle, WINHTTP_OPTION_REDIRECT_POLICY, &policy, sizeof(policy)) != FALSE,
        "Cannot disable redirects");
    std::wstring headers = L"Authorization: Bearer " + data.token + L"\r\nContent-Type: application/json\r\n";
    BOOL sent = WinHttpSendRequest(request.handle, headers.c_str(), static_cast<DWORD>(headers.size()),
        data.body.empty() ? WINHTTP_NO_REQUEST_DATA : data.body.data(),
        static_cast<DWORD>(data.body.size()), static_cast<DWORD>(data.body.size()), 0);
    SecureZeroMemory(headers.data(), headers.size() * sizeof(wchar_t));
    require(sent != FALSE, "Cannot send request");
    require(WinHttpReceiveResponse(request.handle, nullptr) != FALSE, "Cannot receive server response");
    DWORD code = 0, size = sizeof(code);
    require(WinHttpQueryHeaders(request.handle, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
        WINHTTP_HEADER_NAME_BY_INDEX, &code, &size, WINHTTP_NO_HEADER_INDEX) != FALSE, "Missing HTTP status");
    std::string body;
    char chunk[4096];
    for (;;) {
        DWORD count = 0;
        require(WinHttpReadData(request.handle, chunk, sizeof(chunk), &count) != FALSE, "Cannot read response");
        if (count == 0) break;
        if (body.size() + count > 262144) throw std::runtime_error("Response size limit exceeded.");
        body.append(chunk, count);
    }
    return L"HTTP " + std::to_wstring(code) + L"\r\n\r\n" + decodeUtf8(body);
}

DWORD WINAPI worker(void* argument) {
    std::unique_ptr<Request> request(static_cast<Request*>(argument));
    auto message = std::make_unique<std::wstring>();
    try { *message = perform(*request); }
    catch (const std::exception& error) { *message = L"Connection failed.\r\n\r\n" + decodeUtf8(error.what()); }
    catch (...) { *message = L"Unexpected request error."; }
    if (PostMessageW(request->targetWindow, Finished, 0, reinterpret_cast<LPARAM>(message.get()))) message.release();
    return 0;
}

bool coordinate(int id, double& result, bool z) {
    const auto text = value(id);
    wchar_t* end = nullptr;
    result = std::wcstod(text.c_str(), &end);
    return !text.empty() && end == text.c_str() + text.size() && nyx::validCoordinate(result, z);
}

void start(int id) {
    if (busy) return;
    auto request = std::make_unique<Request>();
    request->targetWindow = windowHandle;
    request->url = value(Url);
    request->token = value(Token);
    URL_COMPONENTS components{};
    if (!crack(request->url, components)) {
        status(L"Enter http://127.0.0.1:30120/nyx_admin for a local server or SSH tunnel.\r\n"
               L"HTTPS is also supported through your own TLS reverse proxy. No credentials, query or fragment in URL."); return;
    }
    if (!nyx::validToken(request->token)) { status(L"Enter the 64-character hexadecimal operator token from your server configuration."); return; }
    if (id == Connect || id == Players) {
        request->method = L"GET";
        request->path = id == Connect ? L"/status" : L"/players";
    } else {
        request->method = L"POST"; request->path = L"/action";
        const char* action = nullptr;
        switch (id) {
            case Vehicle: action="spawn_vehicle"; break;
            case GiveWeapon: action="give_weapon"; break;
            case Revive: action="revive"; break;
            case GodOn: action="god_on"; break;
            case GodOff: action="god_off"; break;
            case Lock: action="lock_vehicle"; break;
            case Unlock: action="unlock_vehicle"; break;
            case Teleport: action="teleport"; break;
            default: return;
        }
        unsigned target = 0;
        if ((id == GiveWeapon || id == Revive) && !nyx::parseTarget(value(Target), target)) {
            status(L"Target must be a server ID from 1 to 65535, or 0 for yourself."); return;
        }
        if (id == GiveWeapon || id == Revive) {
            const std::wstring confirm = L"Apply " + decodeUtf8(action) + L" to " +
                (target ? L"server ID " + std::to_wstring(target) : std::wstring(L"your own player")) + L"?";
            if (MessageBoxW(windowHandle, confirm.c_str(), L"Confirm admin action", MB_OKCANCEL | MB_ICONQUESTION) != IDOK) return;
        }
        std::ostringstream body;
        body.imbue(std::locale::classic());
        body << "{\"action\":\"" << action << "\",\"target\":" << target;
        if (id == Vehicle || id == GiveWeapon) {
            const std::wstring selected = value(id == Vehicle ? Model : Weapon);
            const std::string item(selected.begin(), selected.end());
            body << (id == Vehicle ? ",\"model\":\"" : ",\"weapon\":\"") << item << '"';
        }
        if (id == Teleport) {
            double x=0, y=0, z=0;
            if (!coordinate(X, x, false) || !coordinate(Y, y, false) || !coordinate(Z, z, true)) {
                status(L"Enter finite X/Y coordinates from -8000 to 8000 and Z from -2000 to 2000. Use a decimal point."); return;
            }
            body << std::setprecision(17) << ",\"x\":" << x << ",\"y\":" << y << ",\"z\":" << z;
        }
        body << '}'; request->body = body.str();
    }
    busy = true;
    for (HWND h : buttons) EnableWindow(h, FALSE);
    status(L"Waiting for the server...\r\nThe server will check your token, connected account and action permission.");
    HANDLE thread = CreateThread(nullptr, 0, worker, request.get(), 0, nullptr);
    if (!thread) {
        busy = false;
        for (HWND h : buttons) EnableWindow(h, TRUE);
        status(L"Cannot start the request worker."); return;
    }
    request.release(); CloseHandle(thread);
}

LRESULT CALLBACK procedure(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
    switch (message) {
        case WM_CREATE: {
            windowHandle = hwnd;
            control(L"STATIC", L"NYX  /  FIVEM ADMIN", 0, 0, 26, 20, 780, 38, titleFont);
            label(L"Administrator tools for your server. Install the server resource before connecting.", 28, 60, 850);
            label(L"SERVER RESOURCE URL", 34, 106, 640);
            SendMessageW(edit(L"http://127.0.0.1:30120/nyx_admin", Url, 34, 132, 646), EM_SETLIMITTEXT, 512, 0);
            button(L"Check connection", Connect, 700, 130, 170);
            label(L"OPERATOR TOKEN  /  kept in memory only", 34, 176, 640);
            SendMessageW(edit(L"", Token, 34, 202, 646, ES_PASSWORD), EM_SETLIMITTEXT, 64, 0);
            button(L"List player IDs", Players, 700, 200, 170);
            label(L"TARGET ID", 34, 268, 130);
            SendMessageW(edit(L"0", Target, 34, 294, 110, ES_NUMBER), EM_SETLIMITTEXT, 5, 0);
            label(L"VEHICLE MODEL", 164, 268, 280);
            combo(Model, 164, 294, 144, {L"adder", L"sultan", L"buffalo", L"bati", L"sadler"});
            button(L"Spawn vehicle", Vehicle, 322, 292, 150);
            label(L"WEAPON", 496, 268, 320);
            combo(Weapon, 496, 294, 206, {L"WEAPON_PISTOL", L"WEAPON_STUNGUN", L"WEAPON_CARBINERIFLE"});
            button(L"Grant weapon", GiveWeapon, 718, 292, 152);
            label(L"0 = yourself. Target ID is used only for revive and weapon grants.", 34, 338, 830);
            button(L"Revive target", Revive, 34, 374, 156);
            button(L"God mode ON", GodOn, 204, 374, 156);
            button(L"God mode OFF", GodOff, 374, 374, 156);
            button(L"Lock closest", Lock, 544, 374, 156);
            button(L"Unlock closest", Unlock, 714, 374, 156);
            label(L"TELEPORT YOUR PLAYER  /  exact coordinates", 34, 448, 800);
            label(L"X", 34, 478, 30); label(L"Y", 236, 478, 30); label(L"Z", 438, 478, 30);
            edit(L"215.0", X, 64, 476, 148); edit(L"-810.0", Y, 266, 476, 148); edit(L"30.0", Z, 468, 476, 148);
            button(L"Teleport", Teleport, 650, 474, 220);
            label(L"SERVER RESPONSE", 28, 550, 650);
            button(L"Clear response", Clear, 700, 542, 170);
            HWND out = control(L"EDIT", L"Ready. Read README.md for server installation and permissions.",
                WS_BORDER | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL, Output,
                24, 592, 860, 135, monoFont);
            SendMessageW(out, EM_SETLIMITTEXT, 262144, 0);
            return 0;
        }
        case WM_COMMAND:
            if (HIWORD(wparam) == BN_CLICKED) {
                const int id = LOWORD(wparam);
                if (id == Clear) status(L"Ready.");
                else if (id >= Connect && id <= Teleport) start(id);
            }
            return 0;
        case Finished: {
            std::unique_ptr<std::wstring> reply(reinterpret_cast<std::wstring*>(lparam));
            status(*reply); busy = false;
            for (HWND h : buttons) EnableWindow(h, TRUE);
            return 0;
        }
        case WM_GETMINMAXINFO: {
            auto* limits = reinterpret_cast<MINMAXINFO*>(lparam);
            limits->ptMinTrackSize.x = 936; limits->ptMinTrackSize.y = 800; return 0;
        }
        case WM_SIZE:
            if (GetDlgItem(hwnd, Output)) MoveWindow(GetDlgItem(hwnd, Output), 24, 592,
                std::max(860, static_cast<int>(LOWORD(lparam)) - 48),
                std::max(120, static_cast<int>(HIWORD(lparam)) - 620), TRUE);
            InvalidateRect(hwnd, nullptr, TRUE); return 0;
        case WM_CTLCOLORSTATIC:
        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORLISTBOX: {
            HDC dc = reinterpret_cast<HDC>(wparam);
            SetTextColor(dc, Text);
            SetBkColor(dc, Panel);
            return reinterpret_cast<LRESULT>(panelBrush);
        }
        case WM_DRAWITEM: {
            const auto* draw = reinterpret_cast<DRAWITEMSTRUCT*>(lparam);
            if (draw->CtlType != ODT_BUTTON) break;
            bool enabled = (draw->itemState & ODS_DISABLED) == 0;
            HBRUSH brush = CreateSolidBrush(enabled ? RGB(38, 66, 101) : RGB(29, 35, 47));
            FillRect(draw->hDC, &draw->rcItem, brush); DeleteObject(brush);
            SetBkMode(draw->hDC, TRANSPARENT); SetTextColor(draw->hDC, enabled ? Text : Muted);
            SelectObject(draw->hDC, normalFont);
            wchar_t title[96]{}; GetWindowTextW(draw->hwndItem, title, 96);
            RECT rect=draw->rcItem;
            if (draw->itemState & ODS_SELECTED) OffsetRect(&rect, 1, 1);
            DrawTextW(draw->hDC, title, -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            if (draw->itemState & ODS_FOCUS) { InflateRect(&rect, -3, -3); DrawFocusRect(draw->hDC, &rect); }
            return TRUE;
        }
        case WM_PAINT: {
            PAINTSTRUCT paint{}; HDC dc = BeginPaint(hwnd, &paint);
            FillRect(dc, &paint.rcPaint, backgroundBrush);
            for (const RECT card : { RECT{24,98,884,244}, RECT{24,258,884,424}, RECT{24,438,884,520} })
                FillRect(dc, &card, panelBrush);
            HPEN pen = CreatePen(PS_SOLID, 2, Accent);
            HGDIOBJ old=SelectObject(dc,pen); MoveToEx(dc,24,86,nullptr); LineTo(dc,884,86);
            SelectObject(dc,old); DeleteObject(pen); EndPaint(hwnd,&paint); return 0;
        }
        case WM_CLOSE:
            if (busy) { MessageBoxW(hwnd, L"Wait for the current request to finish, then close the menu.",
                L"Request in progress", MB_OK | MB_ICONINFORMATION); return 0; }
            SetWindowTextW(GetDlgItem(hwnd, Token), L""); DestroyWindow(hwnd); return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd, message, wparam, lparam);
}
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    instanceHandle = instance;
    SetProcessDPIAware();
    INITCOMMONCONTROLSEX init{sizeof(init), ICC_STANDARD_CLASSES}; InitCommonControlsEx(&init);
    normalFont=CreateFontW(-15,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    titleFont=CreateFontW(-27,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
    monoFont=CreateFontW(-14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Consolas");
    backgroundBrush=CreateSolidBrush(Background); panelBrush=CreateSolidBrush(Panel);
    WNDCLASSW klass{};
    klass.lpfnWndProc=procedure; klass.hInstance=instance; klass.hCursor=LoadCursorW(nullptr,IDC_ARROW);
    klass.hbrBackground=backgroundBrush; klass.lpszClassName=L"NyxFiveMAdmin";
    klass.hIcon=LoadIconW(nullptr,IDI_APPLICATION);
    if (!RegisterClassW(&klass)) return 1;
    HWND hwnd=CreateWindowExW(0,klass.lpszClassName,L"NYX FiveM Admin 1.0",WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT,CW_USEDEFAULT,936,820,nullptr,nullptr,instance,nullptr);
    if (!hwnd) return 2;
    ShowWindow(hwnd,show); UpdateWindow(hwnd);
    MSG message{};
    while (GetMessageW(&message,nullptr,0,0)>0) {
        if (!IsDialogMessageW(hwnd,&message)) { TranslateMessage(&message); DispatchMessageW(&message); }
    }
    DeleteObject(normalFont); DeleteObject(titleFont); DeleteObject(monoFont);
    DeleteObject(backgroundBrush); DeleteObject(panelBrush);
    return 0;
}
