local godUntil, invincible = 0, false
local function setGod(enabled)
    SetPlayerInvincible(PlayerId(), enabled)
    SetEntityInvincible(PlayerPedId(), enabled)
    invincible = enabled
end

RegisterNetEvent('nyx_admin:lease', function(enabled)
    if source ~= 65535 then return end
    if enabled == true then godUntil = GetGameTimer() + 6000
    else godUntil = 0; setGod(false) end
end)

RegisterNetEvent('nyx_admin:apply', function(requestId, action)
    if source ~= 65535 or type(requestId) ~= 'string' or type(action) ~= 'table' then return end
    local ok = pcall(function()
        local ped = PlayerPedId()
        if action.action == 'give_weapon' then
            GiveWeaponToPed(ped, GetHashKey(action.weapon), action.ammo, false, true)
        elseif action.action == 'revive' then
            local pos, heading = GetEntityCoords(ped), GetEntityHeading(ped)
            NetworkResurrectLocalPlayer(pos.x, pos.y, pos.z, heading, true, false)
            ped = PlayerPedId()
            ClearPedTasksImmediately(ped)
            SetEntityHealth(ped, GetEntityMaxHealth(ped))
            ClearPedBloodDamage(ped)
        elseif action.action == 'god_on' then
            godUntil = GetGameTimer() + 6000
            setGod(true)
        elseif action.action == 'god_off' then
            godUntil = 0
            setGod(false)
        elseif action.action == 'teleport' then
            DoScreenFadeOut(150)
            Wait(180)
            RequestCollisionAtCoord(action.x, action.y, action.z)
            SetEntityCoords(ped, action.x, action.y, action.z, false, false, false, false)
            Wait(200)
            DoScreenFadeIn(150)
        else error('unknown client action') end
    end)
    if not ok then DoScreenFadeIn(150) end
    TriggerServerEvent('nyx_admin:ack', requestId, ok)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(ok and 'NYX: admin action received.' or 'NYX: admin action failed.')
    EndTextCommandThefeedPostTicker(false, false)
end)

CreateThread(function()
    while true do
        Wait(200)
        if godUntil > GetGameTimer() then setGod(true)
        elseif invincible then setGod(false) end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name == GetCurrentResourceName() then setGod(false) end
end)
