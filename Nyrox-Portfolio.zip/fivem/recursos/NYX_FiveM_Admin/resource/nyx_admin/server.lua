local C = NyxCore
local pending, lastRequest, vehicles, godPlayers = {}, {}, {}, {}
local sequence = 0

local function log(operator, action, target, result)
    print(('[nyx_admin] %s'):format(json.encode({ time = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        operator = operator, action = action, target = target, result = result })))
end

local function onlineIdentifier(id)
    for _, identifier in ipairs(GetPlayerIdentifiers(id)) do
        if identifier:match('^license:') then return identifier end
    end
end

local function actorFor(operator)
    if not operator then return nil end
    for _, player in ipairs(GetPlayers()) do
        local id = tonumber(player)
        for _, identifier in ipairs(GetPlayerIdentifiers(id)) do
            if identifier == operator.identifier and IsPlayerAceAllowed(id, 'nyx_admin.use') then
                return id
            end
        end
    end
end

local function authenticated(request)
    local auth = C.header(request.headers, 'Authorization')
    if not auth then return nil end
    local token = auth:match('^Bearer (%x+)$')
    if not C.validToken(token) then return nil end
    for _, operator in ipairs(Config.Operators) do
        local expected = GetConvar(operator.tokenConvar, '')
        if C.validToken(expected) and C.secureEqual(expected, token) then
            return operator
        end
    end
end

local function permitted(actor, action)
    return IsPlayerAceAllowed(actor, 'nyx_admin.use')
        and IsPlayerAceAllowed(actor, 'nyx_admin.' .. action)
end

local function complete(id, code, message)
    local item = pending[id]
    if not item then return end
    pending[id] = nil
    log(item.operator, item.action, item.target, message)
    item.reply(code, { message = message, request = id })
end

local function dispatch(operator, actor, action, reply)
    if not GetPlayerName(action.target) then
        reply(404, { message = 'Target is no longer connected.' }); return
    end
    if GetPlayerRoutingBucket(action.target) ~= GetPlayerRoutingBucket(actor) then
        reply(403, { message = 'Target must be in your routing bucket.' }); return
    end
    if not permitted(actor, action.action) then
        log(operator.name, action.action, action.target, 'permission denied')
        reply(403, { message = 'The server has not granted this action to your account.' }); return
    end
    local ped = GetPlayerPed(actor)
    if ped == 0 or not DoesEntityExist(ped) then
        reply(409, { message = 'Your player has not spawned yet.' }); return
    end
    if action.action == 'spawn_vehicle' then
        local position, heading = GetEntityCoords(ped), GetEntityHeading(ped)
        local radians = math.rad(heading)
        local vehicle = CreateVehicleServerSetter(GetHashKey(action.model), Config.Vehicles[action.model],
            position.x - math.sin(radians) * 4, position.y + math.cos(radians) * 4, position.z + 0.5, heading)
        if vehicle == 0 or not DoesEntityExist(vehicle) then
            reply(500, { message = 'Server could not create the vehicle.' }); return
        end
        SetEntityRoutingBucket(vehicle, GetPlayerRoutingBucket(actor))
        SetEntityOrphanMode(vehicle, 2)
        if vehicles[actor] and DoesEntityExist(vehicles[actor]) then DeleteEntity(vehicles[actor]) end
        vehicles[actor] = vehicle
        log(operator.name, action.action, actor, 'vehicle created')
        reply(201, { message = 'Vehicle created in front of you.', networkId = NetworkGetNetworkIdFromEntity(vehicle) })
        return
    end
    if action.action == 'lock_vehicle' or action.action == 'unlock_vehicle' then
        local position = GetEntityCoords(ped)
        local closest, distance = nil, Config.VehicleRadius
        for _, vehicle in ipairs(GetAllVehicles()) do
            if DoesEntityExist(vehicle) and GetEntityRoutingBucket(vehicle) == GetPlayerRoutingBucket(actor) then
                local value = #(GetEntityCoords(vehicle) - position)
                if value <= distance then closest, distance = vehicle, value end
            end
        end
        if not closest then reply(404, { message = 'No vehicle within 6 metres.' }); return end
        SetVehicleDoorsLocked(closest, action.action == 'lock_vehicle' and 2 or 1)
        log(operator.name, action.action, actor, 'vehicle lock requested')
        reply(200, { message = 'Server requested the closest vehicle lock change.' })
        return
    end
    sequence = sequence + 1
    local requestId = tostring(GetGameTimer()) .. '-' .. tostring(sequence)
    pending[requestId] = { actor = actor, target = action.target, operator = operator.name,
        action = action.action, reply = reply }
    if action.action == 'god_on' then
        godPlayers[actor] = { operator = operator, identifier = onlineIdentifier(actor) }
    elseif action.action == 'god_off' then godPlayers[actor] = nil end
    action.ammo = Config.Ammo
    TriggerClientEvent('nyx_admin:apply', action.target, requestId, action)
    SetTimeout(Config.ClientTimeoutMs, function()
        if pending[requestId] and action.action == 'god_on' then
            godPlayers[actor] = nil
            TriggerClientEvent('nyx_admin:lease', actor, false)
        end
        complete(requestId, 504, 'No client acknowledgement; action is unconfirmed.')
    end)
end

RegisterNetEvent('nyx_admin:ack', function(requestId, success)
    local actor = source
    if type(requestId) ~= 'string' or #requestId > 64 or type(success) ~= 'boolean' then return end
    local item = pending[requestId]
    if not item or item.target ~= actor then return end
    if not success and item.action == 'god_on' then
        godPlayers[item.actor] = nil
        TriggerClientEvent('nyx_admin:lease', item.actor, false)
    end
    complete(requestId, success and 200 or 500,
        success and 'Client acknowledged the action.' or 'Client reported that the action failed.')
end)

SetHttpHandler(function(request, response)
    local answered = false
    local function reply(code, value, plain)
        if answered then return end
        answered = true
        response.writeHead(code, { ['Content-Type'] = plain and 'text/plain; charset=utf-8' or 'application/json',
            ['Cache-Control'] = 'no-store', ['X-Content-Type-Options'] = 'nosniff' })
        response.send(plain and value or json.encode(value))
    end
    if not C.loopback(request.address) then reply(403, { message = 'API accepts loopback connections only.' }); return end
    local operator = authenticated(request)
    if not operator then reply(401, { message = 'Missing or invalid operator token.' }); return end
    local actor = actorFor(operator)
    if not actor then reply(403, { message = 'Operator must be connected and have nyx_admin.use permission.' }); return end
    local now = GetGameTimer()
    if lastRequest[actor] and now - lastRequest[actor] >= 0 and now - lastRequest[actor] < Config.RequestIntervalMs then
        reply(429, { message = 'Wait a moment before the next request.' }); return
    end
    lastRequest[actor] = now
    local path = request.path
    if request.method == 'GET' and path == '/status' then
        reply(200, { message = 'Authorized server connection.', actorId = actor, name = GetPlayerName(actor),
            resource = GetCurrentResourceName(), framework = 'standalone' }); return
    end
    if request.method == 'GET' and path == '/players' then
        if not permitted(actor, 'players') then reply(403, { message = 'Player list permission denied.' }); return end
        local lines = { ('YOUR SERVER ID: %d\r\n\r\nID     NAME (same routing bucket)'):format(actor) }
        for _, player in ipairs(GetPlayers()) do
            local id = tonumber(player)
            if GetPlayerRoutingBucket(id) == GetPlayerRoutingBucket(actor) then
                local name = (GetPlayerName(id) or ''):gsub('[%c]', ' ')
                lines[#lines + 1] = ('%-6d %s'):format(id, name)
            end
        end
        reply(200, table.concat(lines, '\r\n'), true); return
    end
    if request.method ~= 'POST' or path ~= '/action' then reply(404, { message = 'Unknown endpoint.' }); return end
    local contentType = C.header(request.headers, 'Content-Type') or ''
    if not contentType:lower():match('^application/json') then reply(415, { message = 'JSON body required.' }); return end
    local length = C.header(request.headers, 'Content-Length')
    if length and (not tonumber(length) or tonumber(length) > 4096 or tonumber(length) < 1) then
        reply(413, { message = 'Body size must be from 1 to 4096 bytes.' }); return
    end
    local bodyHandled = false
    request.setDataHandler(function(body)
        if bodyHandled or answered then return end
        bodyHandled = true
        if type(body) ~= 'string' or #body > 4096 or #body == 0 then reply(413, { message = 'Invalid body size.' }); return end
        local decoded, value = pcall(json.decode, body)
        if not decoded then reply(400, { message = 'Invalid JSON.' }); return end
        local currentActor = actorFor(operator)
        if currentActor ~= actor then reply(403, { message = 'Operator session changed.' }); return end
        local action, problem = C.validate(value, Config, actor)
        if not action then reply(400, { message = problem }); return end
        local ok, failure = pcall(dispatch, operator, actor, action, reply)
        if not ok then
            log(operator.name, action.action, action.target, 'runtime error: ' .. tostring(failure))
            reply(500, { message = 'Server runtime error; inspect the FXServer console.' })
        end
    end)
    SetTimeout(Config.ClientTimeoutMs + 1500, function()
        reply(408, { message = 'Request body or action timed out.' })
    end)
end)

CreateThread(function()
    while true do
        Wait(2000)
        for actor, data in pairs(godPlayers) do
            local allowed = actorFor(data.operator) == actor and onlineIdentifier(actor) == data.identifier
                and permitted(actor, 'god_on')
            if not allowed then godPlayers[actor] = nil end
            TriggerClientEvent('nyx_admin:lease', actor, allowed)
        end
    end
end)

AddEventHandler('playerDropped', function()
    local player = source
    godPlayers[player], lastRequest[player] = nil, nil
    if vehicles[player] and DoesEntityExist(vehicles[player]) then DeleteEntity(vehicles[player]) end
    vehicles[player] = nil
    local ids = {}
    for id, item in pairs(pending) do
        if item.actor == player or item.target == player then ids[#ids + 1] = id end
    end
    for _, id in ipairs(ids) do complete(id, 409, 'An involved player disconnected.') end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    for _, vehicle in pairs(vehicles) do if DoesEntityExist(vehicle) then DeleteEntity(vehicle) end end
    for actor in pairs(godPlayers) do TriggerClientEvent('nyx_admin:lease', actor, false) end
end)

print('[nyx_admin] Loaded. Local API only; configure an operator, token and ACE permissions before use.')
