-- Server-only configuration. Never change this to shared_scripts.
Config = {
    Operators = {
        {
            name = 'owner',
            identifier = 'license:REPLACE_WITH_YOUR_LICENSE',
            tokenConvar = 'nyx_admin_owner_token'
        }
    },
    Vehicles = { adder = 'automobile', sultan = 'automobile', buffalo = 'automobile',
                 bati = 'bike', sadler = 'automobile' },
    Weapons = { WEAPON_PISTOL = true, WEAPON_STUNGUN = true,
                WEAPON_CARBINERIFLE = true },
    Ammo = 60,
    VehicleRadius = 6.0,
    RequestIntervalMs = 600,
    ClientTimeoutMs = 8000
}
