fx_version 'cerulean'
game 'gta5'
author 'NYX'
description 'Server-authorized administrative companion for NYX FiveM Admin'
version '1.0.0'
dependency '/onesync'
server_scripts { 'config.lua', 'core.lua', 'server.lua' }
client_script 'client.lua'
