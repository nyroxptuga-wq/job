-- Pure validation; also loaded by the offline authorization tests.
NyxCore = {}
local C = NyxCore
C.actions = {
    spawn_vehicle = true, give_weapon = true, revive = true,
    god_on = true, god_off = true, teleport = true,
    lock_vehicle = true, unlock_vehicle = true
}
local function integer(v)
    return type(v) == 'number' and v == v and v % 1 == 0
end
function C.validToken(v)
    return type(v) == 'string' and #v == 64 and v:match('^%x+$') ~= nil
end
function C.secureEqual(a, b)
    if type(a) ~= 'string' or type(b) ~= 'string' or #a ~= #b then return false end
    local different = 0
    for i = 1, #a do different = different | (a:byte(i) ~ b:byte(i)) end
    return different == 0
end
function C.loopback(address)
    if type(address) ~= 'string' then return false end
    return address == '127.0.0.1' or address == '::1'
        or address:match('^127%.0%.0%.1:%d+$') ~= nil
        or address:match('^%[::1%]:%d+$') ~= nil
        or address == '::ffff:127.0.0.1'
        or address:match('^%[::ffff:127%.0%.0%.1%]:%d+$') ~= nil
end
function C.header(headers, name)
    if type(headers) ~= 'table' then return nil end
    for key, value in pairs(headers) do
        if type(key) == 'string' and key:lower() == name:lower() then
            return type(value) == 'string' and value or nil
        end
    end
end
function C.validate(body, config, actor)
    if type(body) ~= 'table' or not C.actions[body.action] then
        return nil, 'Unknown action. Only the fixed admin actions are accepted.'
    end
    local allowed = { action = true, target = true }
    if body.action == 'spawn_vehicle' then allowed.model = true end
    if body.action == 'give_weapon' then allowed.weapon = true end
    if body.action == 'teleport' then allowed.x = true; allowed.y = true; allowed.z = true end
    for key in pairs(body) do
        if not allowed[key] then return nil, 'Unexpected request field.' end
    end
    local target = body.target
    if target == nil or target == 0 then target = actor end
    if not integer(target) or target < 1 or target > 65535 then
        return nil, 'Target must be an online server ID.'
    end
    local action = { action = body.action, target = target }
    if body.action ~= 'revive' and body.action ~= 'give_weapon' and target ~= actor then
        return nil, 'This action can only be applied to your own player.'
    end
    if body.action == 'spawn_vehicle' then
        if type(body.model) ~= 'string' or not config.Vehicles[body.model] then
            return nil, 'Vehicle model is not enabled in the server allowlist.'
        end
        action.model = body.model
    elseif body.action == 'give_weapon' then
        if type(body.weapon) ~= 'string' or not config.Weapons[body.weapon] then
            return nil, 'Weapon is not enabled in the server allowlist.'
        end
        action.weapon = body.weapon
    elseif body.action == 'teleport' then
        for _, key in ipairs({ 'x', 'y', 'z' }) do
            local v = body[key]
            local limit = key == 'z' and 2000 or 8000
            if type(v) ~= 'number' or v ~= v or v == math.huge or v == -math.huge
                or math.abs(v) > limit then
                return nil, 'Teleport requires finite coordinates within map bounds.'
            end
            action[key] = v
        end
    end
    return action
end
