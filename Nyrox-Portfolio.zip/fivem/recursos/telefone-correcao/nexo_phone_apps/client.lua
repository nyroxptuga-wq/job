local function reg(def)
    local ok = exports['oph3z-phone']:RegisterApp(def)
    if not ok then print(('[Nexo Phone Apps] Falha ao registar %s'):format(def.id)) end
end

CreateThread(function()
    while GetResourceState('oph3z-phone') ~= 'started' do Wait(500) end
    Wait(1500)
    local base = ('https://cfx-nui-%s/ui/index.html'):format(GetCurrentResourceName())
    reg({id='nexo_radio', label='Rádio', developer='Nexo Shop', description='Rádio de comunicações RP por frequência.', icon='📻', ui=base..'?app=radio', place='grid', deletable=false})
    reg({id='nexo_wifi', label='Wi-Fi', developer='Nexo Shop', description='Estado de conectividade do telefone.', icon='📶', ui=base..'?app=wifi', place='grid', deletable=false})
    reg({id='nexo_social', label='Social', developer='Nexo Shop', description='Centro de redes e multimédia.', icon='🌐', ui=base..'?app=social', place='grid', deletable=false})
end)

RegisterNUICallback('radioJoin', function(data, cb)
    local ch = tonumber(data and data.channel)
    if not ch or ch < 1 or ch > 999 then cb({ok=false,error='Frequência inválida'}); return end
    if GetResourceState('pma-voice') ~= 'started' then cb({ok=false,error='pma-voice não iniciado'}); return end
    exports['pma-voice']:setRadioChannel(ch)
    cb({ok=true,channel=ch})
end)
RegisterNUICallback('radioLeave', function(_, cb)
    if GetResourceState('pma-voice') == 'started' then exports['pma-voice']:setRadioChannel(0) end
    cb({ok=true})
end)
RegisterNUICallback('wifiState', function(_, cb)
    cb({ok=true, online=true, network='QUINAS-RP 5G', signal=4})
end)
