--[[
    FiveM Scripts
    Copyright C 2018 Sighmir

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    at your option any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Affero General Public License for more details.
    <https://www.gnu.org/licenses/>.

    Revision 1.1.0 — phone banking corrections.
    INSTALL: replace this file inside the original banking resource.
    Requires existing server globals vRPbm, vRP, vRPclient and lang.
    Preserves chargePhoneNumber/payPhoneNumber, online recipients,
    existing translation keys and the 600-second charge confirmation.
    This module does not implement the graphical smartphone or its licence.
    Amounts are positive whole game-currency units, within exact integer range.
    Locks cover these two functions only; vRP must handle wider banking concurrency.
    Two setBankMoney calls are not a database transaction. Indeterminate writes
    are logged for reconciliation; no automatic retry is performed.
]]

assert(type(vRPbm)=='table', 'phone.lua: load inside the original vRP banking resource (vRPbm missing).')
assert(type(vRP)=='table' and type(vRPclient)=='table', 'phone.lua: vRP/vRPclient missing.')

local MAX_INTEGER=9007199254740991
-- Reuse locks when reloading this module within the same resource.
vRPbm._phoneTransferLocks=vRPbm._phoneTransferLocks or {}
local locks=vRPbm._phoneTransferLocks

local function integer(value,positive)
 local number=tonumber(value)
 if not number or number~=number or number<0 or number>MAX_INTEGER or number%1~=0 then return nil end
 if positive and number==0 then return nil end
 return number
end
local function amount(value)
 if type(value)=='string' then
  value=value:match('^%s*(.-)%s*$')
  if not value:match('^%d+$') then return nil end
 elseif type(value)~='number' then return nil end
 return integer(value,true)
end
local function phoneNumber(value)
 if type(value)~='string' and type(value)~='number' then return nil end
 local phone=tostring(value):match('^%s*(.-)%s*$')
 if #phone<1 or #phone>64 or phone:find('[%c<>]') then return nil end
 return phone
end
local function escape(value)
 return tostring(value or ''):gsub('&','&amp;'):gsub('<','&lt;'):gsub('>','&gt;'):gsub('"','&quot;'):gsub("'",'&#39;')
end
local function text(section,key,args,fallback)
 local current=type(lang)=='table' and lang[section]
 local fn=type(current)=='table' and current[key]
 if type(fn)=='function' then
  local safe={}
  for i,value in ipairs(args or {}) do safe[i]=type(value)=='string' and escape(value) or value end
  local ok,result=pcall(fn,safe)
  if ok and type(result)=='string' then return result end
 end
 return fallback
end
local function player(uid)
 local source=vRP.getUserSource(uid)
 return integer(source,true)
end
local function notify(source,message)
 if source and message then
  local ok,err=pcall(vRPclient.notify,source,message)
  if not ok then print('[phone banking] Notification failed: '..tostring(err)) end
 end
end
local function invalid(source)
 notify(source,text('common','invalid_value',nil,'Valor ou jogador inválido.'))
end
local function directory(uid,phone)
 local name=vRP.getPhoneDirectoryName(uid,phone)
 if type(name)~='string' or name=='' or name=='unknown' then return phone end
 return name
end
local function nameForRecipient(recipient,sender)
 local identity=vRP.getUserIdentity(sender)
 local phone=type(identity)=='table' and phoneNumber(identity.phone)
 return phone and directory(recipient,phone) or tostring(sender)
end
local function matches(uid,source)
 return player(uid)==source
end
local function close(source)
 local ok,err=pcall(vRP.closeMenu,source)
 if not ok then print('[phone banking] Menu close failed: '..tostring(err)) end
end
local function logIssue(from,to,value,reason)
 print(('[phone banking] Transfer ID %s -> ID %s, amount %s: %s'):format(tostring(from),tostring(to),tostring(value),tostring(reason)))
end

local function writeBalances(from,to,value,beforeFrom,beforeTo)
 local afterFrom,afterTo=beforeFrom-value,beforeTo+value
 local ok,err=pcall(function()
  -- Debit first: a failed debit must never be followed by a credit.
  vRP.setBankMoney(from,afterFrom)
  vRP.setBankMoney(to,afterTo)
 end)
 if ok then return true end
 -- A framework can throw after persisting a write. Inspect before deciding
 -- whether restoring the debit would itself create money.
 local inspected,currentFrom,currentTo=pcall(function()
  return integer(vRP.getBankMoney(from)),integer(vRP.getBankMoney(to))
 end)
 if inspected and currentFrom==afterFrom and currentTo==afterTo then
  logIssue(from,to,value,'Both balances committed despite setter error: '..tostring(err))
  return true
 end
 if inspected and currentFrom==beforeFrom and currentTo==beforeTo then
  logIssue(from,to,value,'No balance change: '..tostring(err))
  return false,'write'
 end
 if inspected and currentFrom==afterFrom and currentTo==beforeTo then
  local restored=pcall(function()
   vRP.setBankMoney(from,beforeFrom)
   assert(integer(vRP.getBankMoney(from))==beforeFrom,'Debit restore not confirmed')
  end)
  if restored then
   logIssue(from,to,value,'Debit restored after credit failed: '..tostring(err))
   return false,'write'
  end
 end
 logIssue(from,to,value,'MANUAL RECONCILIATION REQUIRED; do not retry automatically: '..tostring(err))
 return false,'uncertain'
end

local function transfer(from,to,value,fromSource,toSource)
 if from==to then return false,'invalid' end
 if locks[from] or locks[to] then return false,'busy' end
 local token={}
 locks[from],locks[to]=token,token
 local result=table.pack(pcall(function()
  if not matches(from,fromSource) or not matches(to,toSource) then return false,'offline' end
  -- Read current balances after any prompt/confirmation and after obtaining locks.
  local fromBalance=integer(vRP.getBankMoney(from))
  local toBalance=integer(vRP.getBankMoney(to))
  if not fromBalance or not toBalance or value>MAX_INTEGER-toBalance then return false,'invalid' end
  if fromBalance<value then return false,'funds' end
  if not matches(from,fromSource) or not matches(to,toSource) then return false,'offline' end
  return writeBalances(from,to,value,fromBalance,toBalance)
 end))
 if locks[from]==token then locks[from]=nil end
 if locks[to]==token then locks[to]=nil end
 if not result[1] then logIssue(from,to,value,result[2]); return false,'write' end
 return table.unpack(result,2,result.n)
end
local function failure(source,reason)
 if reason=='busy' then notify(source,'Já existe uma operação nestas contas. Aguarda e verifica o saldo antes de tentar novamente.')
 elseif reason=='write' or reason=='uncertain' then notify(source,'Não foi possível confirmar o pagamento. Verifica os saldos e contacta a administração antes de repetir.')
 else invalid(source) end
end

function vRPbm.chargePhoneNumber(user_id,phone)
 user_id=integer(user_id,true)
 phone=phoneNumber(phone)
 if not user_id then return false end
 local source=player(user_id)
 if not source then return false end
 if not phone then invalid(source); return false end
 local directoryName=directory(user_id,phone)
 local value=amount(vRP.prompt(source,text('mcharge','prompt',{directoryName},'Montante a cobrar:'),''))
 if not value then invalid(source); return false end
 if not matches(user_id,source) then return false end
 local targetId=integer(vRP.getUserByPhone(phone),true)
 if not targetId or targetId==user_id then invalid(source); return false end
 local target=player(targetId)
 if not target then invalid(source); return false end
 local senderName=nameForRecipient(targetId,user_id)
 local accepted=vRP.request(target,text('mcharge','request',{senderName,value},'Aceitas pagar '..value..' ao ID '..user_id..'?'),600)
 if not matches(user_id,source) then return false end
 if not accepted then
  notify(source,text('mcharge','refused',{directoryName},'O pedido de pagamento foi recusado.'))
  return false
 end
 local ok,reason=transfer(targetId,user_id,value,target,source)
 if not ok then
  if reason=='funds' then
   if matches(targetId,target) then notify(target,text('money','not_enough',nil,'Saldo insuficiente.')) end
   notify(source,text('mcharge','not_enough',{directoryName},'O destinatário não tem saldo suficiente.'))
  else failure(source,reason) end
  return false
 end
 notify(source,text('mcharge','charger',{directoryName,value},'Pagamento recebido: '..value..'.'))
 if matches(targetId,target) then notify(target,text('mcharge','charged',{senderName,value},'Pagamento efetuado: '..value..'.')) end
 close(source)
 return true
end

function vRPbm.payPhoneNumber(user_id,phone)
 user_id=integer(user_id,true)
 phone=phoneNumber(phone)
 if not user_id then return false end
 local source=player(user_id)
 if not source then return false end
 if not phone then invalid(source); return false end
 local directoryName=directory(user_id,phone)
 local value=amount(vRP.prompt(source,text('mpay','prompt',{directoryName},'Montante a transferir:'),''))
 if not value then invalid(source); return false end
 if not matches(user_id,source) then return false end
 local targetId=integer(vRP.getUserByPhone(phone),true)
 if not targetId or targetId==user_id then invalid(source); return false end
 local target=player(targetId)
 if not target then invalid(source); return false end
 local senderName=nameForRecipient(targetId,user_id)
 local ok,reason=transfer(user_id,targetId,value,source,target)
 if not ok then
  if reason=='funds' then notify(source,text('money','not_enough',nil,'Saldo insuficiente.'))
  else failure(source,reason) end
  return false
 end
 notify(source,text('mpay','transferred',{value,directoryName},'Transferência efetuada: '..value..'.'))
 if matches(targetId,target) then notify(target,text('mpay','received',{value,senderName},'Transferência recebida: '..value..'.')) end
 close(source)
 return true
end
